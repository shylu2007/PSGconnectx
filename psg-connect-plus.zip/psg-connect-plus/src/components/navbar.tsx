'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { SearchDialog } from './search-dialog';
import {
  Search,
  Bell,
  Menu,
  X,
  GraduationCap,
  Briefcase,
  Home as HomeIcon,
  Calendar,
  FileText,
  Users,
  LayoutDashboard,
  ShieldCheck,
  LogOut,
  User,
  ChevronDown,
  Bookmark,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isAuthenticated, logout, role } = useAuth();
  
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const updateNotifs = () => {
      if (user) {
        const notifs = DataStore.getNotifications(user.id);
        const unread = notifs.filter((n) => !n.is_read).length;
        setUnreadCount(unread);
      } else {
        setUnreadCount(0);
      }
    };

    updateNotifs();
    window.addEventListener('psg_store_updated', updateNotifs);
    return () => window.removeEventListener('psg_store_updated', updateNotifs);
  }, [user]);

  // Close menus on navigation
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsUserMenuOpen(false);
  }, [pathname]);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Internships', href: '/internships' },
    { name: 'Accommodation', href: '/accommodation' },
    { name: 'Campus Buzz', href: '/community' },
    { name: 'Academic Spotlight', href: '/resources' },
    { name: 'Events', href: '/events' },
    { name: 'Alumni', href: '/alumni' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/95 backdrop-blur-md transition-all">
        <div className="container max-w-7xl mx-auto flex h-16 items-center justify-between px-4 sm:px-6">
          {/* Brand Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-psg-900 to-blue-700 flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-lg font-black tracking-tight text-psg-950 font-serif">
                  PSG
                </span>
                <span className="text-lg font-bold tracking-tight text-blue-600">
                  Connect<span className="text-emerald-500 font-extrabold">+</span>
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold leading-none">
                Student & Alumni Hub
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    'px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-blue-50 text-psg-900 font-semibold'
                      : 'text-slate-600 hover:text-psg-900 hover:bg-slate-50'
                  )}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Right Action Icons & Auth */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Global Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-500 text-xs hover:bg-slate-100 hover:border-slate-300 transition-all"
              aria-label="Open search dialog"
            >
              <Search className="h-3.5 w-3.5 text-slate-500" />
              <span className="hidden sm:inline">Search...</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 bg-white rounded border border-slate-200">
                ⌘K
              </kbd>
            </button>

            {/* Notifications Button */}
            {isAuthenticated && (
              <Link
                href="/notifications"
                className="relative p-2 rounded-lg text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors"
                aria-label="View notifications"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white shadow-sm animate-pulse-subtle">
                    {unreadCount}
                  </span>
                )}
              </Link>
            )}

            {/* User Account / Sign In */}
            {isAuthenticated && user ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
                >
                  {user.avatar_url ? (
                    <img
                      src={user.avatar_url}
                      alt={user.full_name}
                      className="h-8 w-8 rounded-lg object-cover ring-1 ring-slate-200"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded-lg bg-psg-800 text-white flex items-center justify-center font-bold text-xs">
                      {user.full_name.charAt(0)}
                    </div>
                  )}
                  <span className="hidden md:inline text-xs font-semibold text-slate-800 max-w-[100px] truncate">
                    {user.full_name.split(' ')[0]}
                  </span>
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400 hidden md:inline" />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-20"
                      onClick={() => setIsUserMenuOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white p-2 shadow-2xl border border-slate-200 z-30 animate-in fade-in-0 zoom-in-95">
                      <div className="px-3 py-2.5 border-b border-slate-100">
                        <p className="text-sm font-bold text-slate-900">{user.full_name}</p>
                        <p className="text-xs text-slate-500 truncate">{user.email}</p>
                        <div className="mt-1.5 flex items-center gap-1.5">
                          <Badge variant="psg" className="capitalize text-[10px]">
                            {user.role}
                          </Badge>
                          <span className="text-[11px] text-slate-400">
                            {user.department.split(' ')[0]} &apos;{String(user.batch_year).slice(-2)}
                          </span>
                        </div>
                      </div>

                      <div className="py-1 space-y-0.5">
                        <Link
                          href="/dashboard"
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-psg-900 transition-colors"
                        >
                          <LayoutDashboard className="h-4 w-4 text-blue-600" />
                          My Dashboard
                        </Link>
                        
                        {role === 'admin' && (
                          <Link
                            href="/admin"
                            onClick={() => setIsUserMenuOpen(false)}
                            className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-amber-700 hover:bg-amber-50 transition-colors"
                          >
                            <ShieldCheck className="h-4 w-4 text-amber-600" />
                            Admin Console
                          </Link>
                        )}

                        <Link
                          href="/dashboard?tab=saved"
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-psg-900 transition-colors"
                        >
                          <Bookmark className="h-4 w-4 text-slate-500" />
                          Saved Items
                        </Link>

                        <Link
                          href="/dashboard?tab=profile"
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-psg-900 transition-colors"
                        >
                          <User className="h-4 w-4 text-slate-500" />
                          Edit Profile
                        </Link>
                      </div>

                      <div className="pt-1 border-t border-slate-100">
                        <button
                          onClick={() => {
                            logout();
                            setIsUserMenuOpen(false);
                            router.push('/');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-red-600 hover:bg-red-50 transition-colors"
                        >
                          <LogOut className="h-4 w-4" />
                          Sign Out
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/auth/login">
                  <Button variant="ghost" size="sm">
                    Login
                  </Button>
                </Link>
                <Link href="/auth/register">
                  <Button variant="default" size="sm">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-1 animate-in slide-in-from-top-2">
            <div className="grid grid-cols-2 gap-2 pb-3 mb-2 border-b border-slate-100">
              <Link
                href="/jobs"
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-medium"
              >
                <Briefcase className="h-4 w-4 text-blue-600" /> Jobs
              </Link>
              <Link
                href="/internships"
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-medium"
              >
                <GraduationCap className="h-4 w-4 text-indigo-600" /> Internships
              </Link>
              <Link
                href="/accommodation"
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-medium"
              >
                <HomeIcon className="h-4 w-4 text-emerald-600" /> Accommodation
              </Link>
              <Link
                href="/events"
                className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-medium"
              >
                <Calendar className="h-4 w-4 text-amber-600" /> Events
              </Link>
            </div>

            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  'block px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  pathname === link.href
                    ? 'bg-blue-50 text-psg-900 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50'
                )}
              >
                {link.name}
              </Link>
            ))}

            {isAuthenticated && (
              <div className="pt-2 border-t border-slate-100 space-y-1">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-blue-700 bg-blue-50/70"
                >
                  <LayoutDashboard className="h-4 w-4" /> My Dashboard
                </Link>
                {role === 'admin' && (
                  <Link
                    href="/admin"
                    className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-amber-800 bg-amber-50/70"
                  >
                    <ShieldCheck className="h-4 w-4" /> Admin Console
                  </Link>
                )}
              </div>
            )}
          </div>
        )}
      </header>

      {/* Global Search Dialog Modal */}
      <SearchDialog
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />
    </>
  );
}
