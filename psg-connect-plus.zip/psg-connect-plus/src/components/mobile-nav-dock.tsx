'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Home,
  GraduationCap,
  Building,
  Calendar,
  Users,
  LayoutDashboard,
  BookOpen,
  Flame,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

export function MobileNavDock() {
  const pathname = usePathname();
  const { isAuthenticated } = useAuth();

  const navItems = [
    { label: 'Home', href: '/', icon: Home },
    { label: 'Internships', href: '/internships', icon: GraduationCap },
    { label: 'Accommodation', href: '/accommodation', icon: Building },
    { label: 'Buzz', href: '/community', icon: Flame },
    { label: 'Spotlight', href: '/resources', icon: BookOpen },
    { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t border-slate-200 px-2 py-1.5 shadow-2xl">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all ${
                isActive
                  ? 'text-psg-900 font-bold scale-105'
                  : 'text-slate-500 hover:text-slate-900 font-medium'
              }`}
            >
              <Icon className={`h-4 w-4 ${isActive ? 'text-blue-600 stroke-[2.5]' : 'stroke-[1.75]'}`} />
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
