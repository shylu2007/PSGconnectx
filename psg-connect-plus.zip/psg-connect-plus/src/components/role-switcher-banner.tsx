'use client';

import React from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from './ui/toast';
import { UserCheck, ShieldCheck, GraduationCap, RotateCcw, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

export function RoleSwitcherBanner() {
  const { user, role, demoLogin } = useAuth();
  const { success } = useToast();

  const handleSwitch = (targetRole: 'student' | 'alumni' | 'admin') => {
    demoLogin(targetRole);
    success(
      `Switched to ${targetRole.toUpperCase()} View`,
      `Active account: ${targetRole === 'student' ? 'Aditya (Student)' : targetRole === 'alumni' ? 'Dr. Priya (Google Alumni)' : 'Placement Admin'}`
    );
  };

  const handleResetData = () => {
    if (confirm('Reset database to default sample data (10 jobs, 10 internships, 8 housing listings, 8 events, 10 alumni, 10 exams)?')) {
      DataStore.resetAllData();
      success('Database Reset', 'Sample data successfully restored.');
    }
  };

  return (
    <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 border-b border-slate-800">
      <div className="container max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 font-semibold text-blue-400">
            <Sparkles className="h-3.5 w-3.5 text-blue-400" /> PSG Connect+
          </span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="text-slate-300 hidden md:inline">
            Active Mode:
          </span>
          <span className={cn(
            "px-2 py-0.5 rounded-full font-medium text-[11px] capitalize",
            role === 'admin' ? "bg-amber-900/60 text-amber-200 border border-amber-700/50" :
            role === 'alumni' ? "bg-purple-900/60 text-purple-200 border border-purple-700/50" :
            "bg-blue-900/60 text-blue-200 border border-blue-700/50"
          )}>
            {user ? `${user.full_name} (${role})` : 'Guest Visitor'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px] hidden sm:inline">Switch Role:</span>
          
          <button
            onClick={() => handleSwitch('student')}
            className={cn(
              "px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1",
              role === 'student'
                ? "bg-blue-600 text-white shadow-sm"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
            )}
          >
            <GraduationCap className="h-3 w-3" /> Student
          </button>

          <button
            onClick={() => handleSwitch('alumni')}
            className={cn(
              "px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1",
              role === 'alumni'
                ? "bg-purple-600 text-white shadow-sm"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
            )}
          >
            <UserCheck className="h-3 w-3" /> Alumni
          </button>

          <button
            onClick={() => handleSwitch('admin')}
            className={cn(
              "px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1",
              role === 'admin'
                ? "bg-amber-600 text-white shadow-sm"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
            )}
          >
            <ShieldCheck className="h-3 w-3" /> Admin
          </button>

          <button
            onClick={handleResetData}
            title="Restore sample demo data"
            className="p-1 rounded-md bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors ml-1"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
