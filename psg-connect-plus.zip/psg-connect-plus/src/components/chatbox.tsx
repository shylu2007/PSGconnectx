'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  Minimize2,
  Maximize2,
  GraduationCap,
  ChevronDown,
  HelpCircle,
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ChatMessage } from '@/types';

export function CampusChatbox() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadMessages = () => {
    setMessages(DataStore.getChatMessages());
  };

  useEffect(() => {
    loadMessages();
    window.addEventListener('psg_store_updated', loadMessages);
    return () => window.removeEventListener('psg_store_updated', loadMessages);
  }, []);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputValue.trim();
    if (!text) return;

    // Add user message
    const userMsg = DataStore.sendChatMessage(text, 'user');
    setInputValue('');
    setIsTyping(true);

    try {
      // Send to server API endpoint
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, userId: user?.id }),
      });

      if (res.ok) {
        const data = await res.json();
        setTimeout(() => {
          setIsTyping(false);
          const assistantMsg = DataStore.sendChatMessage(data.reply, 'assistant');
          if (data.suggestions && data.suggestions.length > 0) {
            assistantMsg.suggestions = data.suggestions;
          }
        }, 500);
      } else {
        throw new Error('Failed to connect to assistant API');
      }
    } catch (err) {
      // Graceful offline fallback
      setTimeout(() => {
        setIsTyping(false);
        DataStore.sendChatMessage(
          `I am running in offline mode. For attendance calculations, please visit the Attendance portal. For exam timetables, visit the Exams portal.`,
          'assistant'
        );
      }, 500);
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-20 md:bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-psg-900 to-blue-700 hover:from-psg-800 hover:to-blue-600 text-white rounded-full shadow-2xl hover:scale-105 transition-all duration-200 group border border-white/20"
          aria-label="Open PSG Campus Chat"
        >
          <div className="relative">
            <Bot className="h-5 w-5 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </div>
          <span className="text-xs font-bold font-sans">PSG Assistant</span>
        </button>
      )}

      {/* Chat Window Modal */}
      {isOpen && (
        <div
          className={`fixed z-50 transition-all duration-200 bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col ${
            isExpanded
              ? 'inset-4 md:inset-10 max-w-4xl max-h-[85vh] mx-auto my-auto'
              : 'bottom-20 md:bottom-6 right-4 md:right-6 w-[92vw] sm:w-[400px] h-[540px]'
          }`}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-psg-900 via-blue-900 to-slate-900 text-white px-5 py-3.5 flex items-center justify-between shadow-md">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-inner">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-sm">PSG Connect+ AI</h3>
                  <Badge variant="success" className="text-[9px] py-0 px-1.5 h-4">
                    Online
                  </Badge>
                </div>
                <p className="text-[10px] text-blue-200">Campus Guide & Bunk Calculator</p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
                title={isExpanded ? 'Minimize' : 'Maximize'}
              >
                {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors"
                title="Close chat"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/60 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="h-7 w-7 rounded-full bg-psg-900 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-sm">
                    <Bot className="h-3.5 w-3.5" />
                  </div>
                )}

                <div className="space-y-2 max-w-[82%]">
                  <div
                    className={`p-3 rounded-2xl leading-relaxed whitespace-pre-line shadow-sm ${
                      msg.sender === 'user'
                        ? 'bg-blue-600 text-white rounded-br-none font-medium'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
                    }`}
                  >
                    {msg.content}
                  </div>

                  {/* Suggestion Chips */}
                  {msg.suggestions && msg.suggestions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {msg.suggestions.map((sug, i) => (
                        <button
                          key={i}
                          onClick={() => handleSendMessage(sug)}
                          className="px-2.5 py-1 rounded-full bg-white hover:bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-semibold transition-all hover:scale-105 shadow-xs"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  )}

                  <span className="text-[9px] text-slate-400 block px-1">
                    {new Date(msg.timestamp).toLocaleTimeString('en-IN', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                {msg.sender === 'user' && (
                  <div className="h-7 w-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 border border-blue-200">
                    <User className="h-3.5 w-3.5" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <div className="h-7 w-7 rounded-full bg-psg-900 text-white flex items-center justify-center">
                  <Bot className="h-3.5 w-3.5" />
                </div>
                <div className="bg-white p-3 rounded-2xl border border-slate-200 flex items-center gap-1.5 shadow-sm">
                  <span className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-bounce"></span>
                  <span className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
          >
            <Input
              type="text"
              placeholder="Ask about attendance, bunks, exams, housing..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="text-xs flex-1 h-9 rounded-xl"
            />
            <Button
              type="submit"
              size="sm"
              disabled={!inputValue.trim()}
              className="bg-psg-900 hover:bg-psg-800 text-white h-9 px-3 rounded-xl shrink-0"
            >
              <Send className="h-3.5 w-3.5" />
            </Button>
          </form>
        </div>
      )}
    </>
  );
}
