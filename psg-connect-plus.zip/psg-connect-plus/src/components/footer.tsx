'use client';

import React from 'react';
import Link from 'next/link';
import { GraduationCap, Mail, Phone, MapPin, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      {/* Top collegiate banner */}
      <div className="bg-psg-900/60 border-b border-slate-800 py-6 px-4">
        <div className="container max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shadow-md">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-white font-bold text-base">PSG Tech & Institutions Community</p>
              <p className="text-xs text-blue-200">Connecting 15,000+ students and global alumni across 45+ countries</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/auth/register"
              className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors"
            >
              Join the Network
            </Link>
            <Link
              href="/alumni"
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
            >
              Find Alumni Mentors
            </Link>
          </div>
        </div>
      </div>

      {/* Main footer columns */}
      <div className="container max-w-7xl mx-auto py-12 px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <GraduationCap className="h-5 w-5" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                PSG Connect<span className="text-emerald-400">+</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              The unified digital platform for students, faculty, and alumni of PSG Institutions. Discover top-tier career placements, research internships, verified student housing, college symposiums, and exam timetables.
            </p>
            <div className="space-y-1.5 text-xs text-slate-400">
              <p className="flex items-center gap-2">
                <MapPin className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                <span>Avinashi Road, Peelamedu, Coimbatore, TN - 641004</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                <span>connect@psgtech.ac.in</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                <span>+91 422 257 2177 / 247 2177</span>
              </p>
            </div>
          </div>

          {/* Quick Portals */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Explore Portals
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/internships" className="hover:text-white transition-colors">
                  Internships & Research
                </Link>
              </li>
              <li>
                <Link href="/accommodation" className="hover:text-white transition-colors">
                  Student Accommodation & PGs
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-white transition-colors">
                  Campus Buzz Discussions
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-white transition-colors">
                  Academic Spotlight & Global Degrees
                </Link>
              </li>
              <li>
                <Link href="/events" className="hover:text-white transition-colors">
                  Symposiums & Hackathons
                </Link>
              </li>
            </ul>
          </div>

          {/* Student Hub */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Connect & Support
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/alumni" className="hover:text-white transition-colors">
                  Alumni Mentors Directory
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-white transition-colors">
                  Student Dashboard
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  About PSG Connect+
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-white transition-colors">
                  Student Dashboard
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  About PSG Connect+
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal & Trust */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Platform & Trust
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/about#guidelines" className="hover:text-white transition-colors">
                  Community Guidelines
                </Link>
              </li>
              <li>
                <Link href="/about#privacy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/about#terms" className="hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/about#verification" className="hover:text-white transition-colors">
                  Verification Badges
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-amber-400 transition-colors">
                  Admin Portal
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} PSG Connect+. Built with excellence for PSG Institutions.</p>
          <p className="flex items-center gap-1">
            Crafted for PSGians with <Heart className="h-3.5 w-3.5 text-red-500 fill-red-500" />
          </p>
        </div>
      </div>
    </footer>
  );
}
