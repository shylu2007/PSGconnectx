'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Search,
  Briefcase,
  GraduationCap,
  Home,
  Calendar,
  FileText,
  Users,
  X,
  ArrowRight,
  BookOpen,
  MessageSquare,
  CalendarCheck,
} from 'lucide-react';
import { DataStore } from '@/lib/store';
import { Badge } from './ui/badge';
import { cn } from '@/lib/utils';

interface SearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchDialog({ isOpen, onClose }: SearchDialogProps) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'internships' | 'housing' | 'resources' | 'community' | 'events' | 'alumni'>('all');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        // toggle handled by parent or opened
      }
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  // Query collections
  const allAttendance = DataStore.getAttendanceSubjects().filter(
    (a) =>
      !q ||
      a.subject_code.toLowerCase().includes(q) ||
      a.subject_name.toLowerCase().includes(q) ||
      (a.faculty_name && a.faculty_name.toLowerCase().includes(q))
  );

  const allJobs = DataStore.getJobs().filter(
    (j) =>
      !q ||
      j.title.toLowerCase().includes(q) ||
      j.company.toLowerCase().includes(q) ||
      j.skills.some((s) => s.toLowerCase().includes(q))
  );

  const allInternships = DataStore.getInternships().filter(
    (i) =>
      !q ||
      i.role.toLowerCase().includes(q) ||
      i.company.toLowerCase().includes(q) ||
      i.domain.toLowerCase().includes(q)
  );

  const allAccommodations = DataStore.getAccommodations().filter(
    (a) =>
      !q ||
      a.title.toLowerCase().includes(q) ||
      a.location.toLowerCase().includes(q) ||
      a.property_type.toLowerCase().includes(q)
  );

  const allEvents = DataStore.getEvents().filter(
    (e) =>
      !q ||
      e.title.toLowerCase().includes(q) ||
      e.category.toLowerCase().includes(q) ||
      e.venue.toLowerCase().includes(q)
  );

  const allAlumni = DataStore.getAlumni().filter(
    (a) =>
      !q ||
      a.name.toLowerCase().includes(q) ||
      a.current_company.toLowerCase().includes(q) ||
      a.position.toLowerCase().includes(q) ||
      a.department.toLowerCase().includes(q)
  );

  const allExams = DataStore.getExams().filter(
    (ex) =>
      !q ||
      ex.subject_code.toLowerCase().includes(q) ||
      ex.subject_name.toLowerCase().includes(q) ||
      ex.department.toLowerCase().includes(q)
  );

  const allResources = DataStore.getResources().filter(
    (res) =>
      !q ||
      res.student_name.toLowerCase().includes(q) ||
      res.title.toLowerCase().includes(q) ||
      (res.partner_university && res.partner_university.toLowerCase().includes(q)) ||
      res.description.toLowerCase().includes(q) ||
      res.tags.some((t) => t.toLowerCase().includes(q))
  );

  const allPosts = DataStore.getCommunityPosts().filter(
    (post) =>
      !q ||
      post.title.toLowerCase().includes(q) ||
      post.content.toLowerCase().includes(q)
  );

  const handleNavigate = (path: string) => {
    onClose();
    router.push(path);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 md:p-12 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Dialog Panel */}
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150 my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="flex items-center px-5 py-4 border-b border-slate-100 bg-slate-50/50">
          <Search className="h-5 w-5 text-slate-400 mr-3 shrink-0" />
          <input
            type="text"
            placeholder="Search internships, accommodation, buzz topics, academic spotlights, alumni..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm placeholder:text-slate-400 text-slate-900 focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 mr-2"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold text-slate-500 bg-slate-200 rounded border border-slate-300">
            ESC
          </kbd>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 px-5 py-2.5 border-b border-slate-100 bg-white overflow-x-auto text-xs font-medium">
          {[
            { id: 'all', label: 'All Results' },
            { id: 'internships', label: `Internships (${allInternships.length})` },
            { id: 'housing', label: `Accommodation (${allAccommodations.length})` },
            { id: 'community', label: `Campus Buzz (${allPosts.length})` },
            { id: 'resources', label: `Spotlight (${allResources.length})` },
            { id: 'events', label: `Events (${allEvents.length})` },
            { id: 'alumni', label: `Alumni (${allAlumni.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                'px-3 py-1.5 rounded-full transition-colors whitespace-nowrap',
                activeTab === tab.id
                  ? 'bg-psg-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4 divide-y divide-slate-100">

          {/* Internships */}
          {(activeTab === 'all' || activeTab === 'internships') && allInternships.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <GraduationCap className="h-3.5 w-3.5 text-indigo-600" /> Internships
                </span>
                <button
                  onClick={() => handleNavigate('/internships')}
                  className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allInternships.slice(0, activeTab === 'internships' ? 10 : 3).map((intern) => (
                  <div
                    key={intern.id}
                    onClick={() => handleNavigate(`/internships?id=${intern.id}`)}
                    className="p-3 rounded-xl hover:bg-indigo-50/60 border border-transparent hover:border-indigo-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{intern.role}</p>
                      <p className="text-xs text-slate-500">
                        {intern.company} • <span className="text-indigo-600 font-medium">{intern.domain}</span> • {intern.stipend}
                      </p>
                    </div>
                    <Badge variant="secondary">{intern.remote_type}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
          {/* Academic Spotlight */}
          {(activeTab === 'all' || activeTab === 'resources') && allResources.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <BookOpen className="h-3.5 w-3.5 text-teal-600" /> Academic Spotlight & Honors
                </span>
                <button
                  onClick={() => handleNavigate('/resources')}
                  className="text-xs text-teal-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allResources.slice(0, activeTab === 'resources' ? 10 : 3).map((res) => (
                  <div
                    key={res.id}
                    onClick={() => handleNavigate('/resources')}
                    className="p-3 rounded-xl hover:bg-teal-50/60 border border-transparent hover:border-teal-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{res.student_name} — {res.title}</p>
                      <p className="text-xs text-slate-500">
                        {res.partner_university || res.institution} • {res.program_type || res.category}
                      </p>
                    </div>
                    <Badge variant="psg">{res.category}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Community */}
          {(activeTab === 'all' || activeTab === 'community') && allPosts.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <MessageSquare className="h-3.5 w-3.5 text-purple-600" /> Student Discussions
                </span>
                <button
                  onClick={() => handleNavigate('/community')}
                  className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allPosts.slice(0, activeTab === 'community' ? 10 : 3).map((post) => (
                  <div
                    key={post.id}
                    onClick={() => handleNavigate('/community')}
                    className="p-3 rounded-xl hover:bg-purple-50/60 border border-transparent hover:border-purple-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{post.title}</p>
                      <p className="text-xs text-slate-500">
                        {post.author_name} • {post.comments.length} replies
                      </p>
                    </div>
                    <Badge variant="purple">#{post.channel}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Accommodations */}
          {(activeTab === 'all' || activeTab === 'housing') && allAccommodations.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Home className="h-3.5 w-3.5 text-emerald-600" /> Accommodations & PGs
                </span>
                <button
                  onClick={() => handleNavigate('/accommodation')}
                  className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allAccommodations.slice(0, activeTab === 'housing' ? 10 : 3).map((acc) => (
                  <div
                    key={acc.id}
                    onClick={() => handleNavigate(`/accommodation?id=${acc.id}`)}
                    className="p-3 rounded-xl hover:bg-emerald-50/60 border border-transparent hover:border-emerald-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{acc.title}</p>
                      <p className="text-xs text-slate-500">
                        {acc.location} • {acc.distance_to_campus}
                      </p>
                    </div>
                    <span className="text-sm font-bold text-emerald-700">₹{acc.rent}/mo</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Events */}
          {(activeTab === 'all' || activeTab === 'events') && allEvents.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-amber-600" /> Campus Events
                </span>
                <button
                  onClick={() => handleNavigate('/events')}
                  className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allEvents.slice(0, activeTab === 'events' ? 10 : 3).map((event) => (
                  <div
                    key={event.id}
                    onClick={() => handleNavigate(`/events?id=${event.id}`)}
                    className="p-3 rounded-xl hover:bg-amber-50/60 border border-transparent hover:border-amber-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{event.title}</p>
                      <p className="text-xs text-slate-500">
                        {event.event_date} • {event.venue}
                      </p>
                    </div>
                    <Badge variant="warning">{event.category}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Alumni */}
          {(activeTab === 'all' || activeTab === 'alumni') && allAlumni.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 text-purple-600" /> Alumni Mentors
                </span>
                <button
                  onClick={() => handleNavigate('/alumni')}
                  className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                >
                  View all <ArrowRight className="h-3 w-3" />
                </button>
              </div>
              <div className="space-y-1.5">
                {allAlumni.slice(0, activeTab === 'alumni' ? 10 : 3).map((alum) => (
                  <div
                    key={alum.id}
                    onClick={() => handleNavigate(`/alumni?id=${alum.id}`)}
                    className="p-3 rounded-xl hover:bg-purple-50/60 border border-transparent hover:border-purple-100 cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{alum.name}</p>
                      <p className="text-xs text-slate-500">
                        {alum.position} • {alum.current_company} • Class of {alum.graduation_year}
                      </p>
                    </div>
                    <Badge variant="purple">Alumni</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {allInternships.length === 0 &&
            allAccommodations.length === 0 &&
            allResources.length === 0 &&
            allPosts.length === 0 &&
            allEvents.length === 0 &&
            allAlumni.length === 0 && (
              <div className="py-12 text-center">
                <Search className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                <p className="text-base font-semibold text-slate-800">No matching results found</p>
                <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
                  We couldn't find anything matching &quot;{query}&quot;. Try searching for companies, housing, notes, topics, or alumni.
                </p>
              </div>
            )}
        </div>

        {/* Footer info */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Search across 50+ PSG opportunities & resources</span>
          <span>Tip: Press <kbd className="font-semibold text-slate-700 bg-white px-1.5 py-0.5 rounded border border-slate-200">ESC</kbd> to close</span>
        </div>
      </div>
    </div>
  );
}
