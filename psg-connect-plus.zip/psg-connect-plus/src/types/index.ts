export type UserRole = 'student' | 'alumni' | 'admin';

export interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  role: UserRole;
  department: string;
  batch_year: number;
  phone?: string;
  avatar_url?: string;
  bio?: string;
  skills?: string[];
  current_company?: string;
  current_role?: string;
  linkedin_url?: string;
  github_url?: string;
  is_verified?: boolean;
  created_at?: string;
}

export type JobType = 'Full-time' | 'Part-time' | 'Contract' | 'Remote';
export type ExperienceLevel = 'Fresher / 0-1 yr' | '1-3 yrs' | '3-5 yrs' | '5+ yrs';

export interface Job {
  id: string;
  title: string;
  company: string;
  company_logo?: string;
  location: string;
  job_type: JobType;
  salary: string;
  experience_level: ExperienceLevel;
  eligible_departments: string[];
  description: string;
  requirements: string[];
  skills: string[];
  deadline: string;
  apply_url?: string;
  contact_email?: string;
  posted_by?: string;
  is_active: boolean;
  created_at: string;
}

export type InternshipDomain = 
  | 'Software Development'
  | 'AI / ML'
  | 'Data Science'
  | 'VLSI & Embedded'
  | 'Core Mechanical'
  | 'Robotics & Automation'
  | 'Finance & Analytics'
  | 'UI/UX Design'
  | 'Other';

export type RemoteType = 'On-site' | 'Remote' | 'Hybrid';

export interface Internship {
  id: string;
  role: string;
  company: string;
  company_logo?: string;
  location: string;
  domain: InternshipDomain;
  is_paid: boolean;
  stipend: string;
  duration: string;
  remote_type: RemoteType;
  eligible_departments: string[];
  description: string;
  requirements: string[];
  deadline: string;
  apply_url?: string;
  posted_by?: string;
  is_active: boolean;
  created_at: string;
}

export type PropertyType = 'Single Room' | '1 BHK' | '2 BHK' | '3 BHK' | 'Shared Room' | 'PG / Hostel';
export type GenderPreference = 'Boys Only' | 'Girls Only' | 'Any / Co-ed';
export type AccommodationStatus = 'pending' | 'approved' | 'rejected';

export interface Accommodation {
  id: string;
  title: string;
  description: string;
  property_type: PropertyType;
  rent: number;
  deposit: number;
  location: string;
  distance_to_campus: string;
  gender_preference: GenderPreference;
  amenities: string[];
  images: string[];
  available_from: string;
  owner_name: string;
  owner_phone: string;
  owner_whatsapp?: string;
  is_verified: boolean;
  status: AccommodationStatus;
  posted_by?: string;
  created_at: string;
}

export type EventCategory = 
  | 'Technical'
  | 'Cultural'
  | 'Sports'
  | 'Workshops'
  | 'Hackathons'
  | 'Seminars'
  | 'Alumni Talks'
  | 'Placement';

export interface CampusEvent {
  id: string;
  title: string;
  category: EventCategory;
  event_date: string;
  event_time: string;
  venue: string;
  description: string;
  cover_image: string;
  organizer: string;
  capacity: number;
  registered_count: number;
  registration_link?: string;
  is_featured: boolean;
  created_at: string;
}

export interface EventRegistration {
  id: string;
  event_id: string;
  user_id: string;
  student_roll_no?: string;
  ticket_code: string;
  status: 'confirmed' | 'cancelled' | 'attended';
  registered_at: string;
  event?: CampusEvent;
}

export interface ExamSchedule {
  id: string;
  exam_name: string;
  subject_code: string;
  subject_name: string;
  department: string;
  year: number;
  semester: number;
  exam_date: string;
  session: string;
  venue: string;
  instructions?: string;
  created_at: string;
}

export interface AlumniProfile {
  id: string;
  name: string;
  avatar_url?: string;
  department: string;
  graduation_year: number;
  current_company: string;
  position: string;
  location?: string;
  skills: string[];
  linkedin_url?: string;
  bio: string;
  available_for_mentorship: boolean;
  contact_email?: string;
  created_at: string;
}

export interface SavedItem {
  id: string;
  user_id: string;
  item_id: string;
  item_type: 'job' | 'internship' | 'event' | 'accommodation';
  created_at: string;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'opportunity' | 'event' | 'exam' | 'housing' | 'mentorship' | 'system';
  link?: string;
  is_read: boolean;
  created_at: string;
}

export interface ContentReport {
  id: string;
  item_id: string;
  item_type: 'job' | 'internship' | 'accommodation' | 'event' | 'profile';
  reason: string;
  details?: string;
  reported_by?: string;
  status: 'pending' | 'reviewed' | 'dismissed';
  created_at: string;
}

export type ResourceCategory = 
  | 'International Dual Degree'
  | 'Academic Honors'
  | 'Research Excellence'
  | 'Executive Leadership'
  | 'Global Programs';

export interface ResourceItem {
  id: string;
  title: string;
  student_name: string;
  category: ResourceCategory;
  program_type?: string;
  institution: string;
  partner_university?: string;
  current_role?: string;
  award_name?: string;
  cohort_year?: string;
  photo_url: string;
  description: string;
  tags: string[];
  external_link?: string;
  created_at: string;
}

export type CommunityChannel = 'general' | 'placement' | 'housing' | 'projects' | 'lost-found' | 'rides';

export interface CommunityComment {
  id: string;
  author_name: string;
  author_avatar?: string;
  author_role: string;
  content: string;
  created_at: string;
}

export interface CommunityPost {
  id: string;
  channel: CommunityChannel;
  title: string;
  content: string;
  author_name: string;
  author_avatar?: string;
  author_role: string;
  author_dept?: string;
  upvotes: number;
  upvoted_by: string[];
  comments: CommunityComment[];
  is_pinned?: boolean;
  created_at: string;
}

export interface CampusContact {
  id: string;
  category: 'Emergency & Health' | 'Placement & Career' | 'Hostel & Housing' | 'Academic & COE' | 'Administration';
  department_title: string;
  in_charge: string;
  phone_primary: string;
  phone_secondary?: string;
  email: string;
  location: string;
  hours: string;
}

export interface AttendanceSubject {
  id: string;
  user_id: string;
  subject_code: string;
  subject_name: string;
  faculty_name?: string;
  department: string;
  semester: number;
  classes_conducted: number;
  classes_attended: number;
  minimum_percentage: number; // default 75
  slot_schedule?: string[];
  color?: string;
  updated_at: string;
}

export type AttendanceAction = 'present' | 'absent' | 'cancelled';

export interface AttendanceLog {
  id: string;
  subject_id: string;
  user_id: string;
  date: string;
  action: AttendanceAction;
  created_at: string;
}

export interface BunkMarginResult {
  percentage: number;
  status: 'safe' | 'warning' | 'critical';
  safeBunks: number;
  requiredAttend: number;
  message: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  suggestions?: string[];
}


