'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile, UserRole } from '@/types';
import { DataStore, initializeStorageIfNeeded } from './store';
import { INITIAL_PROFILES } from './mock-data';
import { supabase, isSupabaseConfigured } from './supabase';

interface AuthContextType {
  user: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  demoLogin: (role: UserRole) => void;
  register: (profileData: Omit<UserProfile, 'id' | 'created_at'>, password?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateCurrentUserProfile: (data: Partial<UserProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize store on mount and restore user session
  useEffect(() => {
    initializeStorageIfNeeded();
    const storedUser = DataStore.getCurrentUser();
    setUser(storedUser);
    setIsLoading(false);

    // Listen for storage updates across tabs/components
    const handleStoreUpdate = () => {
      const updatedUser = DataStore.getCurrentUser();
      setUser(updatedUser);
    };

    window.addEventListener('psg_store_updated', handleStoreUpdate);
    return () => window.removeEventListener('psg_store_updated', handleStoreUpdate);
  }, []);

  const login = async (email: string, password?: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured && supabase) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password: password || 'psgconnect123',
        });
        if (error) {
          // Fallback to local profile check if Supabase test auth doesn't match
          console.warn('Supabase auth returned error, checking local store:', error.message);
        } else if (data.user) {
          const profile = DataStore.getProfiles().find((p) => p.email === email) || {
            id: data.user.id,
            full_name: data.user.user_metadata?.full_name || email.split('@')[0],
            email: data.user.email || email,
            role: (data.user.user_metadata?.role as UserRole) || 'student',
            department: data.user.user_metadata?.department || 'Computer Science and Engineering',
            batch_year: data.user.user_metadata?.batch_year || 2026,
            is_verified: true,
          };
          DataStore.setCurrentUser(profile);
          setUser(profile);
          setIsLoading(false);
          return { success: true };
        }
      }

      // Check registered profiles or match by email
      const allProfiles = DataStore.getProfiles();
      const matched = allProfiles.find((p) => p.email.toLowerCase() === email.toLowerCase());

      if (matched) {
        DataStore.setCurrentUser(matched);
        setUser(matched);
        setIsLoading(false);
        return { success: true };
      }

      // If email has @psgtech or @psg, create new student session seamlessly
      const fallbackUser: UserProfile = {
        id: `usr-${Date.now()}`,
        full_name: email.split('@')[0].replace('.', ' ').replace(/\b\w/g, (l) => l.toUpperCase()),
        email,
        role: email.includes('admin') ? 'admin' : email.includes('alumni') ? 'alumni' : 'student',
        department: 'Computer Science and Engineering',
        batch_year: 2026,
        is_verified: true,
        created_at: new Date().toISOString(),
      };
      
      const updatedProfiles = [...allProfiles, fallbackUser];
      DataStore.updateProfile(fallbackUser);
      DataStore.setCurrentUser(fallbackUser);
      setUser(fallbackUser);
      setIsLoading(false);
      return { success: true };
    } catch (err: any) {
      setIsLoading(false);
      return { success: false, error: err.message || 'Failed to login' };
    }
  };

  const demoLogin = (targetRole: UserRole) => {
    const demoProfile = INITIAL_PROFILES.find((p) => p.role === targetRole) || INITIAL_PROFILES[0];
    DataStore.setCurrentUser(demoProfile);
    setUser(demoProfile);
  };

  const register = async (
    profileData: Omit<UserProfile, 'id' | 'created_at'>,
    password?: string
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    try {
      let newId = `usr-${Date.now()}`;
      if (isSupabaseConfigured && supabase) {
        const { data, error } = await supabase.auth.signUp({
          email: profileData.email,
          password: password || 'psgconnect123',
          options: {
            data: {
              full_name: profileData.full_name,
              role: profileData.role,
              department: profileData.department,
              batch_year: profileData.batch_year,
            },
          },
        });
        if (data.user) {
          newId = data.user.id;
        }
      }

      const newProfile: UserProfile = {
        ...profileData,
        id: newId,
        is_verified: profileData.role === 'admin' ? true : false,
        created_at: new Date().toISOString(),
      };

      const profiles = [...DataStore.getProfiles(), newProfile];
      DataStore.updateProfile(newProfile);
      DataStore.setCurrentUser(newProfile);
      setUser(newProfile);

      // Add welcome notification
      DataStore.addNotification({
        user_id: newProfile.id,
        title: 'Welcome to PSG Connect+!',
        message: `Your account as a ${newProfile.role} in ${newProfile.department} has been created successfully. Explore jobs, events, and campus housing.`,
        type: 'system',
        link: '/dashboard',
      });

      setIsLoading(false);
      return { success: true };
    } catch (err: any) {
      setIsLoading(false);
      return { success: false, error: err.message || 'Registration failed' };
    }
  };

  const logout = () => {
    if (isSupabaseConfigured && supabase) {
      supabase.auth.signOut().catch(console.error);
    }
    DataStore.setCurrentUser(null);
    setUser(null);
  };

  const updateCurrentUserProfile = (data: Partial<UserProfile>) => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      ...data,
    };
    DataStore.updateProfile(updated);
    setUser(updated);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user?.role || null,
        isAuthenticated: Boolean(user),
        isLoading,
        login,
        demoLogin,
        register,
        logout,
        updateCurrentUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
