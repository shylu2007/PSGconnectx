'use client';

import {
  UserProfile,
  Job,
  Internship,
  Accommodation,
  CampusEvent,
  EventRegistration,
  ExamSchedule,
  AlumniProfile,
  SavedItem,
  NotificationItem,
  ContentReport,
  ResourceItem,
  CommunityPost,
  CampusContact,
  AttendanceSubject,
  AttendanceAction,
  BunkMarginResult,
  ChatMessage,
} from '@/types';
import {
  INITIAL_PROFILES,
  INITIAL_JOBS,
  INITIAL_INTERNSHIPS,
  INITIAL_ACCOMMODATIONS,
  INITIAL_EVENTS,
  INITIAL_EXAMS,
  INITIAL_ALUMNI,
  INITIAL_NOTIFICATIONS,
  INITIAL_RESOURCES,
  INITIAL_COMMUNITY_POSTS,
  INITIAL_CONTACTS,
  INITIAL_ATTENDANCE_SUBJECTS,
  INITIAL_CHAT_MESSAGES,
} from './mock-data';
import { supabase, isSupabaseConfigured } from './supabase';

const STORAGE_KEYS = {
  CURRENT_USER: 'psg_current_user',
  PROFILES: 'psg_profiles_v1',
  JOBS: 'psg_jobs_v1',
  INTERNSHIPS: 'psg_internships_v1',
  ACCOMMODATIONS: 'psg_accommodations_v1',
  EVENTS: 'psg_events_v1',
  REGISTRATIONS: 'psg_registrations_v1',
  EXAMS: 'psg_exams_v1',
  ALUMNI: 'psg_alumni_v1',
  SAVED_ITEMS: 'psg_saved_items_v1',
  NOTIFICATIONS: 'psg_notifications_v1',
  REPORTS: 'psg_reports_v1',
  RESOURCES: 'psg_resources_v1',
  COMMUNITY: 'psg_community_v1',
  CONTACTS: 'psg_contacts_v1',
  ATTENDANCE: 'psg_attendance_v1',
  CHAT: 'psg_chat_messages_v1',
};

// Bunk Margin & Eligibility Calculator
export function calculateBunkMargin(
  attended: number,
  conducted: number,
  target: number = 75
): BunkMarginResult {
  if (conducted <= 0) {
    return {
      percentage: 100,
      status: 'safe',
      safeBunks: 0,
      requiredAttend: 0,
      message: 'Classes have not started yet.',
    };
  }

  const percentage = Number(((attended / conducted) * 100).toFixed(1));
  const targetRatio = target / 100;

  if (percentage >= target) {
    const safeBunks = Math.floor((attended - targetRatio * conducted) / targetRatio);
    return {
      percentage,
      status: percentage >= 85 ? 'safe' : 'warning',
      safeBunks: Math.max(0, safeBunks),
      requiredAttend: 0,
      message:
        safeBunks > 0
          ? `You can safely bunk ${safeBunks} more class${safeBunks > 1 ? 'es' : ''} without falling below ${target}%.`
          : `On the border! Do not miss your next class to stay above ${target}%.`,
    };
  } else {
    const requiredAttend = Math.ceil((targetRatio * conducted - attended) / (1 - targetRatio));
    return {
      percentage,
      status: 'critical',
      safeBunks: 0,
      requiredAttend: Math.max(1, requiredAttend),
      message: `Below eligibility! You must attend the next ${requiredAttend} consecutive class${requiredAttend > 1 ? 'es' : ''} to reach ${target}%.`,
    };
  }
}

// Safe localStorage helpers
export function getStoredData<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return fallback;
  }
}

export function setStoredData<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('psg_store_updated'));
  } catch (e) {
    console.error(`Error saving ${key} to storage:`, e);
  }
}

let isSupabaseSyncInitialized = false;

// Initializer to ensure all collections exist with cloud sync
export function initializeStorageIfNeeded(): void {
  if (typeof window === 'undefined') return;

  if (!localStorage.getItem(STORAGE_KEYS.PROFILES)) {
    localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(INITIAL_PROFILES));
  }
  if (!localStorage.getItem(STORAGE_KEYS.JOBS)) {
    localStorage.setItem(STORAGE_KEYS.JOBS, JSON.stringify(INITIAL_JOBS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.INTERNSHIPS)) {
    localStorage.setItem(STORAGE_KEYS.INTERNSHIPS, JSON.stringify(INITIAL_INTERNSHIPS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ACCOMMODATIONS)) {
    localStorage.setItem(STORAGE_KEYS.ACCOMMODATIONS, JSON.stringify(INITIAL_ACCOMMODATIONS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.EVENTS)) {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(INITIAL_EVENTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.EXAMS)) {
    localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(INITIAL_EXAMS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ALUMNI)) {
    localStorage.setItem(STORAGE_KEYS.ALUMNI, JSON.stringify(INITIAL_ALUMNI));
  }
  if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.SAVED_ITEMS)) {
    const defaultSaved: SavedItem[] = [
      { id: 'save-1', user_id: 'usr-student-1', item_id: 'job-1', item_type: 'job', created_at: new Date().toISOString() },
      { id: 'save-2', user_id: 'usr-student-1', item_id: 'intern-1', item_type: 'internship', created_at: new Date().toISOString() },
      { id: 'save-3', user_id: 'usr-student-1', item_id: 'event-1', item_type: 'event', created_at: new Date().toISOString() },
    ];
    localStorage.setItem(STORAGE_KEYS.SAVED_ITEMS, JSON.stringify(defaultSaved));
  }
  if (!localStorage.getItem(STORAGE_KEYS.REGISTRATIONS)) {
    const defaultRegistrations: EventRegistration[] = [
      {
        id: 'reg-1',
        event_id: 'event-1',
        user_id: 'usr-student-1',
        student_roll_no: '22CS104',
        ticket_code: 'KRIYA-2026-789',
        status: 'confirmed',
        registered_at: '2026-08-20T10:00:00Z',
      },
    ];
    localStorage.setItem(STORAGE_KEYS.REGISTRATIONS, JSON.stringify(defaultRegistrations));
  }
  if (!localStorage.getItem(STORAGE_KEYS.RESOURCES)) {
    localStorage.setItem(STORAGE_KEYS.RESOURCES, JSON.stringify(INITIAL_RESOURCES));
  }
  if (!localStorage.getItem(STORAGE_KEYS.COMMUNITY)) {
    localStorage.setItem(STORAGE_KEYS.COMMUNITY, JSON.stringify(INITIAL_COMMUNITY_POSTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CONTACTS)) {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(INITIAL_CONTACTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ATTENDANCE)) {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(INITIAL_ATTENDANCE_SUBJECTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CHAT)) {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(INITIAL_CHAT_MESSAGES));
  }

  // Live Cloud Synchronization with Supabase
  if (isSupabaseConfigured && supabase && !isSupabaseSyncInitialized) {
    isSupabaseSyncInitialized = true;
    syncFromSupabase();
  }
}

// Fetch live database rows from Supabase and sync into memory
async function syncFromSupabase() {
  if (!supabase) return;
  try {
    // 1. Sync Internships
    const { data: dbInternships } = await supabase.from('internships').select('*').order('created_at', { ascending: false });
    if (dbInternships && dbInternships.length > 0) {
      const local = getStoredData<Internship[]>(STORAGE_KEYS.INTERNSHIPS, INITIAL_INTERNSHIPS);
      const combined = [...dbInternships, ...local.filter((l) => !dbInternships.some((d) => d.id === l.id))];
      setStoredData(STORAGE_KEYS.INTERNSHIPS, combined);
    }

    // 2. Sync Accommodations
    const { data: dbAccommodations } = await supabase.from('accommodations').select('*').order('created_at', { ascending: false });
    if (dbAccommodations && dbAccommodations.length > 0) {
      const local = getStoredData<Accommodation[]>(STORAGE_KEYS.ACCOMMODATIONS, INITIAL_ACCOMMODATIONS);
      const combined = [...dbAccommodations, ...local.filter((l) => !dbAccommodations.some((d) => d.id === l.id))];
      setStoredData(STORAGE_KEYS.ACCOMMODATIONS, combined);
    }

    // 3. Sync Community Posts
    const { data: dbPosts } = await supabase.from('community_posts').select('*').order('created_at', { ascending: false });
    if (dbPosts && dbPosts.length > 0) {
      const local = getStoredData<CommunityPost[]>(STORAGE_KEYS.COMMUNITY, INITIAL_COMMUNITY_POSTS);
      const formattedPosts = dbPosts.map((p) => ({
        ...p,
        upvotes: p.upvotes || 0,
        upvoted_by: p.upvoted_by || [],
        comments: p.comments || [],
      }));
      const combined = [...formattedPosts, ...local.filter((l) => !formattedPosts.some((d) => d.id === l.id))];
      setStoredData(STORAGE_KEYS.COMMUNITY, combined);
    }

    // 4. Sync Academic Spotlights / Resources
    const { data: dbResources } = await supabase.from('resources').select('*').order('created_at', { ascending: false });
    if (dbResources && dbResources.length > 0) {
      const local = getStoredData<ResourceItem[]>(STORAGE_KEYS.RESOURCES, INITIAL_RESOURCES);
      const combined = [...dbResources, ...local.filter((l) => !dbResources.some((d) => d.id === l.id))];
      setStoredData(STORAGE_KEYS.RESOURCES, combined);
    }

    // 5. Setup Real-time Listener for Cross-Device Sync
    supabase
      .channel('schema-db-changes')
      .on('postgres_changes', { event: '*', schema: 'public' }, () => {
        syncFromSupabase();
      })
      .subscribe();
  } catch (err) {
    console.warn('Supabase live sync notice:', err);
  }
}

// Global Store API
export const DataStore = {
  // Current User Session
  getCurrentUser: (): UserProfile | null => {
    return getStoredData<UserProfile | null>(STORAGE_KEYS.CURRENT_USER, INITIAL_PROFILES[0]);
  },
  setCurrentUser: (user: UserProfile | null): void => {
    setStoredData(STORAGE_KEYS.CURRENT_USER, user);
  },
  getProfiles: (): UserProfile[] => {
    return getStoredData<UserProfile[]>(STORAGE_KEYS.PROFILES, INITIAL_PROFILES);
  },
  updateProfile: (updatedProfile: UserProfile): void => {
    const profiles = DataStore.getProfiles().map((p) =>
      p.id === updatedProfile.id ? updatedProfile : p
    );
    setStoredData(STORAGE_KEYS.PROFILES, profiles);
    const currentUser = DataStore.getCurrentUser();
    if (currentUser?.id === updatedProfile.id) {
      DataStore.setCurrentUser(updatedProfile);
    }
  },

  // Jobs
  getJobs: (): Job[] => {
    return getStoredData<Job[]>(STORAGE_KEYS.JOBS, INITIAL_JOBS);
  },
  getJobById: (id: string): Job | undefined => {
    return DataStore.getJobs().find((j) => j.id === id);
  },
  addJob: (job: Omit<Job, 'id' | 'created_at'>): Job => {
    const newJob: Job = {
      ...job,
      id: `job-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    const jobs = [newJob, ...DataStore.getJobs()];
    setStoredData(STORAGE_KEYS.JOBS, jobs);
    return newJob;
  },
  updateJob: (updatedJob: Job): void => {
    const jobs = DataStore.getJobs().map((j) => (j.id === updatedJob.id ? updatedJob : j));
    setStoredData(STORAGE_KEYS.JOBS, jobs);
  },
  deleteJob: (id: string): void => {
    const jobs = DataStore.getJobs().filter((j) => j.id !== id);
    setStoredData(STORAGE_KEYS.JOBS, jobs);
  },

  // Internships
  getInternships: (): Internship[] => {
    return getStoredData<Internship[]>(STORAGE_KEYS.INTERNSHIPS, INITIAL_INTERNSHIPS);
  },
  getInternshipById: (id: string): Internship | undefined => {
    return DataStore.getInternships().find((i) => i.id === id);
  },
  addInternship: (internship: Omit<Internship, 'id' | 'created_at'>): Internship => {
    const newInternship: Internship = {
      ...internship,
      id: `intern-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    const internships = [newInternship, ...DataStore.getInternships()];
    setStoredData(STORAGE_KEYS.INTERNSHIPS, internships);

    // Sync to Supabase Cloud Database if configured
    if (isSupabaseConfigured && supabase) {
      supabase.from('internships').insert([
        {
          role: newInternship.role,
          company: newInternship.company,
          company_logo: newInternship.company_logo,
          location: newInternship.location,
          domain: newInternship.domain,
          is_paid: newInternship.is_paid,
          stipend: newInternship.stipend,
          duration: newInternship.duration,
          remote_type: newInternship.remote_type,
          eligible_departments: newInternship.eligible_departments,
          description: newInternship.description,
          requirements: newInternship.requirements,
          deadline: newInternship.deadline || new Date(Date.now() + 30 * 86400000).toISOString(),
          apply_url: newInternship.apply_url,
          is_active: true,
        },
      ]).then(({ error }) => {
        if (error) console.warn('Supabase internship upload error:', error);
      });
    }

    return newInternship;
  },
  updateInternship: (updatedInternship: Internship): void => {
    const internships = DataStore.getInternships().map((i) =>
      i.id === updatedInternship.id ? updatedInternship : i
    );
    setStoredData(STORAGE_KEYS.INTERNSHIPS, internships);
  },
  deleteInternship: (id: string): void => {
    const internships = DataStore.getInternships().filter((i) => i.id !== id);
    setStoredData(STORAGE_KEYS.INTERNSHIPS, internships);
  },

  // Accommodations
  getAccommodations: (): Accommodation[] => {
    return getStoredData<Accommodation[]>(STORAGE_KEYS.ACCOMMODATIONS, INITIAL_ACCOMMODATIONS);
  },
  getAccommodationById: (id: string): Accommodation | undefined => {
    return DataStore.getAccommodations().find((a) => a.id === id);
  },
  addAccommodation: (acc: Omit<Accommodation, 'id' | 'created_at'>): Accommodation => {
    const newAcc: Accommodation = {
      ...acc,
      id: `acc-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    const list = [newAcc, ...DataStore.getAccommodations()];
    setStoredData(STORAGE_KEYS.ACCOMMODATIONS, list);

    // Sync to Supabase Cloud Database if configured
    if (isSupabaseConfigured && supabase) {
      supabase.from('accommodations').insert([
        {
          title: newAcc.title,
          description: newAcc.description,
          property_type: newAcc.property_type,
          rent: newAcc.rent,
          deposit: newAcc.deposit,
          location: newAcc.location,
          distance_to_campus: newAcc.distance_to_campus,
          gender_preference: newAcc.gender_preference,
          amenities: newAcc.amenities,
          images: newAcc.images,
          owner_name: newAcc.owner_name,
          owner_phone: newAcc.owner_phone,
          owner_whatsapp: newAcc.owner_whatsapp,
          is_verified: newAcc.is_verified,
          status: newAcc.status,
        },
      ]).then(({ error }) => {
        if (error) console.warn('Supabase accommodation upload error:', error);
      });
    }

    return newAcc;
  },
  updateAccommodation: (updatedAcc: Accommodation): void => {
    const list = DataStore.getAccommodations().map((a) =>
      a.id === updatedAcc.id ? updatedAcc : a
    );
    setStoredData(STORAGE_KEYS.ACCOMMODATIONS, list);
  },
  deleteAccommodation: (id: string): void => {
    const list = DataStore.getAccommodations().filter((a) => a.id !== id);
    setStoredData(STORAGE_KEYS.ACCOMMODATIONS, list);
  },

  // Campus Events
  getEvents: (): CampusEvent[] => {
    return getStoredData<CampusEvent[]>(STORAGE_KEYS.EVENTS, INITIAL_EVENTS);
  },
  getEventById: (id: string): CampusEvent | undefined => {
    return DataStore.getEvents().find((e) => e.id === id);
  },
  addEvent: (event: Omit<CampusEvent, 'id' | 'created_at' | 'registered_count'>): CampusEvent => {
    const newEvent: CampusEvent = {
      ...event,
      id: `event-${Date.now()}`,
      registered_count: 0,
      created_at: new Date().toISOString(),
    };
    const events = [newEvent, ...DataStore.getEvents()];
    setStoredData(STORAGE_KEYS.EVENTS, events);
    return newEvent;
  },
  updateEvent: (updatedEvent: CampusEvent): void => {
    const events = DataStore.getEvents().map((e) =>
      e.id === updatedEvent.id ? updatedEvent : e
    );
    setStoredData(STORAGE_KEYS.EVENTS, events);
  },
  deleteEvent: (id: string): void => {
    const events = DataStore.getEvents().filter((e) => e.id !== id);
    setStoredData(STORAGE_KEYS.EVENTS, events);
  },

  // Event Registrations & Passes
  getUserRegistrations: (userId: string): EventRegistration[] => {
    const regs = getStoredData<EventRegistration[]>(STORAGE_KEYS.REGISTRATIONS, []);
    const events = DataStore.getEvents();
    return regs
      .filter((r) => r.user_id === userId)
      .map((r) => ({
        ...r,
        event: events.find((e) => e.id === r.event_id),
      }));
  },
  registerForEvent: (eventId: string, userId: string, rollNo?: string): EventRegistration => {
    const regs = getStoredData<EventRegistration[]>(STORAGE_KEYS.REGISTRATIONS, []);
    const existing = regs.find((r) => r.event_id === eventId && r.user_id === userId);
    if (existing) return existing;

    const event = DataStore.getEventById(eventId);
    const codePrefix = event ? event.title.slice(0, 5).toUpperCase().replace(/\s/g, '') : 'PSG';
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);

    const newReg: EventRegistration = {
      id: `reg-${Date.now()}`,
      event_id: eventId,
      user_id: userId,
      student_roll_no: rollNo || '22CS101',
      ticket_code: `${codePrefix}-${randomSuffix}`,
      status: 'confirmed',
      registered_at: new Date().toISOString(),
      event,
    };

    setStoredData(STORAGE_KEYS.REGISTRATIONS, [newReg, ...regs]);

    // Increment event registered count
    if (event) {
      DataStore.updateEvent({
        ...event,
        registered_count: event.registered_count + 1,
      });
    }

    return newReg;
  },
  cancelRegistration: (registrationId: string): void => {
    const regs = getStoredData<EventRegistration[]>(STORAGE_KEYS.REGISTRATIONS, []);
    const reg = regs.find((r) => r.id === registrationId);
    if (reg) {
      const event = DataStore.getEventById(reg.event_id);
      if (event && event.registered_count > 0) {
        DataStore.updateEvent({
          ...event,
          registered_count: event.registered_count - 1,
        });
      }
    }
    const updated = regs.filter((r) => r.id !== registrationId);
    setStoredData(STORAGE_KEYS.REGISTRATIONS, updated);
  },

  // Exam Schedules
  getExams: (): ExamSchedule[] => {
    return getStoredData<ExamSchedule[]>(STORAGE_KEYS.EXAMS, INITIAL_EXAMS);
  },
  addExam: (exam: Omit<ExamSchedule, 'id' | 'created_at'>): ExamSchedule => {
    const newExam: ExamSchedule = {
      ...exam,
      id: `exam-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    const exams = [newExam, ...DataStore.getExams()];
    setStoredData(STORAGE_KEYS.EXAMS, exams);
    return newExam;
  },
  deleteExam: (id: string): void => {
    const exams = DataStore.getExams().filter((e) => e.id !== id);
    setStoredData(STORAGE_KEYS.EXAMS, exams);
  },

  // Alumni Directory
  getAlumni: (): AlumniProfile[] => {
    return getStoredData<AlumniProfile[]>(STORAGE_KEYS.ALUMNI, INITIAL_ALUMNI);
  },
  getAlumniById: (id: string): AlumniProfile | undefined => {
    return DataStore.getAlumni().find((a) => a.id === id);
  },

  // Saved Items
  getSavedItems: (userId: string): SavedItem[] => {
    const all = getStoredData<SavedItem[]>(STORAGE_KEYS.SAVED_ITEMS, []);
    return all.filter((s) => s.user_id === userId);
  },
  isItemSaved: (itemId: string, userId: string): boolean => {
    const saved = DataStore.getSavedItems(userId);
    return saved.some((s) => s.item_id === itemId);
  },
  isSaved: (itemId: string, itemType: string, userId: string): boolean => {
    return DataStore.isItemSaved(itemId, userId);
  },
  toggleSaveItem: (itemId: string, itemType: 'job' | 'internship' | 'event' | 'accommodation', userId: string): boolean => {
    const all = getStoredData<SavedItem[]>(STORAGE_KEYS.SAVED_ITEMS, []);
    const existing = all.find((s) => s.item_id === itemId && s.user_id === userId);

    if (existing) {
      const filtered = all.filter((s) => !(s.item_id === itemId && s.user_id === userId));
      setStoredData(STORAGE_KEYS.SAVED_ITEMS, filtered);
      return false; // Removed
    } else {
      const newItem: SavedItem = {
        id: `save-${Date.now()}`,
        user_id: userId,
        item_id: itemId,
        item_type: itemType,
        created_at: new Date().toISOString(),
      };
      setStoredData(STORAGE_KEYS.SAVED_ITEMS, [newItem, ...all]);
      return true; // Added
    }
  },

  // Notifications
  getNotifications: (userId?: string): NotificationItem[] => {
    const all = getStoredData<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    if (!userId) return all;
    return all.filter((n) => n.user_id === userId || n.user_id === 'usr-student-1');
  },
  addNotification: (notif: Omit<NotificationItem, 'id' | 'created_at' | 'is_read'>): NotificationItem => {
    const newNotif: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    const list = [newNotif, ...DataStore.getNotifications()];
    setStoredData(STORAGE_KEYS.NOTIFICATIONS, list);
    return newNotif;
  },
  markNotificationAsRead: (id: string): void => {
    const list = DataStore.getNotifications().map((n) =>
      n.id === id ? { ...n, is_read: true } : n
    );
    setStoredData(STORAGE_KEYS.NOTIFICATIONS, list);
  },
  markAllNotificationsAsRead: (userId: string): void => {
    const list = DataStore.getNotifications().map((n) =>
      n.user_id === userId ? { ...n, is_read: true } : n
    );
    setStoredData(STORAGE_KEYS.NOTIFICATIONS, list);
  },
  clearNotifications: (userId: string): void => {
    const list = DataStore.getNotifications().filter((n) => n.user_id !== userId);
    setStoredData(STORAGE_KEYS.NOTIFICATIONS, list);
  },

  // Content Reports
  getReports: (): ContentReport[] => {
    return getStoredData<ContentReport[]>(STORAGE_KEYS.REPORTS, []);
  },
  addReport: (report: Omit<ContentReport, 'id' | 'created_at' | 'status'>): ContentReport => {
    const newReport: ContentReport = {
      ...report,
      id: `rep-${Date.now()}`,
      status: 'pending',
      created_at: new Date().toISOString(),
    };
    const list = [newReport, ...DataStore.getReports()];
    setStoredData(STORAGE_KEYS.REPORTS, list);
    return newReport;
  },
  updateReportStatus: (id: string, status: 'pending' | 'reviewed' | 'dismissed'): void => {
    const list = DataStore.getReports().map((r) => (r.id === id ? { ...r, status } : r));
    setStoredData(STORAGE_KEYS.REPORTS, list);
  },

  // Student Resources & Academic Spotlight (Global Degrees, Honors, Awards)
  getResources: (): ResourceItem[] => {
    return getStoredData<ResourceItem[]>(STORAGE_KEYS.RESOURCES, INITIAL_RESOURCES);
  },
  addResource: (res: Omit<ResourceItem, 'id' | 'created_at'>): ResourceItem => {
    const newRes: ResourceItem = {
      ...res,
      id: `res-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    const list = [newRes, ...DataStore.getResources()];
    setStoredData(STORAGE_KEYS.RESOURCES, list);

    if (isSupabaseConfigured && supabase) {
      supabase.from('resources').insert([
        {
          student_name: newRes.student_name,
          title: newRes.title,
          category: newRes.category,
          program_type: newRes.program_type,
          institution: newRes.institution,
          partner_university: newRes.partner_university,
          "current_role": newRes.current_role,
          award_name: newRes.award_name,
          cohort_year: newRes.cohort_year,
          photo_url: newRes.photo_url,
          description: newRes.description,
          tags: newRes.tags,
          external_link: newRes.external_link,
        },
      ]).then(({ error }) => {
        if (error) console.warn('Supabase resource upload error:', error);
      });
    }

    return newRes;
  },
  deleteResource: (id: string): void => {
    const list = DataStore.getResources().filter((r) => r.id !== id);
    setStoredData(STORAGE_KEYS.RESOURCES, list);
  },

  // Student Community Discussion Board
  getCommunityPosts: (): CommunityPost[] => {
    return getStoredData<CommunityPost[]>(STORAGE_KEYS.COMMUNITY, INITIAL_COMMUNITY_POSTS);
  },
  addCommunityPost: (post: Omit<CommunityPost, 'id' | 'created_at' | 'upvotes' | 'upvoted_by' | 'comments'>): CommunityPost => {
    const newPost: CommunityPost = {
      ...post,
      id: `post-${Date.now()}`,
      upvotes: 0,
      upvoted_by: [],
      comments: [],
      created_at: new Date().toISOString(),
    };
    const list = [newPost, ...DataStore.getCommunityPosts()];
    setStoredData(STORAGE_KEYS.COMMUNITY, list);

    if (isSupabaseConfigured && supabase) {
      supabase.from('community_posts').insert([
        {
          channel: newPost.channel,
          title: newPost.title,
          content: newPost.content,
          author_name: newPost.author_name,
          author_avatar: newPost.author_avatar,
          author_role: newPost.author_role,
          author_dept: newPost.author_dept,
          upvotes: 0,
          is_pinned: false,
        },
      ]).then(({ error }) => {
        if (error) console.warn('Supabase post upload error:', error);
      });
    }

    return newPost;
  },
  toggleUpvotePost: (postId: string, userId: string): void => {
    const list = DataStore.getCommunityPosts().map((p) => {
      if (p.id === postId) {
        const hasUpvoted = p.upvoted_by.includes(userId);
        const upvoted_by = hasUpvoted
          ? p.upvoted_by.filter((u) => u !== userId)
          : [...p.upvoted_by, userId];
        const upvotes = hasUpvoted ? p.upvotes - 1 : p.upvotes + 1;
        return { ...p, upvotes, upvoted_by };
      }
      return p;
    });
    setStoredData(STORAGE_KEYS.COMMUNITY, list);
  },
  addCommunityComment: (postId: string, comment: { author_name: string; author_role: string; content: string; author_avatar?: string }): void => {
    const list = DataStore.getCommunityPosts().map((p) => {
      if (p.id === postId) {
        const newComment = {
          id: `comment-${Date.now()}`,
          ...comment,
          created_at: new Date().toISOString(),
        };
        return {
          ...p,
          comments: [...p.comments, newComment],
        };
      }
      return p;
    });
    setStoredData(STORAGE_KEYS.COMMUNITY, list);
  },
  deleteCommunityPost: (id: string): void => {
    const list = DataStore.getCommunityPosts().filter((p) => p.id !== id);
    setStoredData(STORAGE_KEYS.COMMUNITY, list);
  },

  // Campus Contacts
  getCampusContacts: (): CampusContact[] => {
    return getStoredData<CampusContact[]>(STORAGE_KEYS.CONTACTS, INITIAL_CONTACTS);
  },
  getContacts: (): CampusContact[] => {
    return DataStore.getCampusContacts();
  },

  // Attendance Tracker Data Operations
  getAttendanceSubjects: (userId?: string): AttendanceSubject[] => {
    const all = getStoredData<AttendanceSubject[]>(STORAGE_KEYS.ATTENDANCE, INITIAL_ATTENDANCE_SUBJECTS);
    if (!userId) return all;
    return all.filter((s) => s.user_id === userId || s.user_id === 'usr-student-1');
  },
  addAttendanceSubject: (sub: Omit<AttendanceSubject, 'id' | 'updated_at'>): AttendanceSubject => {
    const newSub: AttendanceSubject = {
      ...sub,
      id: `att-${Date.now()}`,
      updated_at: new Date().toISOString(),
    };
    const list = [newSub, ...DataStore.getAttendanceSubjects()];
    setStoredData(STORAGE_KEYS.ATTENDANCE, list);
    return newSub;
  },
  updateAttendanceSubject: (sub: AttendanceSubject): void => {
    const list = DataStore.getAttendanceSubjects().map((s) => (s.id === sub.id ? { ...sub, updated_at: new Date().toISOString() } : s));
    setStoredData(STORAGE_KEYS.ATTENDANCE, list);
  },
  deleteAttendanceSubject: (id: string): void => {
    const list = DataStore.getAttendanceSubjects().filter((s) => s.id !== id);
    setStoredData(STORAGE_KEYS.ATTENDANCE, list);
  },
  logAttendance: (subjectId: string, action: AttendanceAction): AttendanceSubject | null => {
    const list = DataStore.getAttendanceSubjects();
    const sub = list.find((s) => s.id === subjectId);
    if (!sub) return null;

    let classes_conducted = sub.classes_conducted;
    let classes_attended = sub.classes_attended;

    if (action === 'present') {
      classes_conducted += 1;
      classes_attended += 1;
    } else if (action === 'absent') {
      classes_conducted += 1;
    }

    const updated: AttendanceSubject = {
      ...sub,
      classes_conducted,
      classes_attended,
      updated_at: new Date().toISOString(),
    };

    DataStore.updateAttendanceSubject(updated);
    return updated;
  },
  markAttendance: (subjectId: string, action: AttendanceAction): AttendanceSubject | null => {
    return DataStore.logAttendance(subjectId, action);
  },

  // AI Chat Messages Operations
  getChatMessages: (): ChatMessage[] => {
    return getStoredData<ChatMessage[]>(STORAGE_KEYS.CHAT, INITIAL_CHAT_MESSAGES);
  },
  addChatMessage: (msg: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage => {
    const newMsg: ChatMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    const list = [...DataStore.getChatMessages(), newMsg];
    setStoredData(STORAGE_KEYS.CHAT, list);
    return newMsg;
  },
  sendChatMessage: (content: string, sender: 'user' | 'assistant' = 'user'): ChatMessage => {
    return DataStore.addChatMessage({ content, sender });
  },
  receiveChatMessage: (content: string): ChatMessage => {
    return DataStore.addChatMessage({ content, sender: 'assistant' });
  },
  clearChatMessages: (): void => {
    setStoredData(STORAGE_KEYS.CHAT, INITIAL_CHAT_MESSAGES);
  },
  resetAllData: (): void => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEYS.PROFILES);
    localStorage.removeItem(STORAGE_KEYS.JOBS);
    localStorage.removeItem(STORAGE_KEYS.INTERNSHIPS);
    localStorage.removeItem(STORAGE_KEYS.ACCOMMODATIONS);
    localStorage.removeItem(STORAGE_KEYS.EVENTS);
    localStorage.removeItem(STORAGE_KEYS.EXAMS);
    localStorage.removeItem(STORAGE_KEYS.ALUMNI);
    localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
    localStorage.removeItem(STORAGE_KEYS.SAVED_ITEMS);
    localStorage.removeItem(STORAGE_KEYS.REGISTRATIONS);
    localStorage.removeItem(STORAGE_KEYS.RESOURCES);
    localStorage.removeItem(STORAGE_KEYS.COMMUNITY);
    localStorage.removeItem(STORAGE_KEYS.CONTACTS);
    localStorage.removeItem(STORAGE_KEYS.ATTENDANCE);
    localStorage.removeItem(STORAGE_KEYS.CHAT);
    initializeStorageIfNeeded();
    window.dispatchEvent(new Event('psg_store_updated'));
  },
};
