'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import {
  Bell,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Briefcase,
  Calendar,
  FileText,
  Home,
  Users,
  Sparkles,
} from 'lucide-react';
import { NotificationItem } from '@/types';

export default function NotificationsPage() {
  const { user } = useAuth();
  const { success, info } = useToast();

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const loadNotifications = () => {
    if (user) {
      setNotifications(DataStore.getNotifications(user.id));
    }
  };

  useEffect(() => {
    loadNotifications();
    window.addEventListener('psg_store_updated', loadNotifications);
    return () => window.removeEventListener('psg_store_updated', loadNotifications);
  }, [user]);

  const handleMarkAllRead = () => {
    if (!user) return;
    DataStore.markAllNotificationsAsRead(user.id);
    success('Updated', 'All notifications marked as read.');
  };

  const handleClearAll = () => {
    if (!user) return;
    if (confirm('Clear all notifications?')) {
      DataStore.clearNotifications(user.id);
      info('Cleared', 'Notification feed cleared.');
    }
  };

  const handleItemClick = (n: NotificationItem) => {
    if (!n.is_read) {
      DataStore.markNotificationAsRead(n.id);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'opportunity':
        return <Briefcase className="h-5 w-5 text-blue-600" />;
      case 'event':
        return <Calendar className="h-5 w-5 text-amber-600" />;
      case 'exam':
        return <FileText className="h-5 w-5 text-rose-600" />;
      case 'housing':
        return <Home className="h-5 w-5 text-emerald-600" />;
      case 'mentorship':
        return <Users className="h-5 w-5 text-purple-600" />;
      default:
        return <Sparkles className="h-5 w-5 text-slate-600" />;
    }
  };

  const filteredNotifs = notifications.filter((n) => {
    if (filter === 'unread') return !n.is_read;
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600">
              <Bell className="h-4 w-4" /> Updates & Alerts
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Notification Center
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Timely reminders for job application deadlines, exam schedules, and event tickets
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleMarkAllRead}
              className="text-xs"
            >
              Mark All Read
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearAll}
              className="text-xs text-red-600 hover:bg-red-50"
            >
              Clear All
            </Button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filter === 'all'
                ? 'bg-psg-900 text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Updates ({notifications.length})
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filter === 'unread'
                ? 'bg-psg-900 text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Unread ({notifications.filter((n) => !n.is_read).length})
          </button>
        </div>

        {/* Notifications Feed */}
        <div className="space-y-3">
          {filteredNotifs.map((n) => (
            <Card
              key={n.id}
              onClick={() => handleItemClick(n)}
              className={`p-5 transition-all cursor-pointer ${
                n.is_read
                  ? 'bg-white border-slate-200'
                  : 'bg-blue-50/80 border-blue-200 shadow-md ring-1 ring-blue-500/10'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-sm shrink-0">
                  {getIcon(n.type)}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-bold text-slate-900 text-sm">{n.title}</h3>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(n.created_at).toLocaleTimeString('en-IN', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>

                  <div className="pt-2 flex items-center justify-between">
                    <Badge variant="secondary" className="capitalize text-[10px]">
                      {n.type}
                    </Badge>
                    {n.link && (
                      <Link href={n.link} className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1">
                        View Details <ExternalLink className="h-3 w-3" />
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}

          {filteredNotifs.length === 0 && (
            <Card className="p-12 text-center text-slate-500">
              <Bell className="h-12 w-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">No notifications</h3>
              <p className="text-xs text-slate-500 mt-1">
                You are all caught up with your campus alerts.
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
