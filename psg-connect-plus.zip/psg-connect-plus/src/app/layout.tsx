import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";
import { ToastProvider } from "@/components/ui/toast";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { RoleSwitcherBanner } from "@/components/role-switcher-banner";
import { MobileNavDock } from "@/components/mobile-nav-dock";
import { CampusChatbox } from "@/components/chatbox";

export const metadata: Metadata = {
  title: "PSG Connect+ | Student & Alumni Platform for PSG Institutions",
  description:
    "Discover internships, attendance tracker, student accommodation, college events, exam schedules, and alumni mentorship for PSG Institute students.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="min-h-screen flex flex-col antialiased font-sans selection:bg-blue-600 selection:text-white bg-slate-50 text-slate-900 pb-16 md:pb-0">
        <ToastProvider>
          <AuthProvider>
            <RoleSwitcherBanner />
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
            <MobileNavDock />
            <CampusChatbox />
          </AuthProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
