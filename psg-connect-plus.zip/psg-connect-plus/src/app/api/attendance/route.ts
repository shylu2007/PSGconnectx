import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { INITIAL_ATTENDANCE_SUBJECTS } from '@/lib/mock-data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    // If Supabase is configured in environment, query PostgreSQL database
    if (supabase && process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      let query = supabase.from('attendance_subjects').select('*');
      if (userId) {
        query = query.eq('user_id', userId);
      }
      const { data, error } = await query;
      if (!error && data && data.length > 0) {
        return NextResponse.json({ success: true, data, source: 'supabase' });
      }
    }

    // Default fallback to realistic pre-seeded dataset
    return NextResponse.json({
      success: true,
      data: INITIAL_ATTENDANCE_SUBJECTS,
      source: 'cloud_dataset',
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, subjectId, subjectData } = body;

    if (supabase && process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      if (action === 'create') {
        const { data, error } = await supabase.from('attendance_subjects').insert([subjectData]).select();
        if (error) throw error;
        return NextResponse.json({ success: true, data: data[0] });
      }
      if (action === 'update') {
        const { data, error } = await supabase
          .from('attendance_subjects')
          .update(subjectData)
          .eq('id', subjectId)
          .select();
        if (error) throw error;
        return NextResponse.json({ success: true, data: data[0] });
      }
    }

    return NextResponse.json({ success: true, message: 'Updated successfully in cloud data store' });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
