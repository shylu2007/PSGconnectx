import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { message } = body;
    const q = (message || '').toLowerCase();

    let reply = '';
    let suggestions: string[] = [];

    if (q.includes('buzz') || q.includes('community') || q.includes('flatmate') || q.includes('hackathon') || q.includes('team')) {
      reply = `**PSG Campus Buzz & Student Lounge:**
• Active channels for peer discussions: **#placement**, **#housing**, **#projects**, **#lost-found**, **#rides**, **#general**.
• Find hackathon teammates for KRIYA & HackStorm, locate roommates in Peelamedu, or ask questions to placed seniors!
• Visit the **Campus Buzz** lounge to start a thread or upvote useful discussions.`;
      suggestions = ['Find Hackathon Teammates', 'Flatmate Finder in Peelamedu', 'Go to Campus Buzz'];
    } else if (q.includes('hostel') || q.includes('flat') || q.includes('pg') || q.includes('room') || q.includes('housing') || q.includes('peelamedu')) {
      reply = `**Student Housing & Accommodation around Campus:**
• We have **8+ verified listings** across Peelamedu, Hope College, and Nava India Road.
• **Single PG / Hostels:** ₹4,500 - ₹8,500/month with Wi-Fi and homely meals.
• **2 BHK Sharing Flats:** ₹14,000 - ₹18,000/month (around ₹4,500/student).
• Zero brokerage! You can directly click **WhatsApp Owner** on any listing in the **Accommodation Marketplace**.`;
      suggestions = ['Show PGs under ₹6,000', '2 BHK Flats near Hope College', 'Post a roommate request'];
    } else if (q.includes('intern') || q.includes('placement') || q.includes('zoho') || q.includes('microsoft') || q.includes('bosch') || q.includes('stipend')) {
      reply = `**Campus Internships & High-Stipend Research Openings:**
• Open domain tracks: **AI / ML**, **Software Development**, **VLSI & Embedded**, **Robotics**, **UI/UX Design**.
• High-stipend internships with monthly stipends up to ₹65,000/mo.
• Filter by remote, hybrid, or on-site formats in the **Internships Hub**!`;
      suggestions = ['View AI/ML Internships', 'High-Stipend Roles', 'Zoho SDE Internship'];
    } else if (q.includes('resource') || q.includes('note') || q.includes('pyq') || q.includes('paper') || q.includes('book')) {
      reply = `**Academic & Placement Resources:**
• Download verified interview prep guides for Microsoft, Amazon, Zoho, and Goldman Sachs.
• Solved Previous Year Question Papers (PYQs), Lab Manuals, and PSG Design Data Book indexes.
• Browse all downloads in the **Resources Hub**.`;
      suggestions = ['Microsoft SDE Interview Guide', 'Distributed Systems Solved Papers', 'Share a Resource'];
    } else if (q.includes('event') || q.includes('kriya') || q.includes('hackathon') || q.includes('workshop')) {
      reply = `**Campus Events & Symposiums:**
• **KRIYA 2026 Global Tech Fest**: 40+ events, paper presentations, and robotics arenas.
• **PSG CodeStorm 24-Hr Hackathon**: ₹1.5 Lakh cash prize pool.
• Register with 1-click and get your **Instant Digital QR Ticket Pass**!`;
      suggestions = ['Register for KRIYA 2026', 'CodeStorm Hackathon', 'View All Events'];
    } else if (q.includes('alumni') || q.includes('mentor') || q.includes('referral')) {
      reply = `**PSG Global Alumni Network:**
• Connect with verified PSG alumni leaders at Google, Tesla, NVIDIA, Microsoft, McKinsey, and venture-backed startups.
• Send 1-click **Mentorship Requests** for mock technical interviews, resume reviews, and off-campus referrals.`;
      suggestions = ['Search Alumni at Google', 'Request Mock Interview', 'Join Alumni Directory'];
    } else {
      reply = `I am your PSG Connect+ Assistant! I can help you with:
1. 🔥 **Campus Buzz & Student Lounge** (Peer discussions, flatmates & hackathon teammates)
2. 🎓 **High-Stipend Internships & Research**
3. 🏠 **Verified Housing & PGs in Peelamedu**
4. 📚 **Placement Guides, Solved PYQs & Notes**
5. 🎟️ **KRIYA 2026, Hackathons & QR Ticket Passes**
6. 🤝 **Global Alumni Mentors at FAANG & Startups**

What would you like to explore?`;
      suggestions = [
        'Open Campus Buzz Lounge',
        'Show Internships in AI/ML',
        'Find 2 BHK Flats near Peelamedu',
        'Download Placement Guides',
      ];
    }

    return NextResponse.json({
      success: true,
      reply,
      suggestions,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
