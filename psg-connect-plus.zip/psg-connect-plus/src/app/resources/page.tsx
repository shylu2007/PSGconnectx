'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import {
  Award,
  Globe2,
  GraduationCap,
  Sparkles,
  PlusCircle,
  Search,
  ExternalLink,
  Building,
  Briefcase,
  Share2,
  CheckCircle2,
  BookOpen,
} from 'lucide-react';
import { ResourceItem, ResourceCategory } from '@/types';

function ResourcesContent() {
  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [resources, setResources] = useState<ResourceItem[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSpotlight, setSelectedSpotlight] = useState<ResourceItem | null>(null);

  // Submit Modal
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<ResourceCategory>('Academic Honors');
  const [newProgramType, setNewProgramType] = useState('2+2 BS Computer Engineering');
  const [newInstitution, setNewInstitution] = useState('PSG Institute of Advanced Studies, Coimbatore');
  const [newPartnerUni, setNewPartnerUni] = useState('Binghamton University, USA');
  const [newRole, setNewRole] = useState('');
  const [newPhotoUrl, setNewPhotoUrl] = useState('/images/psg-ias-spotlight.png');
  const [newDesc, setNewDesc] = useState('');
  const [newTags, setNewTags] = useState('Honors, 2+2 Dual Degree, USA');

  const loadResources = () => {
    setResources(DataStore.getResources());
  };

  useEffect(() => {
    loadResources();
    window.addEventListener('psg_store_updated', loadResources);
    return () => window.removeEventListener('psg_store_updated', loadResources);
  }, []);

  const categories = [
    { id: 'all', label: 'All Spotlights' },
    { id: 'Academic Honors', label: 'Academic Honors' },
    { id: 'Executive Leadership', label: 'Executive Leadership' },
    { id: 'International Dual Degree', label: '2+2 & 3+1 Dual Degrees' },
    { id: 'Research Excellence', label: 'Research Excellence' },
  ];

  const filteredResources = resources.filter((res) => {
    const matchSearch =
      !search ||
      res.student_name.toLowerCase().includes(search.toLowerCase()) ||
      res.title.toLowerCase().includes(search.toLowerCase()) ||
      (res.partner_university && res.partner_university.toLowerCase().includes(search.toLowerCase())) ||
      res.description.toLowerCase().includes(search.toLowerCase()) ||
      res.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));

    const matchCategory = selectedCategory === 'all' || res.category === selectedCategory;

    return matchSearch && matchCategory;
  });

  const handleShare = (res: ResourceItem) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      success('Link Copied', `Copied link to ${res.student_name}'s spotlight.`);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName || !newTitle || !newDesc) {
      error('Missing Details', 'Please enter student name, title, and description.');
      return;
    }

    const created = DataStore.addResource({
      student_name: newStudentName.trim(),
      title: newTitle.trim(),
      category: newCategory,
      program_type: newProgramType.trim(),
      institution: newInstitution.trim(),
      partner_university: newPartnerUni.trim() || undefined,
      current_role: newRole.trim() || undefined,
      photo_url: newPhotoUrl.trim() || '/images/psg-ias-spotlight.png',
      description: newDesc.trim(),
      tags: newTags.split(',').map((t) => t.trim()).filter(Boolean),
    });

    confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
    success('Spotlight Published', `Added ${created.student_name} to academic spotlight.`);
    setIsSubmitModalOpen(false);
    setNewStudentName('');
    setNewTitle('');
    setNewDesc('');
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-8">
        {/* Hero Header */}
        <div className="rounded-3xl bg-gradient-to-r from-psg-950 via-psg-900 to-blue-900 text-white p-6 sm:p-10 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-xs font-bold text-blue-200">
              <Globe2 className="h-4 w-4 text-blue-300" /> PSG Institute of Advanced Studies & Global Programs
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif tracking-tight">
              Academic Spotlight & Global Degree Honors
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Celebrating PSGians in 2+2 & 3+1 international dual-degree cohorts, Cum Laude honors graduates, corporate directors, and world-class academic achievers.
            </p>
          </div>

          <Button
            onClick={() => setIsSubmitModalOpen(true)}
            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg rounded-2xl h-11 px-5 shrink-0"
          >
            <PlusCircle className="h-4 w-4" /> Share Student Spotlight
          </Button>
        </div>

        {/* Official PSG IAS Feature Showcase Banner */}
        <Card className="overflow-hidden border-slate-200 shadow-md bg-white rounded-3xl">
          <div className="p-6 sm:p-8 bg-gradient-to-br from-slate-50 to-blue-50/50 border-b border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-psg-900">
                <Award className="h-4 w-4 text-amber-500" /> Featured Academic Highlights
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
                PSG Institute of Advanced Studies, Coimbatore
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
                Global international tie-ups offering 2+2 BS & 3+1 BE engineering degrees in partnership with premier US universities including Binghamton University and University of Hartford.
              </p>
            </div>
            <img
              src="/images/psg-ias-spotlight.png"
              alt="PSG Institute of Advanced Studies Global Honors"
              className="w-full md:w-96 rounded-2xl shadow-md border border-slate-200 object-cover"
            />
          </div>
        </Card>

        {/* Filter Pills & Search */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-psg-900 text-white shadow-md'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
            <Input
              type="text"
              placeholder="Search student, university, honors..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 text-xs h-10 rounded-xl bg-white border-slate-200"
            />
          </div>
        </div>

        {/* Spotlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredResources.map((item) => (
            <Card
              key={item.id}
              className="overflow-hidden border border-slate-200 hover:border-blue-300 hover:shadow-xl transition-all duration-200 bg-white rounded-3xl flex flex-col justify-between"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="psg" className="text-xs font-bold">
                      {item.category}
                    </Badge>
                    {item.program_type && (
                      <Badge variant="outline" className="text-[11px] font-mono text-blue-700 bg-blue-50 border-blue-200">
                        {item.program_type}
                      </Badge>
                    )}
                  </div>
                  <button
                    onClick={() => handleShare(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                    title="Share spotlight"
                  >
                    <Share2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Main Content Layout */}
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <img
                    src={item.photo_url}
                    alt={item.student_name}
                    className="w-full sm:w-36 h-44 rounded-2xl object-cover border border-slate-200 shadow-sm shrink-0 bg-slate-100"
                  />

                  <div className="space-y-2 flex-1">
                    <h3 className="text-lg font-bold text-slate-900 leading-snug">
                      {item.student_name}
                    </h3>
                    <p className="text-xs font-semibold text-blue-700">
                      {item.title}
                    </p>
                    {item.partner_university && (
                      <p className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                        <Globe2 className="h-3.5 w-3.5 text-slate-400" />
                        {item.partner_university}
                      </p>
                    )}
                    {item.current_role && (
                      <p className="text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 p-2 rounded-xl font-medium leading-relaxed">
                        💼 {item.current_role}
                      </p>
                    )}
                    <p className="text-xs text-slate-600 leading-relaxed pt-1">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-2">
                  {item.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-medium"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>{item.institution}</span>
                <Button
                  onClick={() => setSelectedSpotlight(item)}
                  variant="ghost"
                  size="sm"
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 p-0 h-auto"
                >
                  View Details →
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredResources.length === 0 && (
          <Card className="p-12 text-center text-slate-500 bg-white rounded-3xl">
            <Award className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No spotlights found</h3>
            <p className="text-xs text-slate-500 mt-1">
              Try adjusting your search terms or select &quot;All Spotlights&quot;.
            </p>
          </Card>
        )}
      </div>

      {/* DETAIL MODAL */}
      {selectedSpotlight && (
        <Modal
          isOpen={!!selectedSpotlight}
          onClose={() => setSelectedSpotlight(null)}
          title={selectedSpotlight.student_name}
          description={selectedSpotlight.title}
          maxWidth="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <img
                src={selectedSpotlight.photo_url}
                alt={selectedSpotlight.student_name}
                className="w-full sm:w-48 h-56 rounded-2xl object-cover border border-slate-200 shadow-md"
              />
              <div className="space-y-2 flex-1">
                <Badge variant="psg" className="text-xs">{selectedSpotlight.category}</Badge>
                {selectedSpotlight.program_type && (
                  <p className="font-mono text-blue-700 font-bold">{selectedSpotlight.program_type}</p>
                )}
                <p className="text-slate-700 font-semibold">{selectedSpotlight.institution}</p>
                {selectedSpotlight.partner_university && (
                  <p className="text-slate-600">Partner University: <span className="font-bold text-slate-900">{selectedSpotlight.partner_university}</span></p>
                )}
                {selectedSpotlight.current_role && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-950 font-medium">
                    {selectedSpotlight.current_role}
                  </div>
                )}
                <p className="text-slate-700 leading-relaxed pt-2 whitespace-pre-line">
                  {selectedSpotlight.description}
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
              <Button variant="outline" size="sm" onClick={() => setSelectedSpotlight(null)}>
                Close
              </Button>
              <Button size="sm" className="bg-psg-900 text-white" onClick={() => handleShare(selectedSpotlight)}>
                Share Spotlight
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* SUBMIT MODAL */}
      {isSubmitModalOpen && (
        <Modal
          isOpen={isSubmitModalOpen}
          onClose={() => setIsSubmitModalOpen(false)}
          title="Share Student Academic Spotlight"
          description="Highlight global degrees, awards, or leadership achievements for PSG students & alumni"
          maxWidth="lg"
        >
          <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Student / Alumni Name *</label>
                <Input
                  type="text"
                  placeholder="e.g. Ms. Harshitha Babu"
                  value={newStudentName}
                  onChange={(e) => setNewStudentName(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full h-9 rounded-xl border border-slate-200 bg-white px-3 text-xs"
                >
                  <option value="Academic Honors">Academic Honors</option>
                  <option value="Executive Leadership">Executive Leadership</option>
                  <option value="International Dual Degree">International Dual Degree (2+2 / 3+1)</option>
                  <option value="Research Excellence">Research Excellence</option>
                  <option value="Global Programs">Global Programs</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Achievement Title *</label>
              <Input
                type="text"
                placeholder="e.g. Cum Laude Honors Award — Binghamton University 2+2 BS Program"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Program Mode</label>
                <Input
                  type="text"
                  placeholder="e.g. 2+2 BS Computer Engineering"
                  value={newProgramType}
                  onChange={(e) => setNewProgramType(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Partner University (if applicable)</label>
                <Input
                  type="text"
                  placeholder="e.g. Binghamton University, USA"
                  value={newPartnerUni}
                  onChange={(e) => setNewPartnerUni(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Current Role / Designation</label>
              <Input
                type="text"
                placeholder="e.g. Director, Lokesh Machines Ltd."
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Photo URL / Asset Path</label>
              <Input
                type="text"
                placeholder="/images/psg-ias-spotlight.png or https://..."
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Full Description & Story *</label>
              <Textarea
                rows={3}
                placeholder="Details about the academic honor, degree completion, or corporate leadership..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Tags (comma separated)</label>
              <Input
                type="text"
                placeholder="Honors, 2+2 Dual Degree, USA"
                value={newTags}
                onChange={(e) => setNewTags(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsSubmitModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-psg-900 text-white font-bold">
                Publish Spotlight
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function ResourcesPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading Academic Spotlight...</div>}>
      <ResourcesContent />
    </React.Suspense>
  );
}
