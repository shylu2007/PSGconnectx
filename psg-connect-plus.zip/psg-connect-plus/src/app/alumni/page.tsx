'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import {
  Users,
  Search,
  ExternalLink,
  MapPin,
  Building,
  GraduationCap,
  Sparkles,
  MessageSquare,
  PlusCircle,
  CheckCircle2,
} from 'lucide-react';
import { AlumniProfile } from '@/types';

function AlumniContent() {
  const searchParams = useSearchParams();
  const initialId = searchParams.get('id') || '';

  const { user } = useAuth();
  const { success, info } = useToast();

  const [alumni, setAlumni] = useState<AlumniProfile[]>([]);
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [selectedCompany, setSelectedCompany] = useState('all');

  // Modals
  const [selectedAlum, setSelectedAlum] = useState<AlumniProfile | null>(null);
  const [mentorshipNote, setMentorshipNote] = useState('');
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);

  const loadAlumni = () => {
    const list = DataStore.getAlumni();
    setAlumni(list);
    if (initialId) {
      const target = list.find((a) => a.id === initialId);
      if (target) setSelectedAlum(target);
    }
  };

  useEffect(() => {
    loadAlumni();
    window.addEventListener('psg_store_updated', loadAlumni);
    return () => window.removeEventListener('psg_store_updated', loadAlumni);
  }, [initialId]);

  const handleSendMentorship = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      info('Sign In Required', 'Please log in to request mentorship.');
      return;
    }
    if (!selectedAlum) return;

    DataStore.addNotification({
      user_id: user.id,
      title: `Mentorship Requested: ${selectedAlum.name}`,
      message: `Your inquiry has been dispatched to ${selectedAlum.name} (${selectedAlum.current_company}).`,
      type: 'mentorship',
      link: '/alumni',
    });

    success('Mentorship Request Sent!', `Connected with ${selectedAlum.name}. They will receive your profile note.`);
    setSelectedAlum(null);
    setMentorshipNote('');
  };

  const departments = [
    'Computer Science and Engineering',
    'Electronics and Communication Engineering',
    'Mechanical Engineering',
    'Information Technology',
    'Electrical and Electronics Engineering',
    'Production Engineering',
    'Biomedical Engineering',
    'Robotics and Automation Engineering',
    'Civil Engineering',
  ];

  const topCompanies = ['Google', 'NVIDIA', 'Tesla', 'Microsoft', 'McKinsey', 'Amazon', 'Roche', 'L&T'];

  const filteredAlumni = alumni.filter((a) => {
    const matchSearch =
      !search ||
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.current_company.toLowerCase().includes(search.toLowerCase()) ||
      a.position.toLowerCase().includes(search.toLowerCase()) ||
      a.skills.some((s) => s.toLowerCase().includes(search.toLowerCase()));

    const matchDept = selectedDept === 'all' || a.department === selectedDept;
    const matchComp =
      selectedCompany === 'all' ||
      a.current_company.toLowerCase().includes(selectedCompany.toLowerCase());

    return matchSearch && matchDept && matchComp;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-600">
              <Users className="h-4 w-4" /> Global PSG Alumni Association
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              PSG Alumni Network & Mentorship
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Connect with distinguished PSGians working at top tech firms, research laboratories, consulting giants, and venture startups
            </p>
          </div>

          <Button
            onClick={() => setIsJoinModalOpen(true)}
            className="bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
          >
            <PlusCircle className="h-4 w-4" /> Join as Alumni Mentor
          </Button>
        </div>

        {/* Filter Controls */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search */}
            <div className="relative lg:col-span-2">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search alumni by name, company, role, or skills (e.g. Google, VLSI, Tesla)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>

            {/* Department */}
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-600"
            >
              <option value="all">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            {/* Top Company Filter */}
            <select
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-600"
            >
              <option value="all">All Companies</option>
              {topCompanies.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Company Pills */}
          <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 overflow-x-auto text-xs">
            <button
              onClick={() => setSelectedCompany('all')}
              className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                selectedCompany === 'all'
                  ? 'bg-purple-700 text-white font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Companies
            </button>
            {topCompanies.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCompany(c)}
                className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                  selectedCompany === c
                    ? 'bg-purple-700 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Alumni Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAlumni.map((alum) => (
            <Card
              key={alum.id}
              className="p-5 flex flex-col justify-between hover:border-purple-300 hover:shadow-lg transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <img
                    src={alum.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'}
                    alt={alum.name}
                    className="h-16 w-16 rounded-2xl object-cover border-2 border-purple-200 shadow-sm shrink-0"
                  />
                  <div className="flex flex-col items-end">
                    <Badge variant="purple" className="text-[10px]">
                      Class of {alum.graduation_year}
                    </Badge>
                    {alum.available_for_mentorship && (
                      <span className="text-[10px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" /> Mentorship Open
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-base">{alum.name}</h3>
                  <p className="text-xs text-purple-700 font-semibold mt-0.5">
                    {alum.department.split(' ')[0]} Dept
                  </p>
                </div>

                <div className="space-y-1 my-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-900 line-clamp-1">{alum.position}</p>
                  <p className="text-xs text-slate-600 font-medium flex items-center gap-1">
                    <Building className="h-3 w-3 text-slate-400" /> {alum.current_company}
                  </p>
                  {alum.location && (
                    <p className="text-[11px] text-slate-400 flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {alum.location}
                    </p>
                  )}
                </div>

                <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed mb-4">
                  {alum.bio}
                </p>

                {/* Skills */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {alum.skills.slice(0, 3).map((s) => (
                    <span key={s} className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <Button
                  onClick={() => setSelectedAlum(alum)}
                  size="sm"
                  className="flex-1 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold"
                >
                  <MessageSquare className="h-3.5 w-3.5 mr-1" /> Connect
                </Button>
                <a
                  href={alum.linkedin_url || 'https://linkedin.com'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                  title="View LinkedIn Profile"
                >
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* CONNECT / MENTORSHIP MODAL */}
      {selectedAlum && (
        <Modal
          isOpen={Boolean(selectedAlum)}
          onClose={() => setSelectedAlum(null)}
          title={`Connect with ${selectedAlum.name}`}
          description={`${selectedAlum.position} at ${selectedAlum.current_company}`}
          maxWidth="lg"
        >
          <form onSubmit={handleSendMentorship} className="space-y-4 text-xs">
            <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-xl border border-purple-200">
              <img
                src={selectedAlum.avatar_url}
                alt={selectedAlum.name}
                className="h-12 w-12 rounded-xl object-cover"
              />
              <div>
                <p className="font-bold text-slate-900">{selectedAlum.name}</p>
                <p className="text-purple-700 font-semibold">{selectedAlum.department} (Class of {selectedAlum.graduation_year})</p>
                <p className="text-slate-500">{selectedAlum.location}</p>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">
                Write a note to {selectedAlum.name.split(' ')[0]} *
              </label>
              <Textarea
                rows={4}
                value={mentorshipNote}
                onChange={(e) => setMentorshipNote(e.target.value)}
                placeholder={`Hi ${selectedAlum.name}, I am a student at PSG Tech interested in ${selectedAlum.skills[0] || 'software engineering'}. I would love to connect for career advice and resume review.`}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSelectedAlum(null)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-purple-700 hover:bg-purple-800 text-white font-bold">
                Send Mentorship Request
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* JOIN AS ALUMNI MENTOR MODAL */}
      {isJoinModalOpen && (
        <Modal
          isOpen={isJoinModalOpen}
          onClose={() => setIsJoinModalOpen(false)}
          title="Join PSG Alumni Mentor Network"
          description="Offer guidance, review resumes, or refer juniors for placement roles"
          maxWidth="lg"
        >
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center space-y-3">
            <GraduationCap className="h-10 w-10 text-purple-700 mx-auto" />
            <h4 className="font-bold text-slate-900 text-sm">Register your Alumni Profile</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Create an account choosing the &quot;Alumni&quot; role, or update your existing profile settings with your current company and position.
            </p>
            <div className="pt-2 flex justify-center gap-3">
              <Button size="sm" variant="outline" onClick={() => setIsJoinModalOpen(false)}>
                Close
              </Button>
              <Button
                size="sm"
                className="bg-purple-700 text-white"
                onClick={() => {
                  setIsJoinModalOpen(false);
                  window.location.href = '/auth/register';
                }}
              >
                Go to Registration
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

export default function AlumniPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading Alumni Directory...</div>}>
      <AlumniContent />
    </React.Suspense>
  );
}
