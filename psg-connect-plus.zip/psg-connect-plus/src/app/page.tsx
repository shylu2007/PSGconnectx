'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Search,
  Briefcase,
  GraduationCap,
  Home,
  Calendar,
  FileText,
  Users,
  ArrowRight,
  Sparkles,
  MapPin,
  Clock,
  CheckCircle2,
  Bookmark,
  ExternalLink,
  ShieldCheck,
  Building,
  TrendingUp,
  MessageCircle,
  Phone,
  BookOpen,
  MessageSquare,
  CalendarCheck,
} from 'lucide-react';
import { DataStore } from '@/lib/store';
import { useAuth } from '@/lib/auth-context';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import { Job, Internship, CampusEvent, Accommodation, AlumniProfile, ResourceItem } from '@/types';

export default function LandingPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { success, info } = useToast();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [accommodations, setAccommodations] = useState<Accommodation[]>([]);
  const [alumni, setAlumni] = useState<AlumniProfile[]>([]);
  const [resources, setResources] = useState<ResourceItem[]>([]);
  
  const [activeOppTab, setActiveOppTab] = useState<'all' | 'jobs' | 'internships'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');

  // Modals
  const [selectedAcc, setSelectedAcc] = useState<Accommodation | null>(null);
  const [selectedAlum, setSelectedAlum] = useState<AlumniProfile | null>(null);
  const [mentorshipNote, setMentorshipNote] = useState('');

  const loadData = () => {
    setJobs(DataStore.getJobs());
    setInternships(DataStore.getInternships());
    setEvents(DataStore.getEvents());
    setAccommodations(DataStore.getAccommodations().filter((a) => a.status === 'approved'));
    setAlumni(DataStore.getAlumni());
    setResources(DataStore.getResources());
  };

  useEffect(() => {
    loadData();
    window.addEventListener('psg_store_updated', loadData);
    return () => window.removeEventListener('psg_store_updated', loadData);
  }, []);

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchKeyword.trim()) {
      router.push(`/jobs?q=${encodeURIComponent(searchKeyword.trim())}`);
    }
  };

  const handleSaveItem = (id: string, type: 'job' | 'internship' | 'event' | 'accommodation') => {
    if (!user) {
      info('Please Sign In', 'Log in to bookmark and track opportunities.');
      router.push('/auth/login');
      return;
    }
    const isNowSaved = DataStore.toggleSaveItem(id, type, user.id);
    if (isNowSaved) {
      success('Bookmark Saved', 'Opportunity added to your dashboard.');
    } else {
      info('Bookmark Removed', 'Item removed from saved list.');
    }
  };

  const handleRegisterEvent = (event: CampusEvent) => {
    if (!user) {
      info('Sign In Required', 'Please log in to register for college events.');
      router.push('/auth/login');
      return;
    }
    const reg = DataStore.registerForEvent(event.id, user.id);
    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.7 },
    });
    success('Registration Confirmed!', `Your ticket code is ${reg.ticket_code}. View in dashboard.`);
  };

  const handleSendMentorship = () => {
    if (!user) {
      router.push('/auth/login');
      return;
    }
    if (selectedAlum) {
      DataStore.addNotification({
        user_id: user.id,
        title: `Mentorship Request Sent to ${selectedAlum.name}`,
        message: `Your message to ${selectedAlum.name} (${selectedAlum.current_company}) has been dispatched.`,
        type: 'mentorship',
        link: '/alumni',
      });
      success('Inquiry Dispatched', `Mentorship request sent to ${selectedAlum.name}!`);
      setSelectedAlum(null);
      setMentorshipNote('');
    }
  };

  const quickAccessItems = [
    {
      title: 'Internships & Research',
      description: 'High-stipend summer & 6-month research roles',
      count: `${internships.length} Open`,
      icon: GraduationCap,
      color: 'bg-indigo-500/10 text-indigo-600 border-indigo-200',
      href: '/internships',
    },
    {
      title: 'Student Accommodation & PGs',
      description: 'Verified hostels, PGs & flats in Peelamedu',
      count: `${accommodations.length} Verified`,
      icon: Home,
      color: 'bg-emerald-500/10 text-emerald-600 border-emerald-200',
      href: '/accommodation',
    },
    {
      title: 'Campus Buzz Lounge',
      description: 'Student assistance, flatmates & hackathon teams',
      count: 'Active Discussions',
      icon: MessageSquare,
      color: 'bg-rose-500/10 text-rose-600 border-rose-200',
      href: '/community',
    },
    {
      title: 'Academic Spotlight & Global Honors',
      description: '2+2 & 3+1 international degrees, Cum Laude & alumni leaders',
      count: `${resources.length} Spotlights`,
      icon: BookOpen,
      color: 'bg-teal-500/10 text-teal-600 border-teal-200',
      href: '/resources',
    },
    {
      title: 'Campus Events',
      description: 'KRIYA, Hackathons, Workshops & Sports',
      count: `${events.length} Upcoming`,
      icon: Calendar,
      color: 'bg-amber-500/10 text-amber-600 border-amber-200',
      href: '/events',
    },
    {
      title: 'Alumni Network',
      description: 'Global PSGians at FAANG, Unicorns & Labs',
      count: `${alumni.length} Mentors`,
      icon: Users,
      color: 'bg-purple-500/10 text-purple-600 border-purple-200',
      href: '/alumni',
    },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50/70 via-slate-50 to-white pt-12 pb-20 border-b border-slate-200/60">
        {/* Subtle decorative background circles */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-tr from-blue-200/30 via-indigo-100/20 to-transparent blur-3xl -z-10 pointer-events-none" />

        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto space-y-6">
            {/* Campus Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-blue-200/80 shadow-sm text-xs font-semibold text-psg-900 animate-in fade-in">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Official Student & Alumni Community • PSG Institutions</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-950 font-serif leading-tight">
              Connect. Discover. <span className="gradient-text">Grow.</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              &ldquo;One platform connecting PSG students, seniors, and alumni with top-tier opportunities, verified campus housing, technical symposiums, and academic resources.&rdquo;
            </p>

            {/* Hero Quick Search Bar */}
            <form
              onSubmit={handleHeroSearch}
              className="w-full max-w-xl flex items-center gap-2 p-2 rounded-2xl bg-white border border-slate-300/80 shadow-lg shadow-blue-900/5 focus-within:border-blue-600 focus-within:ring-2 focus-within:ring-blue-100 transition-all"
            >
              <Search className="h-5 w-5 text-slate-400 ml-2 shrink-0" />
              <input
                type="text"
                placeholder="Search jobs, internships, PGs, events (e.g. Microsoft, Peelamedu)..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-full text-sm bg-transparent placeholder:text-slate-400 focus:outline-none px-2 text-slate-900"
              />
              <Button type="submit" size="sm" variant="default" className="shrink-0 px-4">
                Search
              </Button>
            </form>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <Link href="/jobs">
                <Button size="lg" className="bg-psg-900 hover:bg-psg-800 text-white shadow-md">
                  Explore Opportunities <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
              <Link href={user ? '/dashboard' : '/auth/register'}>
                <Button size="lg" variant="outline" className="border-slate-300">
                  {user ? 'Go to Dashboard' : 'Join PSG Connect+'}
                </Button>
              </Link>
            </div>

            {/* Trust Metrics */}
            <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 w-full border-t border-slate-200/80">
              <div>
                <p className="text-2xl sm:text-3xl font-extrabold text-psg-900">15,000+</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Students & Alumni</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-extrabold text-blue-600">450+</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Campus Recruiters</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600">100%</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Verified Accommodation</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-extrabold text-purple-600">₹42 LPA</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Top Placement CTC</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. QUICK ACCESS CARDS */}
      <section className="py-16 bg-white border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5" /> Quick Portals
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Everything for PSG Campus Life
              </h2>
            </div>
            <p className="text-sm text-slate-500 max-w-md">
              Instant access to curated jobs, accommodation around Peelamedu, academic calendars, and alumni mentors.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {quickAccessItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.title}
                  href={item.href}
                  className="group relative rounded-2xl border border-slate-200/90 bg-white p-6 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all duration-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 rounded-xl border ${item.color} group-hover:scale-110 transition-transform`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <Badge variant="secondary" className="font-semibold text-xs">
                        {item.count}
                      </Badge>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-600">
                    <span>Explore portal</span>
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. FEATURED OPPORTUNITIES (JOBS & INTERNSHIPS) */}
      <section className="py-16 bg-slate-50/80 border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                Placement & Career Hub
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Featured Opportunities
              </h2>
            </div>
            
            {/* Filter Pills */}
            <div className="flex items-center gap-2 bg-white p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setActiveOppTab('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeOppTab === 'all'
                    ? 'bg-psg-900 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                All Opportunities
              </button>
              <button
                onClick={() => setActiveOppTab('jobs')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeOppTab === 'jobs'
                    ? 'bg-psg-900 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Full-Time ({jobs.length})
              </button>
              <button
                onClick={() => setActiveOppTab('internships')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeOppTab === 'internships'
                    ? 'bg-psg-900 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Internships ({internships.length})
              </button>
            </div>
          </div>

          {/* Opportunities Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Jobs */}
            {(activeOppTab === 'all' || activeOppTab === 'jobs') &&
              jobs.slice(0, activeOppTab === 'jobs' ? 6 : 3).map((job) => {
                const isItemSaved = user ? DataStore.isSaved(job.id, 'job', user.id) : false;
                return (
                  <Card key={job.id} className="flex flex-col justify-between hover:border-blue-300">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-3 mb-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={job.company_logo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100'}
                            alt={job.company}
                            className="h-12 w-12 rounded-xl object-cover border border-slate-200"
                          />
                          <div>
                            <h4 className="font-bold text-slate-900 line-clamp-1">{job.title}</h4>
                            <p className="text-xs text-slate-500 font-medium">{job.company}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleSaveItem(job.id, 'job')}
                          className={`p-2 rounded-lg transition-colors ${
                            isItemSaved
                              ? 'bg-blue-50 text-blue-600'
                              : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                          }`}
                          title="Bookmark Job"
                        >
                          <Bookmark className={`h-4 w-4 ${isItemSaved ? 'fill-blue-600' : ''}`} />
                        </button>
                      </div>

                      <div className="space-y-2 mb-4 text-xs text-slate-600">
                        <p className="flex items-center gap-2">
                          <MapPin className="h-3.5 w-3.5 text-slate-400" />
                          <span>{job.location}</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
                          <span className="font-bold text-emerald-700">{job.salary}</span>
                          <span className="text-slate-400">• {job.job_type}</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          <span>Deadline: {new Date(job.deadline).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</span>
                        </p>
                      </div>

                      {/* Skills Tags */}
                      <div className="flex flex-wrap gap-1.5 mb-5">
                        {job.skills.slice(0, 3).map((skill) => (
                          <span
                            key={skill}
                            className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                        <Link href={`/jobs?id=${job.id}`} className="flex-1">
                          <Button variant="default" size="sm" className="w-full text-xs">
                            View & Apply
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

            {/* Internships */}
            {(activeOppTab === 'all' || activeOppTab === 'internships') &&
              internships.slice(0, activeOppTab === 'internships' ? 6 : 3).map((intern) => {
                const isItemSaved = user ? DataStore.isSaved(intern.id, 'internship', user.id) : false;
                return (
                  <Card key={intern.id} className="flex flex-col justify-between hover:border-indigo-300">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-3 mb-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={intern.company_logo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100'}
                            alt={intern.company}
                            className="h-12 w-12 rounded-xl object-cover border border-slate-200"
                          />
                          <div>
                            <h4 className="font-bold text-slate-900 line-clamp-1">{intern.role}</h4>
                            <p className="text-xs text-slate-500 font-medium">{intern.company}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleSaveItem(intern.id, 'internship')}
                          className={`p-2 rounded-lg transition-colors ${
                            isItemSaved
                              ? 'bg-indigo-50 text-indigo-600'
                              : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                          }`}
                          title="Bookmark Internship"
                        >
                          <Bookmark className={`h-4 w-4 ${isItemSaved ? 'fill-indigo-600' : ''}`} />
                        </button>
                      </div>

                      <div className="space-y-2 mb-4 text-xs text-slate-600">
                        <p className="flex items-center gap-2">
                          <MapPin className="h-3.5 w-3.5 text-slate-400" />
                          <span>{intern.location} ({intern.remote_type})</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                          <span className="font-bold text-indigo-700">{intern.stipend}</span>
                          <span className="text-slate-400">• {intern.duration}</span>
                        </p>
                        <p className="flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          <span>Deadline: {new Date(intern.deadline).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</span>
                        </p>
                      </div>

                      {/* Domain Badge */}
                      <div className="mb-5">
                        <Badge variant="purple" className="text-[11px]">
                          {intern.domain}
                        </Badge>
                      </div>

                      <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                        <Link href={`/internships?id=${intern.id}`} className="flex-1">
                          <Button variant="outline" size="sm" className="w-full text-xs hover:bg-indigo-50 hover:text-indigo-900 border-indigo-200">
                            View Internship
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
          </div>

          <div className="mt-10 text-center">
            <Link href="/jobs">
              <Button size="lg" variant="outline" className="border-slate-300">
                View All {jobs.length + internships.length} Opportunities <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 4. CAMPUS EVENTS SECTION */}
      <section className="py-16 bg-white border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5" /> Campus Life & Competitions
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Upcoming College Events & Fests
              </h2>
            </div>
            <Link href="/events">
              <Button variant="ghost" size="sm" className="text-blue-600">
                View All Events <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {events.slice(0, 4).map((event) => (
              <Card key={event.id} className="overflow-hidden group flex flex-col justify-between hover:border-amber-300">
                <div>
                  <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                    <img
                      src={event.cover_image}
                      alt={event.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3">
                      <Badge variant="warning" className="shadow-md">
                        {event.category}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <p className="text-xs font-bold text-amber-700 mb-1">
                      {event.event_date} • {event.event_time}
                    </p>
                    <h3 className="font-bold text-slate-900 text-base line-clamp-2 leading-tight group-hover:text-amber-700 transition-colors">
                      {event.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-2 line-clamp-2">
                      {event.description}
                    </p>
                    <p className="text-xs text-slate-400 mt-3 flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{event.venue}</span>
                    </p>
                  </CardContent>
                </div>
                <div className="p-5 pt-0">
                  <Button
                    onClick={() => handleRegisterEvent(event)}
                    size="sm"
                    variant="outline"
                    className="w-full text-xs font-semibold hover:bg-amber-50 hover:text-amber-900 border-amber-200"
                  >
                    Register for Event
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 5. ACCOMMODATION SPOTLIGHT */}
      <section className="py-16 bg-slate-50/80 border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 flex items-center gap-1.5">
                <Home className="h-3.5 w-3.5" /> Student Accommodation Marketplace
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Verified Accommodation near PSG
              </h2>
            </div>
            <Link href="/accommodation">
              <Button variant="ghost" size="sm" className="text-emerald-700">
                Browse All PGs & Flats <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {accommodations.slice(0, 4).map((acc) => (
              <Card key={acc.id} className="overflow-hidden flex flex-col justify-between hover:border-emerald-300">
                <div>
                  <div className="relative h-40 w-full overflow-hidden bg-slate-100">
                    <img
                      src={acc.images[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800'}
                      alt={acc.title}
                      className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge variant="psg" className="bg-white/95 text-slate-900 shadow">
                        {acc.property_type}
                      </Badge>
                    </div>
                    <div className="absolute bottom-3 right-3 bg-slate-950/80 backdrop-blur-sm text-white px-2.5 py-1 rounded-lg text-xs font-bold shadow">
                      ₹{acc.rent.toLocaleString('en-IN')}/mo
                    </div>
                  </div>
                  <CardContent className="p-5">
                    <h3 className="font-bold text-slate-900 text-sm line-clamp-1">
                      {acc.title}
                    </h3>
                    <p className="text-xs text-emerald-700 font-semibold mt-1">
                      📍 {acc.distance_to_campus}
                    </p>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                      {acc.location}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-1">
                      {acc.amenities.slice(0, 2).map((a) => (
                        <span key={a} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                          {a}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </div>
                <div className="p-5 pt-0">
                  <Button
                    onClick={() => setSelectedAcc(acc)}
                    size="sm"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                  >
                    Contact Owner
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 6. PSG ACADEMIC SPOTLIGHT & GLOBAL PROGRAMS */}
      <section className="py-16 bg-slate-50 border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-teal-600 flex items-center gap-1.5">
                <BookOpen className="h-3.5 w-3.5" /> PSG Institute of Advanced Studies & Global Programs
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Student Academic Spotlight & Dual Degrees
              </h2>
            </div>
            <Link href="/resources">
              <Button variant="ghost" size="sm" className="text-teal-700">
                Explore All Academic Spotlights <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resources.slice(0, 2).map((res) => (
              <Card key={res.id} className="p-6 bg-white rounded-3xl border border-slate-200 hover:border-teal-300 hover:shadow-lg transition-all flex flex-col sm:flex-row gap-5 items-start">
                <img
                  src={res.photo_url}
                  alt={res.student_name}
                  className="w-full sm:w-36 h-44 rounded-2xl object-cover border border-slate-200 shadow-sm shrink-0 bg-slate-100"
                />
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="psg" className="text-xs">{res.category}</Badge>
                    {res.program_type && (
                      <span className="text-[11px] font-mono text-teal-700 font-semibold bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                        {res.program_type}
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold text-slate-900 leading-snug">{res.student_name}</h3>
                  <p className="text-xs font-semibold text-teal-700">{res.title}</p>
                  {res.current_role && (
                    <p className="text-[11px] text-emerald-800 bg-emerald-50 border border-emerald-200 p-2 rounded-xl font-medium">
                      💼 {res.current_role}
                    </p>
                  )}
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {res.description}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 7. ALUMNI NETWORK SPOTLIGHT */}
      <section className="py-16 bg-white border-b border-slate-200/60">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-purple-600 flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5" /> Alumni Hall of Fame
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                Learn from Global PSG Leaders
              </h2>
            </div>
            <Link href="/alumni">
              <Button variant="ghost" size="sm" className="text-purple-700">
                View Full Alumni Directory <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {alumni.slice(0, 4).map((alum) => (
              <Card key={alum.id} className="p-5 flex flex-col justify-between hover:border-purple-300">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={alum.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'}
                      alt={alum.name}
                      className="h-14 w-14 rounded-2xl object-cover border-2 border-purple-200"
                    />
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{alum.name}</h3>
                      <p className="text-xs text-purple-700 font-semibold">
                        Class of {alum.graduation_year}
                      </p>
                      <p className="text-[11px] text-slate-400">{alum.department.split(' ')[0]}</p>
                    </div>
                  </div>

                  <div className="space-y-1 my-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-900">{alum.position}</p>
                    <p className="text-xs text-slate-600 font-medium">{alum.current_company}</p>
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed mb-4">
                    {alum.bio}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                  <Button
                    onClick={() => setSelectedAlum(alum)}
                    size="sm"
                    className="flex-1 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold"
                  >
                    Connect
                  </Button>
                  <a
                    href={alum.linkedin_url || 'https://linkedin.com'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                    title="View LinkedIn Profile"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 7. COMMUNITY RESOURCES BANNER */}
      <section className="py-16 bg-gradient-to-r from-psg-950 via-psg-900 to-blue-900 text-white">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <div className="max-w-2xl mx-auto space-y-5">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight font-serif">
              Ready to Accelerate Your PSG Journey?
            </h2>
            <p className="text-sm sm:text-base text-blue-200">
              Join thousands of PSGians discovering placement tips, off-campus opportunities, room share listings, and direct senior guidance.
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <Link href="/auth/register">
                <Button size="lg" className="bg-white text-psg-950 hover:bg-blue-50 font-bold shadow-xl">
                  Create Free Account
                </Button>
              </Link>
              <Link href="/exams">
                <Button size="lg" variant="outline" className="border-blue-400 text-blue-100 hover:bg-blue-800/40">
                  Check Exam Timetables
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Accommodation Contact Owner Modal */}
      {selectedAcc && (
        <Modal
          isOpen={Boolean(selectedAcc)}
          onClose={() => setSelectedAcc(null)}
          title={selectedAcc.title}
          description={`Rent: ₹${selectedAcc.rent}/mo • Deposit: ₹${selectedAcc.deposit}`}
        >
          <div className="space-y-4 text-sm">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <p className="font-semibold text-slate-900">Owner / Manager Contact:</p>
              <p className="text-slate-700 flex items-center gap-2">
                <Users className="h-4 w-4 text-slate-400" /> {selectedAcc.owner_name}
              </p>
              <p className="text-slate-700 flex items-center gap-2">
                <Phone className="h-4 w-4 text-slate-400" /> {selectedAcc.owner_phone}
              </p>
              <p className="text-slate-500 text-xs mt-1">
                📍 {selectedAcc.location} ({selectedAcc.distance_to_campus})
              </p>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {selectedAcc.description}
            </p>

            <div className="flex gap-3 pt-2">
              {selectedAcc.owner_whatsapp && (
                <a
                  href={`https://wa.me/${selectedAcc.owner_whatsapp}?text=Hi%2C%20I%20saw%20your%20PSG%20student%20listing%20for%20${encodeURIComponent(selectedAcc.title)}%20on%20PSG%20Connect%2B.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2">
                    <MessageCircle className="h-4 w-4" /> WhatsApp Owner
                  </Button>
                </a>
              )}
              <a href={`tel:${selectedAcc.owner_phone}`} className="flex-1">
                <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                  <Phone className="h-4 w-4" /> Call Phone
                </Button>
              </a>
            </div>
          </div>
        </Modal>
      )}

      {/* Alumni Mentorship Connect Modal */}
      {selectedAlum && (
        <Modal
          isOpen={Boolean(selectedAlum)}
          onClose={() => setSelectedAlum(null)}
          title={`Connect with ${selectedAlum.name}`}
          description={`${selectedAlum.position} at ${selectedAlum.current_company}`}
        >
          <div className="space-y-4 text-sm">
            <p className="text-xs text-slate-600">
              Draft a polite inquiry note regarding mentorship, placement guidance, or resume review:
            </p>
            <textarea
              rows={4}
              value={mentorshipNote}
              onChange={(e) => setMentorshipNote(e.target.value)}
              placeholder={`Hi ${selectedAlum.name}, I am a student at PSG Tech interested in your journey at ${selectedAlum.current_company}. Would love your guidance on...`}
              className="w-full rounded-xl border border-slate-300 p-3 text-xs focus:outline-none focus:ring-2 focus:ring-purple-600"
            />
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedAlum(null)}>
                Cancel
              </Button>
              <Button size="sm" className="bg-purple-700 hover:bg-purple-800 text-white" onClick={handleSendMentorship}>
                Send Mentorship Request
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
