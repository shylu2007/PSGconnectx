'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input, Textarea } from '@/components/ui/input';
import { Modal } from '@/components/ui/modal';
import {
  LayoutDashboard,
  Bookmark,
  Calendar,
  User,
  Bell,
  Briefcase,
  GraduationCap,
  Home,
  FileText,
  MapPin,
  Clock,
  Sparkles,
  ExternalLink,
  Trash2,
  QrCode,
  CheckCircle2,
  Edit3,
  ShieldCheck,
  CalendarCheck,
} from 'lucide-react';
import { Job, Internship, CampusEvent, EventRegistration, NotificationItem, AttendanceSubject } from '@/types';
import { calculateBunkMargin } from '@/lib/store';

function DashboardContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialTab = searchParams.get('tab') || 'overview';

  const { user, isAuthenticated, logout, role, updateCurrentUserProfile } = useAuth();
  const { success, info } = useToast();

  const [activeTab, setActiveTab] = useState(initialTab);
  const [attendanceSubjects, setAttendanceSubjects] = useState<AttendanceSubject[]>([]);
  const [savedJobs, setSavedJobs] = useState<Job[]>([]);
  const [savedInternships, setSavedInternships] = useState<Internship[]>([]);
  const [userRegistrations, setUserRegistrations] = useState<EventRegistration[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [recommendedJobs, setRecommendedJobs] = useState<Job[]>([]);
  const [recommendedInternships, setRecommendedInternships] = useState<Internship[]>([]);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editSkills, setEditSkills] = useState('');
  const [editLinkedin, setEditLinkedin] = useState('');
  const [editGithub, setEditGithub] = useState('');
  const [editCompany, setEditCompany] = useState('');
  const [editRole, setEditRole] = useState('');

  // Ticket Pass Modal
  const [viewTicket, setViewTicket] = useState<EventRegistration | null>(null);

  const loadUserData = () => {
    if (!user) return;

    const allJobs = DataStore.getJobs();
    const allInternships = DataStore.getInternships();
    const saved = DataStore.getSavedItems(user.id);
    const regs = DataStore.getUserRegistrations(user.id);
    const notifs = DataStore.getNotifications(user.id);
    const attendance = DataStore.getAttendanceSubjects(user.id);
    setAttendanceSubjects(attendance);

    // Filter saved
    const sJobIds = saved.filter((s) => s.item_type === 'job').map((s) => s.item_id);
    const sInternIds = saved.filter((s) => s.item_type === 'internship').map((s) => s.item_id);
    setSavedJobs(allJobs.filter((j) => sJobIds.includes(j.id)));
    setSavedInternships(allInternships.filter((i) => sInternIds.includes(i.id)));

    // Registrations
    setUserRegistrations(regs);
    setNotifications(notifs);

    // Recommended: filter by department or top active
    setRecommendedJobs(allJobs.slice(0, 3));
    setRecommendedInternships(allInternships.slice(0, 3));

    // Seed edit form
    setEditName(user.full_name || '');
    setEditPhone(user.phone || '');
    setEditBio(user.bio || '');
    setEditSkills(user.skills?.join(', ') || '');
    setEditLinkedin(user.linkedin_url || '');
    setEditGithub(user.github_url || '');
    setEditCompany(user.current_company || '');
    setEditRole(user.current_role || '');
  };

  useEffect(() => {
    if (!isAuthenticated && !user) {
      router.push('/auth/login');
      return;
    }
    loadUserData();
    window.addEventListener('psg_store_updated', loadUserData);
    return () => window.removeEventListener('psg_store_updated', loadUserData);
  }, [user, isAuthenticated]);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedSkills = editSkills.split(',').map((s) => s.trim()).filter(Boolean);
    updateCurrentUserProfile({
      full_name: editName,
      phone: editPhone,
      bio: editBio,
      skills: parsedSkills,
      linkedin_url: editLinkedin,
      github_url: editGithub,
      current_company: editCompany,
      current_role: editRole,
    });
    setIsEditingProfile(false);
    success('Profile Updated', 'Your profile details have been saved.');
  };

  const handleRemoveSaved = (itemId: string, itemType: 'job' | 'internship' | 'event' | 'accommodation') => {
    if (!user) return;
    DataStore.toggleSaveItem(itemId, itemType, user.id);
    info('Removed', 'Item removed from saved list.');
  };

  const handleCancelRegistration = (regId: string) => {
    if (confirm('Are you sure you want to cancel this event registration pass?')) {
      DataStore.cancelRegistration(regId);
      info('Registration Cancelled', 'Your seat has been released.');
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Top Header Card */}
        <div className="rounded-3xl bg-gradient-to-r from-psg-950 via-psg-900 to-blue-900 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-0 pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              {user.avatar_url ? (
                <img
                  src={user.avatar_url}
                  alt={user.full_name}
                  className="h-20 w-20 rounded-2xl object-cover ring-4 ring-white/20 shadow-lg"
                />
              ) : (
                <div className="h-20 w-20 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-2xl font-bold ring-4 ring-white/20">
                  {user.full_name.charAt(0)}
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                    Welcome back, {user.full_name}
                  </h1>
                  {user.is_verified && (
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 fill-emerald-400/20" />
                  )}
                </div>
                <p className="text-sm text-blue-200 mt-1 flex flex-wrap items-center gap-2">
                  <span className="capitalize font-semibold text-white">{user.role}</span> •{' '}
                  <span>{user.department}</span> •{' '}
                  <span>Class of {user.batch_year}</span>
                </p>
                {user.current_company && (
                  <p className="text-xs text-blue-300 mt-0.5">
                    {user.current_role} at {user.current_company}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditingProfile(true)}
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 text-xs flex items-center gap-1.5"
              >
                <Edit3 className="h-3.5 w-3.5" /> Edit Profile
              </Button>
              {role === 'admin' && (
                <Link href="/admin">
                  <Button
                    size="sm"
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1.5"
                  >
                    <ShieldCheck className="h-3.5 w-3.5" /> Admin Console
                  </Button>
                </Link>
              )}
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-white/10">
            <div className="bg-white/5 rounded-xl p-3 backdrop-blur-sm">
              <p className="text-xs text-blue-200 font-medium">Saved Bookmarks</p>
              <p className="text-2xl font-bold mt-0.5">{savedJobs.length + savedInternships.length}</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 backdrop-blur-sm">
              <p className="text-xs text-blue-200 font-medium">Registered Events</p>
              <p className="text-2xl font-bold mt-0.5">{userRegistrations.length}</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 backdrop-blur-sm">
              <p className="text-xs text-blue-200 font-medium">Unread Notifications</p>
              <p className="text-2xl font-bold mt-0.5">{notifications.filter((n) => !n.is_read).length}</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 backdrop-blur-sm">
              <p className="text-xs text-blue-200 font-medium">Account Status</p>
              <p className="text-sm font-bold text-emerald-400 mt-1 flex items-center gap-1">
                <CheckCircle2 className="h-4 w-4" /> Verified PSGian
              </p>
            </div>
          </div>
        </div>

        {/* Dashboard Tabs & Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 bg-white p-2 rounded-2xl shadow-sm overflow-x-auto">
          {[
            { id: 'overview', label: 'Overview & Recommendations', icon: LayoutDashboard },
            { id: 'saved', label: `Saved Items (${savedJobs.length + savedInternships.length})`, icon: Bookmark },
            { id: 'events', label: `My Event Passes (${userRegistrations.length})`, icon: Calendar },
            { id: 'notifications', label: `Notifications (${notifications.length})`, icon: Bell },
            { id: 'profile', label: 'My Profile', icon: User },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-psg-900 text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB CONTENT: 1. OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Recommended Jobs & Internships */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-blue-600" /> Recommended for your Department
                  </h3>
                  <Link href="/internships" className="text-xs text-blue-600 hover:underline font-semibold">
                    Explore internships →
                  </Link>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {recommendedJobs.map((job) => (
                    <Card key={job.id} className="p-5 flex flex-col justify-between hover:border-blue-300">
                      <div>
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <img
                            src={job.company_logo}
                            alt={job.company}
                            className="h-10 w-10 rounded-xl object-cover border border-slate-200"
                          />
                          <Badge variant="psg">{job.job_type}</Badge>
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm line-clamp-1">{job.title}</h4>
                        <p className="text-xs text-slate-500 font-medium">{job.company} • {job.location}</p>
                        <p className="text-xs font-bold text-emerald-700 mt-2">{job.salary}</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">
                          Deadline: {new Date(job.deadline).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                        </span>
                        <Link href={`/jobs?id=${job.id}`}>
                          <Button size="sm" variant="default" className="text-xs h-7 px-3">
                            Apply
                          </Button>
                        </Link>
                      </div>
                    </Card>
                  ))}
                  {recommendedInternships.slice(0, 2).map((intern) => (
                    <Card key={intern.id} className="p-5 flex flex-col justify-between hover:border-indigo-300">
                      <div>
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <img
                            src={intern.company_logo}
                            alt={intern.company}
                            className="h-10 w-10 rounded-xl object-cover border border-slate-200"
                          />
                          <Badge variant="purple">{intern.domain}</Badge>
                        </div>
                        <h4 className="font-bold text-slate-900 text-sm line-clamp-1">{intern.role}</h4>
                        <p className="text-xs text-slate-500 font-medium">{intern.company} • {intern.remote_type}</p>
                        <p className="text-xs font-bold text-indigo-700 mt-2">{intern.stipend}</p>
                      </div>
                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">
                          Duration: {intern.duration}
                        </span>
                        <Link href={`/internships?id=${intern.id}`}>
                          <Button size="sm" variant="outline" className="text-xs h-7 px-3 border-indigo-200">
                            Apply
                          </Button>
                        </Link>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Right Column: Upcoming Registered Events & Notifs Feed */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-amber-600" /> My Upcoming Passes
                  </h3>
                  <button
                    onClick={() => setActiveTab('events')}
                    className="text-xs text-blue-600 hover:underline font-semibold"
                  >
                    View passes
                  </button>
                </div>

                {userRegistrations.length > 0 ? (
                  <div className="space-y-3">
                    {userRegistrations.map((reg) => (
                      <Card key={reg.id} className="p-4 border-amber-200/80 bg-amber-50/30">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                              Confirmed Pass
                            </span>
                            <h4 className="font-bold text-slate-900 text-sm mt-1.5 line-clamp-1">
                              {reg.event?.title || 'Campus Event'}
                            </h4>
                            <p className="text-xs text-slate-600 mt-0.5">
                              📅 {reg.event?.event_date} ({reg.event?.event_time})
                            </p>
                            <p className="text-xs text-slate-500">
                              📍 {reg.event?.venue}
                            </p>
                          </div>
                          <button
                            onClick={() => setViewTicket(reg)}
                            className="p-2 rounded-xl bg-white border border-slate-200 shadow-sm hover:bg-slate-50 text-slate-700"
                            title="Show QR Pass"
                          >
                            <QrCode className="h-6 w-6 text-psg-900" />
                          </button>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="p-6 text-center text-slate-500">
                    <Calendar className="h-8 w-8 mx-auto text-slate-300 mb-2" />
                    <p className="text-xs">No active event registrations.</p>
                    <Link href="/events" className="mt-2 inline-block">
                      <Button size="sm" variant="outline" className="text-xs">
                        Browse College Events
                      </Button>
                    </Link>
                  </Card>
                )}

                {/* Notifications Widget */}
                <div className="space-y-3 pt-2">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Bell className="h-4 w-4 text-slate-700" /> Recent Updates
                  </h3>
                  <div className="space-y-2">
                    {notifications.slice(0, 3).map((n) => (
                      <div
                        key={n.id}
                        className={`p-3 rounded-xl border text-xs transition-colors ${
                          n.is_read ? 'bg-white border-slate-200' : 'bg-blue-50/70 border-blue-200'
                        }`}
                      >
                        <p className="font-bold text-slate-900">{n.title}</p>
                        <p className="text-slate-600 mt-0.5 leading-relaxed">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB CONTENT: 2. SAVED ITEMS */}
        {activeTab === 'saved' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-slate-900">Saved Opportunities</h3>
                <p className="text-xs text-slate-500">Jobs and internships you have bookmarked for later</p>
              </div>
            </div>

            {savedJobs.length === 0 && savedInternships.length === 0 ? (
              <Card className="p-12 text-center text-slate-500">
                <Bookmark className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-bold text-slate-800">No saved opportunities yet</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Click the bookmark icon on any job or internship card to save it to your dashboard.
                </p>
                <div className="mt-4 flex justify-center gap-3">
                  <Link href="/jobs">
                    <Button size="sm">Explore Jobs</Button>
                  </Link>
                  <Link href="/internships">
                    <Button size="sm" variant="outline">Browse Internships</Button>
                  </Link>
                </div>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedJobs.map((job) => (
                  <Card key={job.id} className="p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <img
                          src={job.company_logo}
                          alt={job.company}
                          className="h-12 w-12 rounded-xl object-cover border border-slate-200"
                        />
                        <button
                          onClick={() => handleRemoveSaved(job.id, 'job')}
                          className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50"
                          title="Remove bookmark"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <Badge variant="psg" className="mb-2">Full-Time Job</Badge>
                      <h4 className="font-bold text-slate-900 text-base">{job.title}</h4>
                      <p className="text-xs text-slate-500">{job.company} • {job.location}</p>
                      <p className="text-sm font-bold text-emerald-700 mt-2">{job.salary}</p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs text-slate-400">
                        Deadline: {new Date(job.deadline).toLocaleDateString()}
                      </span>
                      <Link href={`/jobs?id=${job.id}`}>
                        <Button size="sm" className="text-xs">Apply Now</Button>
                      </Link>
                    </div>
                  </Card>
                ))}

                {savedInternships.map((intern) => (
                  <Card key={intern.id} className="p-5 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <img
                          src={intern.company_logo}
                          alt={intern.company}
                          className="h-12 w-12 rounded-xl object-cover border border-slate-200"
                        />
                        <button
                          onClick={() => handleRemoveSaved(intern.id, 'internship')}
                          className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50"
                          title="Remove bookmark"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <Badge variant="purple" className="mb-2">Internship</Badge>
                      <h4 className="font-bold text-slate-900 text-base">{intern.role}</h4>
                      <p className="text-xs text-slate-500">{intern.company} • {intern.remote_type}</p>
                      <p className="text-sm font-bold text-indigo-700 mt-2">{intern.stipend}</p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs text-slate-400">
                        Duration: {intern.duration}
                      </span>
                      <Link href={`/internships?id=${intern.id}`}>
                        <Button size="sm" variant="outline" className="text-xs border-indigo-200">
                          Apply Now
                        </Button>
                      </Link>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB CONTENT: 3. EVENT PASSES */}
        {activeTab === 'events' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-slate-900">Campus Event Passes</h3>
                <p className="text-xs text-slate-500">Your verified digital entry passes and workshop tickets</p>
              </div>
              <Link href="/events">
                <Button size="sm" variant="outline">
                  Browse More Events
                </Button>
              </Link>
            </div>

            {userRegistrations.length === 0 ? (
              <Card className="p-12 text-center text-slate-500">
                <Calendar className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-bold text-slate-800">No event passes registered</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Register for KRIYA, technical symposiums, coding hackathons, or guest talks.
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {userRegistrations.map((reg) => (
                  <Card key={reg.id} className="p-6 border-2 border-slate-200 relative overflow-hidden bg-white shadow-md">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-dashed border-slate-200">
                      <div>
                        <Badge variant="success" className="text-[10px]">
                          CONFIRMED DELEGATE PASS
                        </Badge>
                        <h4 className="font-extrabold text-slate-900 text-lg mt-1">
                          {reg.event?.title || 'College Event'}
                        </h4>
                        <p className="text-xs text-slate-500 font-medium">
                          Organized by {reg.event?.organizer || 'PSG Students Union'}
                        </p>
                      </div>
                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-center shrink-0">
                        <QrCode className="h-12 w-12 text-psg-900 mx-auto" />
                        <p className="text-[10px] font-mono font-bold text-slate-600 mt-1">{reg.ticket_code}</p>
                      </div>
                    </div>

                    <div className="py-4 grid grid-cols-2 gap-3 text-xs text-slate-600">
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Attendee Name</span>
                        <span className="font-bold text-slate-900">{user.full_name}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Roll / Delegate No</span>
                        <span className="font-mono font-bold text-slate-900">{reg.student_roll_no || '22CS104'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Event Date & Time</span>
                        <span className="font-semibold text-slate-900">{reg.event?.event_date} ({reg.event?.event_time})</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Venue Allocation</span>
                        <span className="font-semibold text-slate-900">{reg.event?.venue}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCancelRegistration(reg.id)}
                        className="text-xs text-red-600 hover:bg-red-50"
                      >
                        Cancel Registration
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setViewTicket(reg)}
                        className="text-xs"
                      >
                        Enlarge Pass View
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB CONTENT: 4. NOTIFICATIONS */}
        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-slate-900">System & Opportunity Notifications</h3>
                <p className="text-xs text-slate-500">Exam schedules, job updates, and mentorship alerts</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  DataStore.markAllNotificationsAsRead(user.id);
                  loadUserData();
                  success('All Read', 'Marked all notifications as read.');
                }}
                className="text-xs"
              >
                Mark All Read
              </Button>
            </div>

            <div className="space-y-3">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-4 ${
                    notif.is_read ? 'bg-white border-slate-200' : 'bg-blue-50/80 border-blue-200 shadow-sm'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-slate-900 text-sm">{notif.title}</p>
                      {!notif.is_read && (
                        <span className="h-2 w-2 rounded-full bg-blue-600" />
                      )}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{notif.message}</p>
                    <p className="text-[10px] text-slate-400 pt-1">
                      {new Date(notif.created_at).toLocaleString('en-IN')}
                    </p>
                  </div>
                  {notif.link && (
                    <Link href={notif.link}>
                      <Button size="sm" variant="ghost" className="text-xs text-blue-600">
                        View <ExternalLink className="h-3 w-3 ml-1" />
                      </Button>
                    </Link>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB CONTENT: 5. PROFILE */}
        {activeTab === 'profile' && (
          <Card className="max-w-2xl mx-auto shadow-md">
            <CardHeader>
              <CardTitle className="text-lg">Profile Details</CardTitle>
              <CardDescription className="text-xs">
                Manage your student or alumni contact information and skills
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">Full Name</label>
                    <Input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">Phone Number</label>
                    <Input
                      type="tel"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      className="text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">Department (Fixed)</label>
                    <Input type="text" value={user.department} disabled className="text-xs bg-slate-100" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">Batch Year (Fixed)</label>
                    <Input type="text" value={user.batch_year} disabled className="text-xs bg-slate-100" />
                  </div>
                </div>

                {role === 'alumni' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-purple-50 rounded-xl border border-purple-200">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-purple-950">Current Company</label>
                      <Input
                        type="text"
                        value={editCompany}
                        onChange={(e) => setEditCompany(e.target.value)}
                        className="text-xs bg-white"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-purple-950">Current Role</label>
                      <Input
                        type="text"
                        value={editRole}
                        onChange={(e) => setEditRole(e.target.value)}
                        className="text-xs bg-white"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Skills (Comma separated)</label>
                  <Input
                    type="text"
                    value={editSkills}
                    onChange={(e) => setEditSkills(e.target.value)}
                    className="text-xs"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">LinkedIn URL</label>
                    <Input
                      type="url"
                      value={editLinkedin}
                      onChange={(e) => setEditLinkedin(e.target.value)}
                      className="text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-700">GitHub / Portfolio URL</label>
                    <Input
                      type="url"
                      value={editGithub}
                      onChange={(e) => setEditGithub(e.target.value)}
                      className="text-xs"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Bio</label>
                  <Textarea
                    rows={3}
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    className="text-xs"
                  />
                </div>

                <Button type="submit" className="w-full bg-psg-900 hover:bg-psg-800 text-white text-xs font-bold">
                  Save Changes
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Ticket Pass Modal */}
      {viewTicket && (
        <Modal
          isOpen={Boolean(viewTicket)}
          onClose={() => setViewTicket(null)}
          title="PSG Delegate Pass"
          description="Present this QR pass at the entrance registration desk."
          maxWidth="md"
        >
          <div className="p-6 bg-slate-900 text-white rounded-2xl text-center space-y-4 shadow-xl">
            <Badge variant="warning" className="text-xs font-bold">
              {viewTicket.event?.category || 'CAMPUS EVENT'}
            </Badge>
            <h3 className="text-xl font-black font-serif">
              {viewTicket.event?.title}
            </h3>
            
            <div className="bg-white p-4 rounded-2xl inline-block shadow-inner mx-auto my-2">
              <QrCode className="h-36 w-36 text-slate-950" />
            </div>

            <p className="font-mono text-sm tracking-widest text-emerald-400 font-bold">
              {viewTicket.ticket_code}
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 pt-3 border-t border-slate-800 text-left">
              <div>
                <span className="text-slate-400 text-[10px] block">Attendee</span>
                <span className="font-bold text-white">{user.full_name}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Venue</span>
                <span className="font-bold text-white">{viewTicket.event?.venue}</span>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Profile Edit Quick Modal */}
      {isEditingProfile && (
        <Modal
          isOpen={isEditingProfile}
          onClose={() => setIsEditingProfile(false)}
          title="Edit Profile"
          description="Update your contact information and skills"
          maxWidth="lg"
        >
          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Full Name</label>
              <Input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="text-xs"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Phone</label>
              <Input
                type="tel"
                value={editPhone}
                onChange={(e) => setEditPhone(e.target.value)}
                className="text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Skills (Comma separated)</label>
              <Input
                type="text"
                value={editSkills}
                onChange={(e) => setEditSkills(e.target.value)}
                className="text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Bio</label>
              <Textarea
                rows={3}
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                className="text-xs"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsEditingProfile(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-psg-900 text-white">
                Save Profile
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading PSG Dashboard...</div>}>
      <DashboardContent />
    </React.Suspense>
  );
}
