'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore, calculateBunkMargin } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import {
  CalendarCheck,
  Check,
  X as XIcon,
  AlertTriangle,
  PlusCircle,
  TrendingUp,
  Percent,
  Sparkles,
  RotateCcw,
  BookOpen,
  Clock,
  Trash2,
  Edit2,
  ShieldCheck,
  Info,
  Calendar,
} from 'lucide-react';
import { AttendanceSubject, AttendanceAction } from '@/types';

function AttendanceContent() {
  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [subjects, setSubjects] = useState<AttendanceSubject[]>([]);
  const [targetPercentage, setTargetPercentage] = useState<number>(75);
  const [activeTab, setActiveTab] = useState<'subjects' | 'timetable'>('subjects');

  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newFaculty, setNewFaculty] = useState('');
  const [newConducted, setNewConducted] = useState(30);
  const [newAttended, setNewAttended] = useState(26);
  const [newColor, setNewColor] = useState('blue');

  const loadSubjects = () => {
    setSubjects(DataStore.getAttendanceSubjects(user?.id));
  };

  useEffect(() => {
    loadSubjects();
    window.addEventListener('psg_store_updated', loadSubjects);
    return () => window.removeEventListener('psg_store_updated', loadSubjects);
  }, [user]);

  // Calculations
  const totalConducted = subjects.reduce((acc, s) => acc + s.classes_conducted, 0);
  const totalAttended = subjects.reduce((acc, s) => acc + s.classes_attended, 0);
  const overallPercentage =
    totalConducted > 0 ? Number(((totalAttended / totalConducted) * 100).toFixed(1)) : 100;
  const overallMargin = calculateBunkMargin(totalAttended, totalConducted, targetPercentage);

  const handleMark = (subjectId: string, action: AttendanceAction, subName: string) => {
    const updated = DataStore.markAttendance(subjectId, action);
    if (updated) {
      const margin = calculateBunkMargin(
        updated.classes_attended,
        updated.classes_conducted,
        updated.minimum_percentage
      );

      if (action === 'present') {
        success('Marked Present', `${subName}: Now at ${margin.percentage}% attendance.`);
      } else if (action === 'absent') {
        info('Marked Absent', `${subName}: Now at ${margin.percentage}%. ${margin.message}`);
      } else {
        info('Class Cancelled', `${subName}: Timetable adjusted.`);
      }
    }
  };

  const handleAddSubjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !newName) {
      error('Missing Details', 'Please provide subject code and name.');
      return;
    }

    const created = DataStore.addAttendanceSubject({
      user_id: user?.id || 'usr-student-1',
      subject_code: newCode.toUpperCase().trim(),
      subject_name: newName.trim(),
      faculty_name: newFaculty.trim() || undefined,
      department: user?.department || 'Computer Science and Engineering',
      semester: 5,
      classes_conducted: Number(newConducted),
      classes_attended: Number(newAttended),
      minimum_percentage: targetPercentage,
      color: newColor,
      slot_schedule: ['Mon Period 2', 'Wed Period 4'],
    });

    confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
    success('Subject Added', `Tracking ${created.subject_code} - ${created.subject_name}`);
    setIsAddModalOpen(false);
    setNewCode('');
    setNewName('');
    setNewFaculty('');
  };

  const handleDeleteSubject = (id: string, name: string) => {
    if (confirm(`Remove tracking for ${name}?`)) {
      DataStore.deleteAttendanceSubject(id);
      info('Subject Removed', `Deleted ${name} from attendance tracker.`);
    }
  };

  const getColorTheme = (color?: string) => {
    switch (color) {
      case 'emerald':
        return { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', bar: 'bg-emerald-500' };
      case 'purple':
        return { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', bar: 'bg-purple-500' };
      case 'rose':
        return { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', bar: 'bg-rose-500' };
      case 'amber':
        return { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', bar: 'bg-amber-500' };
      case 'indigo':
        return { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', bar: 'bg-indigo-500' };
      default:
        return { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', bar: 'bg-blue-600' };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header Banner */}
        <div className="rounded-3xl bg-gradient-to-r from-psg-950 via-psg-900 to-blue-900 text-white p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <CalendarCheck className="h-4 w-4" /> PSG Academic Regulations
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold font-serif tracking-tight">
              Attendance Tracker & Bunk Calculator
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
              Track course eligibility, calculate safe bunks, and stay comfortably above the mandatory PSG 75% threshold.
            </p>
          </div>

          {/* Overall Dial Box */}
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 shrink-0">
            <div className="text-center">
              <p className="text-[10px] uppercase font-bold text-slate-300">Overall Attendance</p>
              <p className="text-3xl font-black text-white mt-0.5">{overallPercentage}%</p>
              <Badge
                variant={
                  overallPercentage >= 85
                    ? 'success'
                    : overallPercentage >= 75
                    ? 'warning'
                    : 'destructive'
                }
                className="text-[10px] mt-1"
              >
                {overallPercentage >= 75 ? 'Exam Eligible' : 'Below 75% Limit'}
              </Badge>
            </div>
            <div className="h-12 w-px bg-white/20" />
            <div className="text-xs space-y-1 text-slate-300">
              <p>Attended: <span className="font-bold text-white">{totalAttended}</span></p>
              <p>Conducted: <span className="font-bold text-white">{totalConducted}</span></p>
              <p>Missed: <span className="font-bold text-rose-300">{totalConducted - totalAttended}</span></p>
            </div>
          </div>
        </div>

        {/* Global Regulation Notice & Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <Card className="lg:col-span-3 p-4 bg-blue-50/80 border-blue-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-blue-950">PSG Rule: 75% Minimum Required for End-Sem Hall Ticket</p>
                <p className="text-[11px] text-blue-800 leading-relaxed mt-0.5">
                  {overallMargin.message}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-semibold text-slate-600">Threshold:</span>
              <select
                value={targetPercentage}
                onChange={(e) => setTargetPercentage(Number(e.target.value))}
                className="h-8 rounded-lg border border-blue-300 bg-white px-2 text-xs font-bold text-blue-900"
              >
                <option value={75}>75% (PSG Standard)</option>
                <option value={80}>80% (Safe Buffer)</option>
                <option value={85}>85% (Placement Cutoff)</option>
              </select>
            </div>
          </Card>

          <Button
            onClick={() => setIsAddModalOpen(true)}
            className="h-full min-h-[52px] bg-psg-900 hover:bg-psg-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm rounded-2xl"
          >
            <PlusCircle className="h-4 w-4" /> Add New Course
          </Button>
        </div>

        {/* Subjects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((sub) => {
            const margin = calculateBunkMargin(
              sub.classes_attended,
              sub.classes_conducted,
              sub.minimum_percentage || targetPercentage
            );
            const theme = getColorTheme(sub.color);

            return (
              <Card
                key={sub.id}
                className={`p-6 flex flex-col justify-between hover:shadow-lg transition-all duration-200 border-2 ${
                  margin.status === 'critical'
                    ? 'border-rose-300 bg-rose-50/20'
                    : margin.status === 'warning'
                    ? 'border-amber-300 bg-amber-50/20'
                    : 'border-slate-200 bg-white'
                }`}
              >
                <div>
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <Badge variant="outline" className={`font-mono text-xs font-bold ${theme.bg} ${theme.text} ${theme.border}`}>
                        {sub.subject_code}
                      </Badge>
                      <h3 className="font-bold text-slate-900 text-base leading-snug mt-1.5">
                        {sub.subject_name}
                      </h3>
                      {sub.faculty_name && (
                        <p className="text-[11px] text-slate-400 mt-0.5">{sub.faculty_name}</p>
                      )}
                    </div>

                    <div className="text-right">
                      <p
                        className={`text-2xl font-black ${
                          margin.percentage >= 75 ? 'text-slate-900' : 'text-rose-600'
                        }`}
                      >
                        {margin.percentage}%
                      </p>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {sub.classes_attended} / {sub.classes_conducted} Classes
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden my-3">
                    <div
                      className={`h-full transition-all duration-500 ${
                        margin.percentage >= 85
                          ? 'bg-emerald-500'
                          : margin.percentage >= 75
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, margin.percentage)}%` }}
                    />
                  </div>

                  {/* Bunk Margin Calculator Box */}
                  <div
                    className={`p-3 rounded-xl text-xs leading-relaxed mb-4 border ${
                      margin.status === 'safe'
                        ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                        : margin.status === 'warning'
                        ? 'bg-amber-50 text-amber-900 border-amber-200'
                        : 'bg-rose-50 text-rose-900 border-rose-200'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold mb-0.5">
                      {margin.status === 'safe' && <Sparkles className="h-3.5 w-3.5 text-emerald-600" />}
                      {margin.status === 'warning' && <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />}
                      {margin.status === 'critical' && <AlertTriangle className="h-3.5 w-3.5 text-rose-600" />}
                      <span>
                        {margin.status === 'safe'
                          ? 'Safe to Bunk'
                          : margin.status === 'warning'
                          ? 'Tight Margin'
                          : 'Attendance Shortage!'}
                      </span>
                    </div>
                    <p className="text-[11px]">{margin.message}</p>
                  </div>
                </div>

                {/* Bottom Quick-Action Buttons */}
                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <div className="grid grid-cols-3 gap-1.5">
                    <Button
                      onClick={() => handleMark(sub.id, 'present', sub.subject_code)}
                      size="sm"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-8 px-1 flex items-center justify-center gap-1"
                    >
                      <Check className="h-3.5 w-3.5" /> Present
                    </Button>
                    <Button
                      onClick={() => handleMark(sub.id, 'absent', sub.subject_code)}
                      size="sm"
                      variant="outline"
                      className="border-rose-300 text-rose-700 hover:bg-rose-50 font-bold text-xs h-8 px-1 flex items-center justify-center gap-1"
                    >
                      <XIcon className="h-3.5 w-3.5" /> Absent
                    </Button>
                    <Button
                      onClick={() => handleMark(sub.id, 'cancelled', sub.subject_code)}
                      size="sm"
                      variant="ghost"
                      className="text-slate-500 hover:bg-slate-100 text-[11px] h-8 px-1"
                    >
                      Cancelled
                    </Button>
                  </div>

                  <div className="flex items-center justify-between pt-1 text-[10px] text-slate-400">
                    <span>Target: {sub.minimum_percentage}%</span>
                    <button
                      onClick={() => handleDeleteSubject(sub.id, sub.subject_name)}
                      className="text-slate-400 hover:text-rose-600 flex items-center gap-1"
                    >
                      <Trash2 className="h-3 w-3" /> Remove
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {subjects.length === 0 && (
          <Card className="p-12 text-center text-slate-500">
            <CalendarCheck className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No subjects currently tracked</h3>
            <p className="text-xs text-slate-500 mt-1">
              Click &quot;Add New Course&quot; to begin tracking your attendance and calculating bunk limits.
            </p>
          </Card>
        )}
      </div>

      {/* ADD SUBJECT MODAL */}
      {isAddModalOpen && (
        <Modal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          title="Track New PSG Course"
          description="Enter your subject details to automatically calculate attendance and bunk limits"
          maxWidth="md"
        >
          <form onSubmit={handleAddSubjectSubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Course Code *</label>
                <Input
                  type="text"
                  placeholder="e.g. 21CS501"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  required
                  className="text-xs uppercase font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Faculty Name</label>
                <Input
                  type="text"
                  placeholder="e.g. Dr. G. Sudha"
                  value={newFaculty}
                  onChange={(e) => setNewFaculty(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Course Title *</label>
              <Input
                type="text"
                placeholder="e.g. Distributed Systems & Cloud Computing"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Classes Conducted So Far</label>
                <Input
                  type="number"
                  min={0}
                  value={newConducted}
                  onChange={(e) => setNewConducted(Number(e.target.value))}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Classes Attended</label>
                <Input
                  type="number"
                  min={0}
                  max={newConducted}
                  value={newAttended}
                  onChange={(e) => setNewAttended(Number(e.target.value))}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Card Color Accent</label>
              <div className="flex items-center gap-2 pt-1">
                {['blue', 'emerald', 'purple', 'amber', 'rose', 'indigo'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNewColor(c)}
                    className={`h-6 w-6 rounded-full border-2 transition-all ${
                      newColor === c ? 'scale-125 border-slate-900' : 'border-transparent'
                    } ${
                      c === 'blue'
                        ? 'bg-blue-500'
                        : c === 'emerald'
                        ? 'bg-emerald-500'
                        : c === 'purple'
                        ? 'bg-purple-500'
                        : c === 'amber'
                        ? 'bg-amber-500'
                        : c === 'rose'
                        ? 'bg-rose-500'
                        : 'bg-indigo-500'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsAddModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-psg-900 text-white font-bold">
                Start Tracking
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function AttendancePage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading PSG Attendance Tracker...</div>}>
      <AttendanceContent />
    </React.Suspense>
  );
}
