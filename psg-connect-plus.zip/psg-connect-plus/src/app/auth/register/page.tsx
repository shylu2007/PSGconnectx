'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { GraduationCap, ArrowRight, UserCheck, CheckCircle2 } from 'lucide-react';
import { UserRole } from '@/types';

export default function RegisterPage() {
  const router = useRouter();
  const { register } = useAuth();
  const { success, error } = useToast();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [department, setDepartment] = useState('Computer Science and Engineering');
  const [batchYear, setBatchYear] = useState<number>(2026);
  const [phone, setPhone] = useState('');
  const [currentCompany, setCurrentCompany] = useState('');
  const [currentRole, setCurrentRole] = useState('');
  const [skills, setSkills] = useState('');
  const [bio, setBio] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const departments = [
    'Computer Science and Engineering',
    'Information Technology',
    'Artificial Intelligence and Data Science',
    'Electronics and Communication Engineering',
    'Electrical and Electronics Engineering',
    'Mechanical Engineering',
    'Production Engineering',
    'Robotics and Automation Engineering',
    'Biomedical Engineering',
    'Civil Engineering',
    'Metallurgical Engineering',
    'Apparel and Fashion Design',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !password) {
      error('Missing Information', 'Please fill in your name, email and password.');
      return;
    }

    setIsLoading(true);
    const parsedSkills = skills
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const res = await register(
      {
        full_name: fullName,
        email,
        role,
        department,
        batch_year: Number(batchYear),
        phone: phone || undefined,
        current_company: currentCompany || undefined,
        current_role: currentRole || undefined,
        skills: parsedSkills.length > 0 ? parsedSkills : ['Full-Stack', 'Problem Solving'],
        bio: bio || `PSG ${department} student (Class of ${batchYear}).`,
        avatar_url: `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=003366&color=fff`,
      },
      password
    );

    setIsLoading(false);
    if (res.success) {
      success('Account Created!', 'Welcome to PSG Connect+ community.');
      router.push('/dashboard');
    } else {
      error('Registration Failed', res.error || 'Could not complete registration.');
    }
  };

  return (
    <div className="min-h-[90vh] py-10 px-4 sm:px-6 bg-slate-50 flex items-center justify-center">
      <div className="w-full max-w-xl space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex h-12 w-12 rounded-2xl bg-gradient-to-br from-psg-900 to-blue-700 items-center justify-center text-white shadow-lg mx-auto">
            <GraduationCap className="h-7 w-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 font-serif">
            Join PSG Connect+
          </h1>
          <p className="text-xs text-slate-500">
            Create your verified student or alumni profile in 2 minutes
          </p>
        </div>

        <Card className="shadow-xl border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Registration Form</CardTitle>
            <CardDescription className="text-xs">
              Connect with fellow students, seniors, and campus opportunities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Role Toggle */}
              <div>
                <label className="text-xs font-semibold text-slate-700 mb-1.5 block">
                  I am registering as:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('student')}
                    className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      role === 'student'
                        ? 'border-blue-600 bg-blue-50 text-blue-900 ring-2 ring-blue-500/20'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <GraduationCap className="h-4 w-4 text-blue-600" />
                    <span>Current Student</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('alumni')}
                    className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      role === 'alumni'
                        ? 'border-purple-600 bg-purple-50 text-purple-900 ring-2 ring-purple-500/20'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <UserCheck className="h-4 w-4 text-purple-600" />
                    <span>PSG Alumni</span>
                  </button>
                </div>
              </div>

              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Full Name *</label>
                  <Input
                    type="text"
                    placeholder="e.g. Vignesh Sundar"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className="text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Email Address *</label>
                  <Input
                    type="email"
                    placeholder="name@psgtech.ac.in"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="text-xs"
                  />
                </div>
              </div>

              {/* Password & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Password *</label>
                  <Input
                    type="password"
                    placeholder="At least 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Phone Number</label>
                  <Input
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              {/* Department & Batch Year */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Department *</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-psg-700 text-slate-800"
                  >
                    {departments.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">
                    {role === 'student' ? 'Graduation Year' : 'Passout Year'} *
                  </label>
                  <select
                    value={batchYear}
                    onChange={(e) => setBatchYear(Number(e.target.value))}
                    className="w-full h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-psg-700 text-slate-800"
                  >
                    {[2028, 2027, 2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015].map(
                      (yr) => (
                        <option key={yr} value={yr}>
                          {yr}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              {/* Alumni-specific company fields */}
              {role === 'alumni' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-purple-50/60 rounded-xl border border-purple-200/60">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-purple-950">Current Company</label>
                    <Input
                      type="text"
                      placeholder="e.g. Google, Microsoft, Zoho"
                      value={currentCompany}
                      onChange={(e) => setCurrentCompany(e.target.value)}
                      className="text-xs bg-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-purple-950">Job Role / Position</label>
                    <Input
                      type="text"
                      placeholder="e.g. Senior Software Engineer"
                      value={currentRole}
                      onChange={(e) => setCurrentRole(e.target.value)}
                      className="text-xs bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Skills */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">Skills / Interests</label>
                <Input
                  type="text"
                  placeholder="e.g. React, Python, Embedded C, Machine Learning, CAD"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="text-xs"
                />
                <p className="text-[10px] text-slate-400">Separate skills with commas</p>
              </div>

              {/* Bio */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">Short Bio</label>
                <Textarea
                  rows={2}
                  placeholder="Briefly describe your career goals, projects, or areas of interest..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="text-xs"
                />
              </div>

              <Button
                type="submit"
                isLoading={isLoading}
                className="w-full bg-psg-900 hover:bg-psg-800 text-white font-semibold text-xs mt-2"
              >
                Complete Registration <ArrowRight className="h-3.5 w-3.5 ml-1.5" />
              </Button>
            </form>
          </CardContent>
          <CardFooter className="pt-0 justify-center border-t border-slate-100 py-4">
            <p className="text-xs text-slate-500">
              Already have an account?{' '}
              <Link href="/auth/login" className="text-blue-600 font-semibold hover:underline">
                Sign In
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
