'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { GraduationCap, Lock, Mail, ArrowRight, UserCheck, ShieldCheck } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const { login, demoLogin } = useAuth();
  const { success, error } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      error('Email Required', 'Please enter your email address.');
      return;
    }
    setIsLoading(true);
    const res = await login(email, password);
    setIsLoading(false);
    if (res.success) {
      success('Welcome Back!', 'Logged in to PSG Connect+ successfully.');
      router.push('/dashboard');
    } else {
      error('Login Failed', res.error || 'Invalid email or credentials.');
    }
  };

  const handleDemoClick = (role: 'student' | 'alumni' | 'admin') => {
    demoLogin(role);
    success('Demo Session Started', `Logged in as demo ${role}.`);
    router.push('/dashboard');
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 sm:p-6 bg-slate-50">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex h-12 w-12 rounded-2xl bg-gradient-to-br from-psg-900 to-blue-700 items-center justify-center text-white shadow-lg mx-auto">
            <GraduationCap className="h-7 w-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950 font-serif">
            Welcome to PSG Connect+
          </h1>
          <p className="text-xs text-slate-500">
            Sign in to access placement portals, housing, exams and alumni network
          </p>
        </div>

        <Card className="shadow-xl border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Sign In to Your Account</CardTitle>
            <CardDescription className="text-xs">
              Enter your college or registered email ID
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 1-Click Quick Demo Switcher */}
            <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200/80 space-y-2">
              <p className="text-[11px] font-bold text-psg-900 uppercase tracking-wider">
                Instant Demo Access (No Password Required)
              </p>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleDemoClick('student')}
                  className="p-1.5 rounded-lg bg-white border border-blue-300 text-blue-900 font-semibold text-[11px] hover:bg-blue-600 hover:text-white transition-colors flex flex-col items-center gap-1 shadow-sm"
                >
                  <GraduationCap className="h-3.5 w-3.5" />
                  <span>Student</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoClick('alumni')}
                  className="p-1.5 rounded-lg bg-white border border-purple-300 text-purple-900 font-semibold text-[11px] hover:bg-purple-600 hover:text-white transition-colors flex flex-col items-center gap-1 shadow-sm"
                >
                  <UserCheck className="h-3.5 w-3.5" />
                  <span>Alumni</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoClick('admin')}
                  className="p-1.5 rounded-lg bg-white border border-amber-300 text-amber-900 font-semibold text-[11px] hover:bg-amber-600 hover:text-white transition-colors flex flex-col items-center gap-1 shadow-sm"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>Admin</span>
                </button>
              </div>
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-[10px] uppercase font-bold text-slate-400">Or use email</span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    type="email"
                    placeholder="rollno@psgtech.ac.in or personal email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-9 text-xs"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700">Password</label>
                  <Link
                    href="/auth/forgot-password"
                    className="text-[11px] text-blue-600 hover:underline"
                  >
                    Forgot password?
                  </Link>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-9 text-xs"
                  />
                </div>
              </div>

              <Button
                type="submit"
                isLoading={isLoading}
                className="w-full bg-psg-900 hover:bg-psg-800 text-white font-semibold text-xs mt-2"
              >
                Sign In to Account <ArrowRight className="h-3.5 w-3.5 ml-1.5" />
              </Button>
            </form>
          </CardContent>
          <CardFooter className="pt-0 justify-center border-t border-slate-100 mt-2 py-4">
            <p className="text-xs text-slate-500">
              Don&apos;t have an account?{' '}
              <Link href="/auth/register" className="text-blue-600 font-semibold hover:underline">
                Create Account
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
