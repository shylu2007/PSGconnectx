'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import {
  FileText,
  Search,
  Calendar,
  Clock,
  MapPin,
  AlertCircle,
  Download,
  PlusCircle,
  CheckCircle2,
} from 'lucide-react';
import { ExamSchedule } from '@/types';

export default function ExamsPage() {
  const { user, role } = useAuth();
  const { success, error } = useToast();

  const [exams, setExams] = useState<ExamSchedule[]>([]);
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');
  const [selectedSemester, setSelectedSemester] = useState('all');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State
  const [newExamName, setNewExamName] = useState('Continuous Assessment - 2 (CA-2)');
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newDept, setNewDept] = useState('Computer Science and Engineering');
  const [newYear, setNewYear] = useState(3);
  const [newSem, setNewSem] = useState(5);
  const [newDate, setNewDate] = useState('2026-09-28');
  const [newSession, setNewSession] = useState<'FN (09:30 AM - 12:30 PM)' | 'AN (01:30 PM - 04:30 PM)'>('FN (09:30 AM - 12:30 PM)');
  const [newVenue, setNewVenue] = useState('F-Block Halls 301 - 304');
  const [newInstructions, setNewInstructions] = useState('Non-programmable calculators allowed. ID card mandatory.');

  const loadExams = () => {
    setExams(DataStore.getExams());
  };

  useEffect(() => {
    loadExams();
    window.addEventListener('psg_store_updated', loadExams);
    return () => window.removeEventListener('psg_store_updated', loadExams);
  }, []);

  const handleExportICal = (exam: ExamSchedule) => {
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//PSG Connect+//Exam Timetable//EN
BEGIN:VEVENT
SUMMARY:${exam.subject_code} - ${exam.subject_name} Exam
DESCRIPTION:${exam.exam_name} at ${exam.venue}. Instructions: ${exam.instructions || 'Bring college ID'}
LOCATION:${exam.venue}
DTSTART:${exam.exam_date.replace(/-/g, '')}T093000Z
DTEND:${exam.exam_date.replace(/-/g, '')}T123000Z
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${exam.subject_code}_Exam_Schedule.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    success('Calendar File Downloaded', `Added ${exam.subject_code} to your calendar export.`);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !newName || !newVenue) {
      error('Missing Details', 'Please enter subject code, name and venue.');
      return;
    }

    DataStore.addExam({
      exam_name: newExamName,
      subject_code: newCode.toUpperCase(),
      subject_name: newName,
      department: newDept,
      year: Number(newYear),
      semester: Number(newSem),
      exam_date: newDate,
      session: newSession,
      venue: newVenue,
      instructions: newInstructions,
    });

    success('Exam Schedule Published', `${newCode} scheduled for ${newDate}.`);
    setIsAddModalOpen(false);
    setNewCode('');
    setNewName('');
  };

  const departments = [
    'Computer Science and Engineering',
    'Electronics and Communication Engineering',
    'Electrical and Electronics Engineering',
    'Mechanical Engineering',
    'Artificial Intelligence and Data Science',
    'Information Technology',
    'First Year (Common to all Branches)',
  ];

  const filteredExams = exams.filter((ex) => {
    const matchSearch =
      !search ||
      ex.subject_code.toLowerCase().includes(search.toLowerCase()) ||
      ex.subject_name.toLowerCase().includes(search.toLowerCase()) ||
      ex.venue.toLowerCase().includes(search.toLowerCase());

    const matchDept = selectedDept === 'all' || ex.department.includes(selectedDept);
    const matchYear = selectedYear === 'all' || ex.year === Number(selectedYear);
    const matchSem = selectedSemester === 'all' || ex.semester === Number(selectedSemester);

    return matchSearch && matchDept && matchYear && matchSem;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-600">
              <FileText className="h-4 w-4" /> Office of the Controller of Examinations
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Exam Schedules & Timetables
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Continuous Assessment (CA-1, CA-2) and End Semester University Theory & Practical Schedules
            </p>
          </div>

          {(role === 'admin' || user?.role === 'alumni') && (
            <Button
              onClick={() => setIsAddModalOpen(true)}
              className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
            >
              <PlusCircle className="h-4 w-4" /> Publish Exam Schedule
            </Button>
          )}
        </div>

        {/* Filter Controls */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search subject code (21CS501, 21EC501)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>

            {/* Department */}
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-600"
            >
              <option value="all">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            {/* Year */}
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-600"
            >
              <option value="all">All Years (1st - 4th)</option>
              <option value="1">1st Year</option>
              <option value="2">2nd Year</option>
              <option value="3">3rd Year</option>
              <option value="4">4th Year</option>
            </select>

            {/* Semester */}
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-600"
            >
              <option value="all">All Semesters</option>
              {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                <option key={s} value={s}>
                  Semester {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Timetable Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredExams.map((exam) => (
            <Card key={exam.id} className="p-6 border-slate-200 hover:border-rose-300 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-rose-800 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded">
                      {exam.exam_name}
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-lg mt-1.5 leading-tight">
                      {exam.subject_code} - {exam.subject_name}
                    </h3>
                  </div>
                  <Badge variant="secondary" className="shrink-0 font-mono text-xs">
                    Sem {exam.semester}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-700 my-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Date & Session</span>
                    <span className="font-bold text-slate-900 flex items-center gap-1 mt-0.5">
                      <Calendar className="h-3.5 w-3.5 text-rose-600" /> {exam.exam_date}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">{exam.session}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Hall Allocation</span>
                    <span className="font-bold text-slate-900 flex items-center gap-1 mt-0.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-500" /> {exam.venue}
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">{exam.department.split(' ')[0]} Dept</span>
                  </div>
                </div>

                {exam.instructions && (
                  <div className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-200/60 text-[11px] text-amber-950 flex items-start gap-2">
                    <AlertCircle className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span>{exam.instructions}</span>
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">Reporting time: 15 mins prior</span>
                <Button
                  onClick={() => handleExportICal(exam)}
                  variant="outline"
                  size="sm"
                  className="text-xs flex items-center gap-1.5 hover:bg-rose-50 hover:text-rose-900 border-rose-200"
                >
                  <Download className="h-3.5 w-3.5" /> Add to Calendar (.ics)
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredExams.length === 0 && (
          <Card className="p-12 text-center text-slate-500">
            <FileText className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No exam schedules found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              No examinations matching the selected department or semester filter.
            </p>
          </Card>
        )}
      </div>

      {/* PUBLISH EXAM MODAL */}
      {isAddModalOpen && (
        <Modal
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          title="Publish Examination Schedule"
          description="Add a Continuous Assessment or End Semester subject timetable"
          maxWidth="2xl"
        >
          <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1 sm:col-span-2">
                <label className="font-semibold text-slate-700">Exam Category</label>
                <Input
                  type="text"
                  value={newExamName}
                  onChange={(e) => setNewExamName(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Subject Code *</label>
                <Input
                  type="text"
                  placeholder="e.g. 21CS501"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Subject Name *</label>
              <Input
                type="text"
                placeholder="e.g. Distributed Systems & Cloud Computing"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Department</label>
                <select
                  value={newDept}
                  onChange={(e) => setNewDept(e.target.value)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  {departments.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Year</label>
                <select
                  value={newYear}
                  onChange={(e) => setNewYear(Number(e.target.value))}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value={1}>1st Year</option>
                  <option value={2}>2nd Year</option>
                  <option value={3}>3rd Year</option>
                  <option value={4}>4th Year</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Semester</label>
                <select
                  value={newSem}
                  onChange={(e) => setNewSem(Number(e.target.value))}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={s}>
                      Semester {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Exam Date</label>
                <Input
                  type="date"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Session</label>
                <select
                  value={newSession}
                  onChange={(e) => setNewSession(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="FN (09:30 AM - 12:30 PM)">FN (09:30 AM - 12:30 PM)</option>
                  <option value="AN (01:30 PM - 04:30 PM)">AN (01:30 PM - 04:30 PM)</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Venue Hall *</label>
                <Input
                  type="text"
                  placeholder="e.g. F-Block Hall 301"
                  value={newVenue}
                  onChange={(e) => setNewVenue(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Special Instructions / Approved Data Books</label>
              <Textarea
                rows={2}
                value={newInstructions}
                onChange={(e) => setNewInstructions(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsAddModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-rose-600 text-white font-bold">
                Publish Schedule
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
