'use client';

import React from 'react';
import Link from 'next/link';
import {
  GraduationCap,
  ShieldCheck,
  Building,
  Users,
  Briefcase,
  Home,
  CheckCircle2,
  Mail,
  Phone,
  MapPin,
  Heart,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6">
      <div className="container max-w-5xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-to-br from-psg-900 to-blue-700 items-center justify-center text-white shadow-lg mx-auto">
            <GraduationCap className="h-8 w-8" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-950 font-serif">
            About PSG Connect<span className="text-emerald-500 font-extrabold">+</span>
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            The dedicated digital community platform built to bridge students, faculty, seniors, and alumni across PSG Institutions in Coimbatore and worldwide.
          </p>
        </div>

        {/* Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6">
            <div className="p-3 rounded-xl bg-blue-50 text-blue-700 w-fit mb-4">
              <Briefcase className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Career Acceleration</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Curated placement job drives, off-campus referrals, and summer/6-month research internships with transparent CTC and deadline tracking.
            </p>
          </Card>

          <Card className="p-6">
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-700 w-fit mb-4">
              <Home className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Verified Campus Housing</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Zero-brokerage student accommodations, hostels, and PGs around Peelamedu, Hope College, and Nava India with owner direct WhatsApp contact.
            </p>
          </Card>

          <Card className="p-6">
            <div className="p-3 rounded-xl bg-purple-50 text-purple-700 w-fit mb-4">
              <Users className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Global Alumni Network</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Connect directly with PSGians working at Google, Tesla, NVIDIA, Microsoft, McKinsey, and high-growth startups for mock interviews and guidance.
            </p>
          </Card>
        </div>

        {/* Community Guidelines */}
        <Card id="guidelines" className="p-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-blue-600" /> Community Standards & Honor Code
          </h2>
          <div className="space-y-4 text-xs text-slate-600 leading-relaxed">
            <p>
              PSG Connect+ is founded upon the values of integrity, collegiate excellence, and mutual student support. All members must adhere to the following standards:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">Authentic Academic Profiles</p>
                <p>Use your real name, valid student roll number, or verified alumni credentials. Impersonation of college officials is strictly prohibited.</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">Genuine Housing Listings</p>
                <p>Property owners and students must list accurate rent, deposit, and distance metrics. No deceptive amenities or false broker charges.</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">Respectful Alumni Inquiries</p>
                <p>When reaching out to alumni mentors, maintain professional courtesy, prepare specific questions, and respect their personal time.</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">Exam & Academic Integrity</p>
                <p>Exam schedules published on this platform are for official planning. Always verify with official COE circulars for hall allocations.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Contact info */}
        <div className="p-8 bg-slate-900 text-white rounded-3xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-xl font-bold font-serif">Have questions or want to partner?</h3>
            <p className="text-xs text-slate-400">
              Reach out to the PSG Placement Cell or Student Affairs Coordinator.
            </p>
            <div className="flex flex-wrap gap-4 text-xs text-slate-300 pt-2">
              <span className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4 text-blue-400" /> Peelamedu, Coimbatore - 641004
              </span>
              <span className="flex items-center gap-1.5">
                <Mail className="h-4 w-4 text-blue-400" /> connect@psgtech.ac.in
              </span>
            </div>
          </div>
          <Link href="/auth/register">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-500 text-white font-bold shrink-0">
              Join PSG Connect+
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
