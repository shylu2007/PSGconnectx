'use client';

import React, { useState, useEffect } from 'react';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  PhoneCall,
  Mail,
  MapPin,
  Clock,
  ShieldAlert,
  Building,
  HeartPulse,
  Briefcase,
  Home,
  FileText,
  Search,
} from 'lucide-react';
import { CampusContact } from '@/types';

function ContactsContent() {
  const { success } = useToast();
  const [contacts, setContacts] = useState<CampusContact[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    setContacts(DataStore.getCampusContacts());
  }, []);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Emergency & Health':
        return <HeartPulse className="h-5 w-5 text-rose-600" />;
      case 'Placement & Career':
        return <Briefcase className="h-5 w-5 text-blue-600" />;
      case 'Hostel & Housing':
        return <Home className="h-5 w-5 text-emerald-600" />;
      case 'Academic & COE':
        return <FileText className="h-5 w-5 text-amber-600" />;
      default:
        return <Building className="h-5 w-5 text-slate-600" />;
    }
  };

  const categories = [
    'Emergency & Health',
    'Placement & Career',
    'Hostel & Housing',
    'Academic & COE',
    'Administration',
  ];

  const filteredContacts = contacts.filter((c) => {
    const matchSearch =
      !search ||
      c.department_title.toLowerCase().includes(search.toLowerCase()) ||
      c.in_charge.toLowerCase().includes(search.toLowerCase()) ||
      c.location.toLowerCase().includes(search.toLowerCase());

    const matchCat = selectedCategory === 'all' || c.category === selectedCategory;

    return matchSearch && matchCat;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-600">
              <ShieldAlert className="h-4 w-4" /> Essential Campus Directory
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Useful Contacts & Emergency Helplines
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Direct emergency assistance, placement cell coordinators, hostel wardens, and COE office
            </p>
          </div>

          <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-3">
            <div className="p-2 bg-rose-600 text-white rounded-xl">
              <PhoneCall className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-rose-950 uppercase tracking-wider">Campus Emergency</p>
              <p className="text-sm font-black text-rose-700">+91 422 257 0170</p>
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            All Contacts ({contacts.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Contact Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContacts.map((cnt) => (
            <Card
              key={cnt.id}
              className="p-6 flex flex-col justify-between hover:shadow-lg transition-all border-slate-200"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    {getCategoryIcon(cnt.category)}
                  </div>
                  <Badge variant="secondary" className="text-[10px]">
                    {cnt.category}
                  </Badge>
                </div>

                <h3 className="font-bold text-slate-900 text-base mb-1">
                  {cnt.department_title}
                </h3>
                <p className="text-xs text-slate-500 mb-4">{cnt.in_charge}</p>

                <div className="space-y-2 text-xs text-slate-600 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{cnt.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{cnt.hours}</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center gap-2 mt-4">
                <a
                  href={`tel:${cnt.phone_primary.replace(/\s+/g, '')}`}
                  className="flex-1"
                >
                  <Button size="sm" className="w-full text-xs bg-psg-900 text-white flex items-center justify-center gap-1.5 font-bold">
                    <PhoneCall className="h-3.5 w-3.5" /> Call Primary
                  </Button>
                </a>
                <a href={`mailto:${cnt.email}`}>
                  <Button size="sm" variant="outline" className="text-xs px-3 border-slate-300">
                    <Mail className="h-3.5 w-3.5 text-slate-600" />
                  </Button>
                </a>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function ContactsPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading Contacts...</div>}>
      <ContactsContent />
    </React.Suspense>
  );
}
