'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import {
  Calendar,
  Search,
  MapPin,
  Clock,
  Users,
  PlusCircle,
  QrCode,
  Sparkles,
  Ticket,
  CheckCircle2,
} from 'lucide-react';
import { CampusEvent, EventCategory } from '@/types';

function EventsContent() {
  const searchParams = useSearchParams();
  const initialCategory = searchParams.get('cat') || 'all';
  const initialId = searchParams.get('id') || '';

  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);

  // Modals
  const [selectedEvent, setSelectedEvent] = useState<CampusEvent | null>(null);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Registration form
  const [rollNo, setRollNo] = useState('');
  const [confirmedTicket, setConfirmedTicket] = useState<string | null>(null);

  // Create Event Form
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<EventCategory>('Technical');
  const [newDate, setNewDate] = useState('2026-10-15');
  const [newTime, setNewTime] = useState('09:30 AM - 04:30 PM');
  const [newVenue, setNewVenue] = useState('GRD Auditorium, PSG Tech');
  const [newOrganizer, setNewOrganizer] = useState('Department Student Association');
  const [newCapacity, setNewCapacity] = useState(300);
  const [newDesc, setNewDesc] = useState('');
  const [newImage, setNewImage] = useState(
    'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800'
  );

  const loadEvents = () => {
    const list = DataStore.getEvents();
    setEvents(list);
    if (initialId) {
      const target = list.find((e) => e.id === initialId);
      if (target) setSelectedEvent(target);
    }
  };

  useEffect(() => {
    loadEvents();
    window.addEventListener('psg_store_updated', loadEvents);
    return () => window.removeEventListener('psg_store_updated', loadEvents);
  }, [initialId]);

  const categories: EventCategory[] = [
    'Technical',
    'Cultural',
    'Sports',
    'Workshops',
    'Hackathons',
    'Seminars',
    'Alumni Talks',
    'Placement',
  ];

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      info('Sign In Required', 'Please log in to register for this event.');
      return;
    }
    if (!selectedEvent) return;

    const reg = DataStore.registerForEvent(selectedEvent.id, user.id, rollNo);
    setConfirmedTicket(reg.ticket_code);

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    success('Pass Confirmed!', `Ticket ${reg.ticket_code} generated. View in your dashboard.`);
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDesc || !newVenue) {
      error('Missing Information', 'Please fill in all event details.');
      return;
    }

    const created = DataStore.addEvent({
      title: newTitle,
      category: newCategory,
      event_date: newDate,
      event_time: newTime,
      venue: newVenue,
      organizer: newOrganizer,
      capacity: Number(newCapacity),
      description: newDesc,
      cover_image: newImage,
      is_featured: false,
    });

    success('Event Published!', `"${created.title}" is now open for registrations.`);
    setIsCreateModalOpen(false);
    setNewTitle('');
    setNewDesc('');
  };

  const filteredEvents = events.filter((ev) => {
    const matchSearch =
      !search ||
      ev.title.toLowerCase().includes(search.toLowerCase()) ||
      ev.venue.toLowerCase().includes(search.toLowerCase()) ||
      ev.organizer.toLowerCase().includes(search.toLowerCase());

    const matchCat = selectedCategory === 'all' || ev.category === selectedCategory;

    return matchSearch && matchCat;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-600">
              <Calendar className="h-4 w-4" /> Campus Events & Competitions
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              PSG College Events & Fests
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Register for KRIYA, Hackathons, Robotics Workshops, Placement Readiness, and Alumni Keynotes
            </p>
          </div>

          <Button
            onClick={() => setIsCreateModalOpen(true)}
            className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
          >
            <PlusCircle className="h-4 w-4" /> Create Campus Event
          </Button>
        </div>

        {/* Filter Bar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="relative lg:col-span-2">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search event name, venue, or organizer (e.g. Kriya, Hackathon, GRD Auditorium)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-600"
            >
              <option value="all">All Event Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Category Pills */}
          <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 overflow-x-auto text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-amber-600 text-white font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Events
            </button>
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCategory(c)}
                className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                  selectedCategory === c
                    ? 'bg-amber-600 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredEvents.map((ev) => {
            const seatsRemaining = Math.max(0, ev.capacity - ev.registered_count);
            const percentFilled = Math.min(100, Math.round((ev.registered_count / ev.capacity) * 100));

            return (
              <Card
                key={ev.id}
                className="overflow-hidden flex flex-col justify-between hover:border-amber-300 hover:shadow-lg transition-all group"
              >
                <div>
                  <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                    <img
                      src={ev.cover_image}
                      alt={ev.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3">
                      <Badge variant="warning" className="shadow">
                        {ev.category}
                      </Badge>
                    </div>
                  </div>

                  <CardContent className="p-5">
                    <p className="text-xs font-bold text-amber-700 mb-1">
                      📅 {ev.event_date} ({ev.event_time})
                    </p>
                    <h3 className="font-bold text-slate-900 text-sm line-clamp-2 leading-tight group-hover:text-amber-800 transition-colors">
                      {ev.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                      {ev.description}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-3 flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{ev.venue}</span>
                    </p>

                    {/* Progress Bar */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <span>{ev.registered_count} registered</span>
                        <span className="font-semibold text-amber-800">{seatsRemaining} seats left</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{ width: `${percentFilled}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </div>

                <div className="p-5 pt-0 flex gap-2">
                  <Button
                    onClick={() => {
                      setSelectedEvent(ev);
                      setConfirmedTicket(null);
                      setIsRegisterModalOpen(true);
                    }}
                    size="sm"
                    className="w-full bg-psg-900 hover:bg-psg-800 text-white text-xs font-bold"
                  >
                    Register Now
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* REGISTRATION MODAL */}
      {isRegisterModalOpen && selectedEvent && (
        <Modal
          isOpen={isRegisterModalOpen}
          onClose={() => {
            setIsRegisterModalOpen(false);
            setConfirmedTicket(null);
          }}
          title={confirmedTicket ? 'Registration Confirmed!' : `Register: ${selectedEvent.title}`}
          description={
            confirmedTicket
              ? 'Your delegate entry pass has been successfully generated'
              : `${selectedEvent.event_date} • ${selectedEvent.venue}`
          }
          maxWidth="md"
        >
          {confirmedTicket ? (
            <div className="text-center py-4 space-y-4">
              <div className="p-4 bg-emerald-50 text-emerald-950 rounded-2xl border border-emerald-200 inline-block mx-auto">
                <QrCode className="h-28 w-28 text-emerald-900 mx-auto" />
                <p className="font-mono font-bold text-xs tracking-wider mt-2">{confirmedTicket}</p>
              </div>
              <p className="text-xs text-slate-600">
                Show this digital pass at the registration desk on the event day. It is also available in your Dashboard.
              </p>
              <Button
                size="sm"
                className="w-full bg-psg-900 text-white font-bold"
                onClick={() => setIsRegisterModalOpen(false)}
              >
                Done
              </Button>
            </div>
          ) : (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-slate-800 space-y-1">
                <p className="font-bold text-amber-950">{selectedEvent.title}</p>
                <p className="text-slate-600">📅 Date: {selectedEvent.event_date} ({selectedEvent.event_time})</p>
                <p className="text-slate-600">📍 Venue: {selectedEvent.venue}</p>
                <p className="text-slate-600">🏛 Organizer: {selectedEvent.organizer}</p>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">PSG Student Roll Number *</label>
                <Input
                  type="text"
                  placeholder="e.g. 22CS104"
                  value={rollNo}
                  onChange={(e) => setRollNo(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" size="sm" onClick={() => setIsRegisterModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="bg-amber-600 hover:bg-amber-700 text-white font-bold">
                  Confirm Registration
                </Button>
              </div>
            </form>
          )}
        </Modal>
      )}

      {/* CREATE EVENT MODAL */}
      {isCreateModalOpen && (
        <Modal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          title="Create New Campus Event"
          description="Publish a symposium, hackathon, workshop or sports meet"
          maxWidth="2xl"
        >
          <form onSubmit={handleCreateSubmit} className="space-y-3 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Event Title *</label>
              <Input
                type="text"
                placeholder="e.g. PSG CodeStorm 24-Hr Hackathon"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Event Date</label>
                <Input
                  type="date"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Max Capacity</label>
                <Input
                  type="number"
                  value={newCapacity}
                  onChange={(e) => setNewCapacity(Number(e.target.value))}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Timings</label>
                <Input
                  type="text"
                  placeholder="09:30 AM - 05:00 PM"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Venue *</label>
                <Input
                  type="text"
                  placeholder="e.g. GRD Auditorium"
                  value={newVenue}
                  onChange={(e) => setNewVenue(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Organizing Club / Department</label>
              <Input
                type="text"
                placeholder="e.g. Computer Science Engineers Association"
                value={newOrganizer}
                onChange={(e) => setNewOrganizer(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Description *</label>
              <Textarea
                rows={3}
                placeholder="Details on rules, prizes, schedule and registration fee (if any)..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsCreateModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-amber-600 text-white font-bold">
                Publish Event
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function EventsPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading College Events...</div>}>
      <EventsContent />
    </React.Suspense>
  );
}
