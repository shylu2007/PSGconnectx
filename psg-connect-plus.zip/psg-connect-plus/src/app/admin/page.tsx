'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input, Textarea } from '@/components/ui/input';
import { Modal } from '@/components/ui/modal';
import {
  ShieldCheck,
  Briefcase,
  GraduationCap,
  Home,
  Calendar,
  FileText,
  Users,
  CheckCircle2,
  XCircle,
  Trash2,
  RotateCcw,
  PlusCircle,
  Edit,
  TrendingUp,
  AlertTriangle,
  Sparkles,
  BookOpen,
  MessageSquare,
  CalendarCheck,
} from 'lucide-react';
import {
  Job,
  Internship,
  Accommodation,
  CampusEvent,
  ExamSchedule,
  UserProfile,
  AlumniProfile,
  ContentReport,
  ResourceItem,
  CommunityPost,
  AttendanceSubject,
} from '@/types';

export default function AdminPage() {
  const router = useRouter();
  const { user, role } = useAuth();
  const { success, info, error } = useToast();

  const [activeTab, setActiveTab] = useState<'overview' | 'attendance' | 'jobs' | 'housing' | 'events' | 'exams' | 'users' | 'resources' | 'community'>('overview');

  // Collections
  const [attendanceSubjects, setAttendanceSubjects] = useState<AttendanceSubject[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [accommodations, setAccommodations] = useState<Accommodation[]>([]);
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [exams, setExams] = useState<ExamSchedule[]>([]);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [alumni, setAlumni] = useState<AlumniProfile[]>([]);
  const [reports, setReports] = useState<ContentReport[]>([]);
  const [resources, setResources] = useState<ResourceItem[]>([]);
  const [posts, setPosts] = useState<CommunityPost[]>([]);

  const loadAdminData = () => {
    setAttendanceSubjects(DataStore.getAttendanceSubjects());
    setJobs(DataStore.getJobs());
    setInternships(DataStore.getInternships());
    setAccommodations(DataStore.getAccommodations());
    setEvents(DataStore.getEvents());
    setExams(DataStore.getExams());
    setProfiles(DataStore.getProfiles());
    setAlumni(DataStore.getAlumni());
    setReports(DataStore.getReports());
    setResources(DataStore.getResources());
    setPosts(DataStore.getCommunityPosts());
  };

  useEffect(() => {
    loadAdminData();
    window.addEventListener('psg_store_updated', loadAdminData);
    return () => window.removeEventListener('psg_store_updated', loadAdminData);
  }, []);

  // Actions
  const handleToggleJob = (job: Job) => {
    DataStore.updateJob({ ...job, is_active: !job.is_active });
    success('Job Status Updated', `${job.title} is now ${!job.is_active ? 'Active' : 'Inactive'}.`);
  };

  const handleDeleteJob = (id: string) => {
    if (confirm('Delete this job opportunity permanently?')) {
      DataStore.deleteJob(id);
      info('Deleted', 'Job listing removed.');
    }
  };

  const handleDeleteInternship = (id: string) => {
    if (confirm('Delete this internship listing?')) {
      DataStore.deleteInternship(id);
      info('Deleted', 'Internship removed.');
    }
  };

  const handleApproveAcc = (acc: Accommodation) => {
    DataStore.updateAccommodation({ ...acc, status: 'approved', is_verified: true });
    if (acc.posted_by) {
      DataStore.addNotification({
        user_id: acc.posted_by,
        title: 'Accommodation Listing Approved',
        message: `Your listing for "${acc.title}" has been approved by admin and is now live.`,
        type: 'housing',
        link: '/accommodation',
      });
    }
    success('Listing Approved', `"${acc.title}" is now visible to students.`);
  };

  const handleRejectAcc = (acc: Accommodation) => {
    DataStore.updateAccommodation({ ...acc, status: 'rejected' });
    info('Listing Rejected', `"${acc.title}" was rejected.`);
  };

  const handleDeleteAcc = (id: string) => {
    if (confirm('Delete this accommodation listing?')) {
      DataStore.deleteAccommodation(id);
      info('Deleted', 'Accommodation listing removed.');
    }
  };

  const handleDeleteEvent = (id: string) => {
    if (confirm('Delete this event?')) {
      DataStore.deleteEvent(id);
      info('Deleted', 'Event removed.');
    }
  };

  const handleDeleteExam = (id: string) => {
    if (confirm('Delete this exam schedule?')) {
      DataStore.deleteExam(id);
      info('Deleted', 'Exam schedule deleted.');
    }
  };

  const handleToggleVerifyUser = (p: UserProfile) => {
    DataStore.updateProfile({ ...p, is_verified: !p.is_verified });
    success('User Verification Updated', `${p.full_name} verification status changed.`);
  };

  const handleDeleteResource = (id: string) => {
    if (confirm('Delete this resource document?')) {
      DataStore.deleteResource(id);
      info('Deleted', 'Resource guide removed.');
    }
  };

  const handleDeletePost = (id: string) => {
    if (confirm('Delete this discussion thread?')) {
      DataStore.deleteCommunityPost(id);
      info('Deleted', 'Discussion thread removed.');
    }
  };

  const handleResetData = () => {
    if (confirm('Reset entire platform database to fresh PSG demo dataset?')) {
      DataStore.resetAllData();
      success('Database Restored', 'Reset all 50+ sample records.');
    }
  };

  const pendingAccommodations = accommodations.filter((a) => a.status === 'pending');

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Admin Header */}
        <div className="rounded-3xl bg-slate-900 text-white p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold text-2xl shadow-lg">
              <ShieldCheck className="h-9 w-9" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold font-serif tracking-tight">
                  PSG Connect+ Administration Console
                </h1>
                <Badge variant="warning" className="text-xs font-bold">
                  Admin Access
                </Badge>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Moderation, content approval, placement drives management, and platform analytics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              onClick={handleResetData}
              variant="outline"
              size="sm"
              className="bg-white/10 hover:bg-white/20 text-white border-white/20 text-xs flex items-center gap-1.5"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset Demo DB
            </Button>
          </div>
        </div>

        {/* Quick KPI Stat Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card className="p-4 bg-white border-blue-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Registered Students</p>
            <p className="text-2xl font-black text-psg-900 mt-1">{profiles.filter((p) => p.role === 'student').length}</p>
          </Card>
          <Card className="p-4 bg-white border-purple-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Alumni Mentors</p>
            <p className="text-2xl font-black text-purple-700 mt-1">{alumni.length}</p>
          </Card>
          <Card className="p-4 bg-white border-blue-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Active Jobs</p>
            <p className="text-2xl font-black text-blue-600 mt-1">{jobs.filter((j) => j.is_active).length}</p>
          </Card>
          <Card className="p-4 bg-white border-indigo-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Internships</p>
            <p className="text-2xl font-black text-indigo-600 mt-1">{internships.length}</p>
          </Card>
          <Card className="p-4 bg-white border-emerald-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Housing Listings</p>
            <p className="text-2xl font-black text-emerald-600 mt-1">{accommodations.length}</p>
          </Card>
          <Card className="p-4 bg-white border-amber-200 shadow-sm">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Upcoming Events</p>
            <p className="text-2xl font-black text-amber-600 mt-1">{events.length}</p>
          </Card>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-200 bg-white p-2 rounded-2xl shadow-sm overflow-x-auto">
          {[
            { id: 'overview', label: 'Dashboard Overview', icon: TrendingUp },
            { id: 'jobs', label: `Internships & Jobs (${jobs.length + internships.length})`, icon: Briefcase },
            { id: 'housing', label: `Accommodation (${accommodations.length})`, badge: pendingAccommodations.length > 0 ? `${pendingAccommodations.length} Pending` : undefined, icon: Home },
            { id: 'community', label: `Campus Buzz (${posts.length})`, icon: MessageSquare },
            { id: 'resources', label: `Academic Spotlights (${resources.length})`, icon: BookOpen },
            { id: 'events', label: `Events (${events.length})`, icon: Calendar },
            { id: 'users', label: `Users & Alumni (${profiles.length})`, icon: Users },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 text-[10px] font-extrabold rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {pendingAccommodations.length > 0 && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                  <div>
                    <p className="font-bold text-amber-950 text-sm">
                      {pendingAccommodations.length} Pending Accommodation Listings Awaiting Moderation
                    </p>
                    <p className="text-xs text-amber-800">
                      Review student housing posts before they appear on the public marketplace.
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => setActiveTab('housing')}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold"
                >
                  Review Listings
                </Button>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Jobs */}
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-blue-600" /> Recent Placement Drives
                  </h3>
                  <button onClick={() => setActiveTab('jobs')} className="text-xs text-blue-600 hover:underline">
                    Manage all
                  </button>
                </div>
                <div className="space-y-2.5">
                  {jobs.slice(0, 4).map((j) => (
                    <div key={j.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-slate-900">{j.title}</p>
                        <p className="text-slate-500">{j.company} • <span className="text-emerald-700 font-semibold">{j.salary}</span></p>
                      </div>
                      <Badge variant={j.is_active ? 'success' : 'destructive'}>
                        {j.is_active ? 'Active' : 'Paused'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Recent Events */}
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-amber-600" /> Upcoming Symposiums
                  </h3>
                  <button onClick={() => setActiveTab('events')} className="text-xs text-blue-600 hover:underline">
                    Manage all
                  </button>
                </div>
                <div className="space-y-2.5">
                  {events.slice(0, 4).map((e) => (
                    <div key={e.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-slate-900">{e.title}</p>
                        <p className="text-slate-500">{e.event_date} • {e.venue}</p>
                      </div>
                      <span className="font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        {e.registered_count} Regs
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* TAB: ATTENDANCE CURRICULUM */}
        {activeTab === 'attendance' && (
          <div className="space-y-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Curriculum & Attendance Courses</h3>
                  <p className="text-xs text-slate-500">
                    PSG Semester subjects, faculty allocations, and class metrics
                  </p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Course Code & Name</th>
                      <th className="pb-3">Faculty</th>
                      <th className="pb-3">Department</th>
                      <th className="pb-3">Conducted / Attended</th>
                      <th className="pb-3">Minimum %</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {attendanceSubjects.map((sub) => {
                      const pct =
                        sub.classes_conducted > 0
                          ? Number(((sub.classes_attended / sub.classes_conducted) * 100).toFixed(1))
                          : 100;
                      return (
                        <tr key={sub.id} className="hover:bg-slate-50">
                          <td className="py-3 font-semibold text-slate-900">
                            <span className="font-mono text-xs text-blue-600 font-bold mr-1.5">
                              {sub.subject_code}
                            </span>
                            {sub.subject_name}
                          </td>
                          <td className="py-3 text-slate-600">{sub.faculty_name || 'N/A'}</td>
                          <td className="py-3 text-slate-500">{sub.department}</td>
                          <td className="py-3">
                            <span className="font-bold text-slate-900">{sub.classes_attended}</span> / {sub.classes_conducted} ({pct}%)
                          </td>
                          <td className="py-3">
                            <Badge variant="outline">{sub.minimum_percentage}%</Badge>
                          </td>
                          <td className="py-3 text-right">
                            <button
                              onClick={() => {
                                if (confirm(`Remove ${sub.subject_code}?`)) {
                                  DataStore.deleteAttendanceSubject(sub.id);
                                  info('Removed', `Subject ${sub.subject_code} deleted.`);
                                }
                              }}
                              className="text-rose-600 hover:text-rose-800 p-1"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 2: JOBS & INTERNSHIPS */}
        {activeTab === 'jobs' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Active Placement Job Drives</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Company & Role</th>
                      <th className="pb-3">Location</th>
                      <th className="pb-3">Salary / CTC</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {jobs.map((job) => (
                      <tr key={job.id} className="hover:bg-slate-50">
                        <td className="py-3">
                          <p className="font-bold text-slate-900">{job.title}</p>
                          <p className="text-slate-500">{job.company}</p>
                        </td>
                        <td className="py-3 text-slate-600">{job.location}</td>
                        <td className="py-3 font-bold text-emerald-700">{job.salary}</td>
                        <td className="py-3">
                          <Badge variant={job.is_active ? 'success' : 'destructive'}>
                            {job.is_active ? 'Active' : 'Closed'}
                          </Badge>
                        </td>
                        <td className="py-3 text-right space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleToggleJob(job)}
                            className="text-[11px] h-7 px-2"
                          >
                            {job.is_active ? 'Close' : 'Reactivate'}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteJob(job.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Internships & Research Openings</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Role & Company</th>
                      <th className="pb-3">Domain</th>
                      <th className="pb-3">Stipend</th>
                      <th className="pb-3">Format</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {internships.map((intern) => (
                      <tr key={intern.id} className="hover:bg-slate-50">
                        <td className="py-3">
                          <p className="font-bold text-slate-900">{intern.role}</p>
                          <p className="text-slate-500">{intern.company}</p>
                        </td>
                        <td className="py-3">
                          <Badge variant="purple">{intern.domain}</Badge>
                        </td>
                        <td className="py-3 font-bold text-indigo-700">{intern.stipend}</td>
                        <td className="py-3 text-slate-600">{intern.remote_type}</td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteInternship(intern.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 3: ACCOMMODATION MODERATION */}
        {activeTab === 'housing' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Accommodation Listings Management</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Title & Area</th>
                      <th className="pb-3">Type</th>
                      <th className="pb-3">Rent / Mo</th>
                      <th className="pb-3">Owner Contact</th>
                      <th className="pb-3">Status</th>
                      <th className="pb-3 text-right">Moderation Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {accommodations.map((acc) => (
                      <tr key={acc.id} className="hover:bg-slate-50">
                        <td className="py-3">
                          <p className="font-bold text-slate-900">{acc.title}</p>
                          <p className="text-slate-500">{acc.location} • {acc.distance_to_campus}</p>
                        </td>
                        <td className="py-3">
                          <Badge variant="secondary">{acc.property_type}</Badge>
                        </td>
                        <td className="py-3 font-bold text-emerald-700">₹{acc.rent}/mo</td>
                        <td className="py-3 text-slate-600">
                          <p>{acc.owner_name}</p>
                          <p className="text-[11px] text-slate-400">{acc.owner_phone}</p>
                        </td>
                        <td className="py-3">
                          <Badge
                            variant={
                              acc.status === 'approved'
                                ? 'success'
                                : acc.status === 'pending'
                                ? 'warning'
                                : 'destructive'
                            }
                            className="capitalize"
                          >
                            {acc.status}
                          </Badge>
                        </td>
                        <td className="py-3 text-right space-x-2">
                          {acc.status !== 'approved' && (
                            <Button
                              size="sm"
                              onClick={() => handleApproveAcc(acc)}
                              className="text-[11px] h-7 px-2.5 bg-emerald-600 text-white font-bold"
                            >
                              Approve
                            </Button>
                          )}
                          {acc.status === 'pending' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRejectAcc(acc)}
                              className="text-[11px] h-7 px-2 text-amber-700"
                            >
                              Reject
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteAcc(acc.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 4: EVENTS */}
        {activeTab === 'events' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">College Events & Symposiums</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Event Name</th>
                      <th className="pb-3">Category</th>
                      <th className="pb-3">Date & Time</th>
                      <th className="pb-3">Venue</th>
                      <th className="pb-3">Registrations</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {events.map((ev) => (
                      <tr key={ev.id} className="hover:bg-slate-50">
                        <td className="py-3 font-bold text-slate-900">{ev.title}</td>
                        <td className="py-3">
                          <Badge variant="warning">{ev.category}</Badge>
                        </td>
                        <td className="py-3 text-slate-600">{ev.event_date}</td>
                        <td className="py-3 text-slate-600">{ev.venue}</td>
                        <td className="py-3 font-bold text-amber-800">
                          {ev.registered_count} / {ev.capacity}
                        </td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteEvent(ev.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 5: EXAM TIMETABLES */}
        {activeTab === 'exams' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Published Exam Timetables</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Subject</th>
                      <th className="pb-3">Department</th>
                      <th className="pb-3">Sem</th>
                      <th className="pb-3">Date & Session</th>
                      <th className="pb-3">Venue</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {exams.map((ex) => (
                      <tr key={ex.id} className="hover:bg-slate-50">
                        <td className="py-3">
                          <p className="font-bold text-slate-900">{ex.subject_code}</p>
                          <p className="text-slate-500">{ex.subject_name}</p>
                        </td>
                        <td className="py-3 text-slate-600">{ex.department.split(' ')[0]}</td>
                        <td className="py-3 font-semibold">Sem {ex.semester}</td>
                        <td className="py-3 text-slate-600">{ex.exam_date} ({ex.session.substring(0, 2)})</td>
                        <td className="py-3 text-slate-600">{ex.venue}</td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteExam(ex.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 6: USERS & ALUMNI */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">User Profiles & Verification</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">User</th>
                      <th className="pb-3">Role</th>
                      <th className="pb-3">Department</th>
                      <th className="pb-3">Batch</th>
                      <th className="pb-3">Verification</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {profiles.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="py-3">
                          <p className="font-bold text-slate-900">{p.full_name}</p>
                          <p className="text-slate-500">{p.email}</p>
                        </td>
                        <td className="py-3">
                          <Badge variant="psg" className="capitalize">
                            {p.role}
                          </Badge>
                        </td>
                        <td className="py-3 text-slate-600">{p.department}</td>
                        <td className="py-3 text-slate-600">{p.batch_year}</td>
                        <td className="py-3">
                          <Badge variant={p.is_verified ? 'success' : 'secondary'}>
                            {p.is_verified ? 'Verified' : 'Unverified'}
                          </Badge>
                        </td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleToggleVerifyUser(p)}
                            className="text-[11px] h-7 px-2"
                          >
                            {p.is_verified ? 'Unverify' : 'Verify'}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 7: RESOURCES */}
        {activeTab === 'resources' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Academic Spotlight & Global Degrees</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Student Name</th>
                      <th className="pb-3">Title & Category</th>
                      <th className="pb-3">Program / Partner University</th>
                      <th className="pb-3">Role / Award</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {resources.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50">
                        <td className="py-3 font-bold text-slate-900 flex items-center gap-2">
                          <img src={r.photo_url} alt={r.student_name} className="h-8 w-8 rounded-lg object-cover border border-slate-200" />
                          <span>{r.student_name}</span>
                        </td>
                        <td className="py-3 text-slate-600">
                          <p className="font-semibold text-slate-900">{r.title}</p>
                          <Badge variant="secondary" className="text-[10px] mt-0.5">{r.category}</Badge>
                        </td>
                        <td className="py-3 text-slate-600">
                          <p className="font-semibold">{r.program_type || 'Degree'}</p>
                          <p className="text-[10px] text-slate-400">{r.partner_university || r.institution}</p>
                        </td>
                        <td className="py-3 font-bold text-teal-800">{r.current_role || r.award_name || 'Academic Leader'}</td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteResource(r.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* TAB 8: COMMUNITY */}
        {activeTab === 'community' && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-slate-900 text-lg mb-4">Community Discussion Moderation</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="pb-3">Thread Title</th>
                      <th className="pb-3">Channel</th>
                      <th className="pb-3">Author</th>
                      <th className="pb-3">Upvotes & Replies</th>
                      <th className="pb-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {posts.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="py-3 max-w-xs">
                          <p className="font-bold text-slate-900 truncate">{p.title}</p>
                          <p className="text-slate-500 text-[10px] truncate">{p.content}</p>
                        </td>
                        <td className="py-3">
                          <Badge variant="purple">#{p.channel}</Badge>
                        </td>
                        <td className="py-3 text-slate-600">
                          <p className="font-semibold">{p.author_name}</p>
                          <p className="text-[10px] text-slate-400">{p.author_role}</p>
                        </td>
                        <td className="py-3 text-slate-600">
                          <span className="font-bold text-blue-600">{p.upvotes}</span> upvotes • <span className="font-bold text-slate-700">{p.comments.length}</span> replies
                        </td>
                        <td className="py-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeletePost(p.id)}
                            className="text-[11px] h-7 px-2 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
