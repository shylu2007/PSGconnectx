'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import {
  Search,
  Briefcase,
  MapPin,
  Clock,
  Bookmark,
  Share2,
  Filter,
  PlusCircle,
  TrendingUp,
  Building,
  CheckCircle2,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { Job, JobType, ExperienceLevel } from '@/types';

function JobsContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const initialJobId = searchParams.get('id') || '';

  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [search, setSearch] = useState(initialQuery);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedExp, setSelectedExp] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'salary' | 'deadline'>('newest');

  // Modals
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);

  // Application form state
  const [applicantRollNo, setApplicantRollNo] = useState('');
  const [applicantResumeLink, setApplicantResumeLink] = useState('');
  const [applicantCoverNote, setApplicantCoverNote] = useState('');

  // Post Job form state
  const [newTitle, setNewTitle] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newLocation, setNewLocation] = useState('Bengaluru / Coimbatore');
  const [newJobType, setNewJobType] = useState<JobType>('Full-time');
  const [newSalary, setNewSalary] = useState('₹18 - 25 LPA');
  const [newExp, setNewExp] = useState<ExperienceLevel>('Fresher / 0-1 yr');
  const [newDept, setNewDept] = useState('CSE, IT, ECE');
  const [newDesc, setNewDesc] = useState('');
  const [newSkills, setNewSkills] = useState('');
  const [newDeadline, setNewDeadline] = useState('2026-10-30');

  const loadJobs = () => {
    const list = DataStore.getJobs();
    setJobs(list);
    if (initialJobId) {
      const target = list.find((j) => j.id === initialJobId);
      if (target) setSelectedJob(target);
    }
  };

  useEffect(() => {
    loadJobs();
    window.addEventListener('psg_store_updated', loadJobs);
    return () => window.removeEventListener('psg_store_updated', loadJobs);
  }, [initialJobId]);

  const handleSaveJob = (jobId: string) => {
    if (!user) {
      info('Please Sign In', 'Log in to bookmark jobs.');
      return;
    }
    const isSaved = DataStore.toggleSaveItem(jobId, 'job', user.id);
    if (isSaved) {
      success('Job Saved', 'Added to your saved bookmarks.');
    } else {
      info('Job Removed', 'Removed from bookmarks.');
    }
  };

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      info('Sign In Required', 'Please log in to apply.');
      return;
    }
    if (!selectedJob) return;

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    DataStore.addNotification({
      user_id: user.id,
      title: `Application Submitted: ${selectedJob.title}`,
      message: `Your application to ${selectedJob.company} has been received by the placement recruitment team.`,
      type: 'opportunity',
      link: '/dashboard',
    });

    success('Application Submitted!', `Successfully applied to ${selectedJob.company}.`);
    setIsApplyModalOpen(false);
    setApplicantCoverNote('');
  };

  const handlePostJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newCompany || !newDesc) {
      error('Missing Details', 'Please enter job title, company and description.');
      return;
    }

    const created = DataStore.addJob({
      title: newTitle,
      company: newCompany,
      company_logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100',
      location: newLocation,
      job_type: newJobType,
      salary: newSalary,
      experience_level: newExp,
      eligible_departments: newDept.split(',').map((d) => d.trim()),
      description: newDesc,
      requirements: ['B.E/B.Tech from PSG Institutions', 'Strong foundational problem solving'],
      skills: newSkills.split(',').map((s) => s.trim()).filter(Boolean),
      deadline: `${newDeadline}T23:59:59Z`,
      apply_url: 'https://careers.psgconnect.edu',
      posted_by: user?.id,
      is_active: true,
    });

    success('Job Published!', `${created.title} at ${created.company} is now live.`);
    setIsPostModalOpen(false);
    setNewTitle('');
    setNewCompany('');
    setNewDesc('');
  };

  // Filter & Sort
  const filteredJobs = jobs
    .filter((j) => {
      const matchSearch =
        !search ||
        j.title.toLowerCase().includes(search.toLowerCase()) ||
        j.company.toLowerCase().includes(search.toLowerCase()) ||
        j.skills.some((s) => s.toLowerCase().includes(search.toLowerCase()));

      const matchType = selectedType === 'all' || j.job_type === selectedType;
      const matchExp = selectedExp === 'all' || j.experience_level === selectedExp;
      const matchLoc =
        selectedLocation === 'all' ||
        j.location.toLowerCase().includes(selectedLocation.toLowerCase());

      return matchSearch && matchType && matchExp && matchLoc;
    })
    .sort((a, b) => {
      if (sortBy === 'deadline') {
        return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600">
              <Briefcase className="h-4 w-4" /> Career & Placements
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              PSG Job Opportunities
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Explore on-campus drives, off-campus referrals, and alumni job postings
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              onClick={() => setIsPostModalOpen(true)}
              className="bg-psg-900 hover:bg-psg-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
            >
              <PlusCircle className="h-4 w-4" /> Post a Job
            </Button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search Input */}
            <div className="lg:col-span-2 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search job title, company, skills (e.g. C++, Azure, Zoho)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>

            {/* Job Type */}
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-psg-700"
            >
              <option value="all">All Job Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
              <option value="Contract">Contract</option>
              <option value="Remote">Remote</option>
            </select>

            {/* Location */}
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-psg-700"
            >
              <option value="all">All Locations</option>
              <option value="Coimbatore">Coimbatore</option>
              <option value="Bengaluru">Bengaluru</option>
              <option value="Chennai">Chennai</option>
              <option value="Hyderabad">Hyderabad</option>
            </select>

            {/* Sort By */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-psg-700"
            >
              <option value="newest">Sort by Newest</option>
              <option value="deadline">Approaching Deadline</option>
            </select>
          </div>
        </div>

        {/* Job Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredJobs.map((job) => {
            const isItemSaved = user ? DataStore.isSaved(job.id, 'job', user.id) : false;
            return (
              <Card
                key={job.id}
                className="flex flex-col justify-between hover:border-blue-300 hover:shadow-lg transition-all"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={job.company_logo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100'}
                        alt={job.company}
                        className="h-12 w-12 rounded-xl object-cover border border-slate-200 shadow-sm"
                      />
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm line-clamp-1">{job.title}</h3>
                        <p className="text-xs text-slate-500 font-medium">{job.company}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSaveJob(job.id)}
                      className={`p-2 rounded-lg transition-colors ${
                        isItemSaved
                          ? 'bg-blue-50 text-blue-600'
                          : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                      }`}
                      title="Bookmark Job"
                    >
                      <Bookmark className={`h-4 w-4 ${isItemSaved ? 'fill-blue-600' : ''}`} />
                    </button>
                  </div>

                  <div className="space-y-2 mb-4 text-xs text-slate-600">
                    <p className="flex items-center gap-2">
                      <MapPin className="h-3.5 w-3.5 text-slate-400" />
                      <span>{job.location}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
                      <span className="font-bold text-emerald-700">{job.salary}</span>
                      <span className="text-slate-400">• {job.job_type}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Clock className="h-3.5 w-3.5 text-slate-400" />
                      <span>Deadline: {new Date(job.deadline).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </p>
                  </div>

                  {/* Skills Pills */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {job.skills.slice(0, 3).map((skill) => (
                      <span
                        key={skill}
                        className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                    {job.skills.length > 3 && (
                      <span className="px-1.5 py-0.5 text-[10px] text-slate-400">
                        +{job.skills.length - 3} more
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                    {job.description}
                  </p>

                  <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                    <Button
                      onClick={() => setSelectedJob(job)}
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                    >
                      Job Details
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedJob(job);
                        setIsApplyModalOpen(true);
                      }}
                      size="sm"
                      className="flex-1 bg-psg-900 hover:bg-psg-800 text-white text-xs"
                    >
                      Apply Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredJobs.length === 0 && (
          <Card className="p-12 text-center text-slate-500">
            <Briefcase className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No matching jobs found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search criteria or resetting the filters.
            </p>
            <Button
              onClick={() => {
                setSearch('');
                setSelectedType('all');
                setSelectedExp('all');
                setSelectedLocation('all');
              }}
              variant="outline"
              size="sm"
              className="mt-4"
            >
              Reset All Filters
            </Button>
          </Card>
        )}
      </div>

      {/* JOB DETAILS MODAL */}
      {selectedJob && (
        <Modal
          isOpen={Boolean(selectedJob)}
          onClose={() => setSelectedJob(null)}
          title={selectedJob.title}
          description={`${selectedJob.company} • ${selectedJob.location}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs">
            <div className="flex flex-wrap gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">CTC / Compensation</span>
                <span className="font-bold text-emerald-700 text-sm">{selectedJob.salary}</span>
              </div>
              <div className="border-l border-slate-200 pl-3">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Job Type</span>
                <span className="font-semibold text-slate-800">{selectedJob.job_type}</span>
              </div>
              <div className="border-l border-slate-200 pl-3">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Experience</span>
                <span className="font-semibold text-slate-800">{selectedJob.experience_level}</span>
              </div>
              <div className="border-l border-slate-200 pl-3">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Deadline</span>
                <span className="font-semibold text-slate-800">{new Date(selectedJob.deadline).toLocaleDateString()}</span>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">About the Role</h4>
              <p className="text-slate-600 leading-relaxed">{selectedJob.description}</p>
            </div>

            {selectedJob.requirements && selectedJob.requirements.length > 0 && (
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Eligibility & Requirements</h4>
                <ul className="list-disc pl-4 space-y-1 text-slate-600">
                  {selectedJob.requirements.map((req, idx) => (
                    <li key={idx}>{req}</li>
                  ))}
                </ul>
              </div>
            )}

            <div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Required Skills</h4>
              <div className="flex flex-wrap gap-1.5">
                {selectedJob.skills.map((skill) => (
                  <Badge key={skill} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
              <Button
                size="sm"
                className="bg-psg-900 hover:bg-psg-800 text-white font-bold"
                onClick={() => setIsApplyModalOpen(true)}
              >
                Apply for Position
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* APPLY MODAL */}
      {isApplyModalOpen && selectedJob && (
        <Modal
          isOpen={isApplyModalOpen}
          onClose={() => setIsApplyModalOpen(false)}
          title={`Apply to ${selectedJob.company}`}
          description={`Position: ${selectedJob.title}`}
          maxWidth="lg"
        >
          <form onSubmit={handleApplySubmit} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">PSG Student Roll Number *</label>
              <Input
                type="text"
                placeholder="e.g. 22CS104"
                value={applicantRollNo}
                onChange={(e) => setApplicantRollNo(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Resume / Portfolio Link (Google Drive / GitHub) *</label>
              <Input
                type="url"
                placeholder="https://drive.google.com/... or https://github.com/..."
                value={applicantResumeLink}
                onChange={(e) => setApplicantResumeLink(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Cover Note / Why are you a good fit?</label>
              <Textarea
                rows={3}
                placeholder="Briefly state your relevant projects, GPA, or competitive programming handles..."
                value={applicantCoverNote}
                onChange={(e) => setApplicantCoverNote(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsApplyModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold">
                Submit Application
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* POST A JOB MODAL */}
      {isPostModalOpen && (
        <Modal
          isOpen={isPostModalOpen}
          onClose={() => setIsPostModalOpen(false)}
          title="Post a New Job Listing"
          description="Publish a placement opportunity for PSG students & alumni"
          maxWidth="2xl"
        >
          <form onSubmit={handlePostJob} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Job Title *</label>
                <Input
                  type="text"
                  placeholder="e.g. Member Technical Staff - SDE"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Company Name *</label>
                <Input
                  type="text"
                  placeholder="e.g. Amazon / Zoho"
                  value={newCompany}
                  onChange={(e) => setNewCompany(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Location</label>
                <Input
                  type="text"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Job Type</label>
                <select
                  value={newJobType}
                  onChange={(e) => setNewJobType(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="Full-time">Full-time</option>
                  <option value="Part-time">Part-time</option>
                  <option value="Contract">Contract</option>
                  <option value="Remote">Remote</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Salary / CTC</label>
                <Input
                  type="text"
                  placeholder="e.g. ₹20 - 28 LPA"
                  value={newSalary}
                  onChange={(e) => setNewSalary(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Eligible Departments (Comma separated)</label>
                <Input
                  type="text"
                  value={newDept}
                  onChange={(e) => setNewDept(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Application Deadline</label>
                <Input
                  type="date"
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Key Skills (Comma separated)</label>
              <Input
                type="text"
                placeholder="e.g. Java, Python, AWS, Docker"
                value={newSkills}
                onChange={(e) => setNewSkills(e.target.value)}
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Job Description *</label>
              <Textarea
                rows={3}
                placeholder="Describe core responsibilities and interview process..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsPostModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-psg-900 text-white font-bold">
                Publish Opportunity
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function JobsPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading PSG Jobs...</div>}>
      <JobsContent />
    </React.Suspense>
  );
}
