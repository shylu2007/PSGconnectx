'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import {
  Search,
  Home,
  MapPin,
  CheckCircle2,
  Phone,
  MessageCircle,
  PlusCircle,
  Sparkles,
  Wifi,
  Shield,
  Utensils,
  Share2,
} from 'lucide-react';
import { Accommodation, PropertyType, GenderPreference } from '@/types';

function AccommodationContent() {
  const searchParams = useSearchParams();
  const initialId = searchParams.get('id') || '';

  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [accommodations, setAccommodations] = useState<Accommodation[]>([]);
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedGender, setSelectedGender] = useState<string>('all');
  const [maxRent, setMaxRent] = useState<number>(30000);
  const [selectedAmenity, setSelectedAmenity] = useState<string>('all');

  // Modals
  const [selectedAcc, setSelectedAcc] = useState<Accommodation | null>(null);
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);

  // Post Listing Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newType, setNewType] = useState<PropertyType>('Single Room');
  const [newRent, setNewRent] = useState(7000);
  const [newDeposit, setNewDeposit] = useState(15000);
  const [newLoc, setNewLoc] = useState('Peelamedu (Near PSG Tech Gate 2)');
  const [newDist, setNewDist] = useState('0.4 km (5 mins walk)');
  const [newGender, setNewGender] = useState<GenderPreference>('Boys Only');
  const [newAmenities, setNewAmenities] = useState<string[]>([
    'High-Speed Wi-Fi',
    'Power Backup',
    '2-Wheeler Parking',
  ]);
  const [newImage, setNewImage] = useState(
    'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800'
  );
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerWhatsapp, setOwnerWhatsapp] = useState('');

  const loadListings = () => {
    const list = DataStore.getAccommodations().filter(
      (a) => a.status === 'approved' || (user?.role === 'admin' && a.status === 'pending')
    );
    setAccommodations(list);
    if (initialId) {
      const target = list.find((a) => a.id === initialId);
      if (target) setSelectedAcc(target);
    }
  };

  useEffect(() => {
    loadListings();
    window.addEventListener('psg_store_updated', loadListings);
    return () => window.removeEventListener('psg_store_updated', loadListings);
  }, [initialId, user]);

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDesc || !ownerName || !ownerPhone) {
      error('Incomplete Listing', 'Please provide title, description, and contact info.');
      return;
    }

    const created = DataStore.addAccommodation({
      title: newTitle,
      description: newDesc,
      property_type: newType,
      rent: Number(newRent),
      deposit: Number(newDeposit),
      location: newLoc,
      distance_to_campus: newDist,
      gender_preference: newGender,
      amenities: newAmenities,
      images: [newImage],
      available_from: new Date().toISOString().split('T')[0],
      owner_name: ownerName,
      owner_phone: ownerPhone,
      owner_whatsapp: ownerWhatsapp || ownerPhone.replace(/\D/g, ''),
      is_verified: true,
      status: 'approved',
      posted_by: user?.id,
    });

    if (user) {
      DataStore.addNotification({
        user_id: user.id,
        title: 'Accommodation Listing Published',
        message: `Your listing for "${created.title}" is now visible to PSG students.`,
        type: 'housing',
        link: '/accommodation',
      });
    }

    success('Listing Created!', 'Your property is now live on the PSG student housing marketplace.');
    setIsPostModalOpen(false);
    setNewTitle('');
    setNewDesc('');
  };

  const allAmenitiesList = [
    'High-Speed Wi-Fi',
    'Air Conditioning',
    'Mess Food Included',
    'Power Backup',
    '2-Wheeler Parking',
    'Washing Machine',
    'CCTV Security',
    'Biometric Gate Access',
    'Geyser',
  ];

  const toggleAmenity = (amenity: string) => {
    if (newAmenities.includes(amenity)) {
      setNewAmenities(newAmenities.filter((a) => a !== amenity));
    } else {
      setNewAmenities([...newAmenities, amenity]);
    }
  };

  const filteredListings = accommodations.filter((a) => {
    const matchSearch =
      !search ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.location.toLowerCase().includes(search.toLowerCase()) ||
      a.property_type.toLowerCase().includes(search.toLowerCase());

    const matchType = selectedType === 'all' || a.property_type === selectedType;
    const matchGender =
      selectedGender === 'all' || a.gender_preference === selectedGender || a.gender_preference === 'Any / Co-ed';
    const matchRent = a.rent <= maxRent;
    const matchAmenity =
      selectedAmenity === 'all' || a.amenities.some((am) => am.toLowerCase().includes(selectedAmenity.toLowerCase()));

    return matchSearch && matchType && matchGender && matchRent && matchAmenity;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-600">
              <Home className="h-4 w-4" /> PSG Student Accommodation Marketplace
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              Accommodation & PGs near PSG Tech
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Verified flats, single rooms, sharing PGs, and hostels around Peelamedu, Hope College, and SITRA
            </p>
          </div>

          <Button
            onClick={() => setIsPostModalOpen(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
          >
            <PlusCircle className="h-4 w-4" /> Post Accommodation
          </Button>
        </div>

        {/* Filter Controls */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Search */}
            <div className="relative lg:col-span-2">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search area (Peelamedu, Hope College, Nava India, SITRA)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>

            {/* Room Type */}
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="all">All Property Types</option>
              <option value="Single Room">Single Room</option>
              <option value="1 BHK">1 BHK Flat</option>
              <option value="2 BHK">2 BHK Flat</option>
              <option value="3 BHK">3 BHK Flat</option>
              <option value="Shared Room">Shared Room</option>
              <option value="PG / Hostel">PG / Hostel</option>
            </select>

            {/* Gender Preference */}
            <select
              value={selectedGender}
              onChange={(e) => setSelectedGender(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="all">All Gender Rules</option>
              <option value="Boys Only">Boys Only</option>
              <option value="Girls Only">Girls Only</option>
              <option value="Any / Co-ed">Any / Co-ed</option>
            </select>

            {/* Max Rent Filter */}
            <div className="flex flex-col justify-center px-2">
              <div className="flex justify-between text-[11px] font-semibold text-slate-600 mb-1">
                <span>Max Rent:</span>
                <span className="text-emerald-700 font-bold">₹{maxRent.toLocaleString('en-IN')}/mo</span>
              </div>
              <input
                type="range"
                min={3000}
                max={30000}
                step={500}
                value={maxRent}
                onChange={(e) => setMaxRent(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
            </div>
          </div>

          {/* Amenities Filter Pills */}
          <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 overflow-x-auto text-xs">
            <span className="text-slate-400 text-[11px] mr-1">Amenity:</span>
            {['all', 'Wi-Fi', 'AC', 'Mess Food', 'Power Backup', 'Washing Machine', 'Parking'].map((am) => (
              <button
                key={am}
                onClick={() => setSelectedAmenity(am)}
                className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                  selectedAmenity === am
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {am === 'all' ? 'All Amenities' : am}
              </button>
            ))}
          </div>
        </div>

        {/* Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredListings.map((acc) => (
            <Card
              key={acc.id}
              className="overflow-hidden flex flex-col justify-between hover:border-emerald-300 hover:shadow-lg transition-all"
            >
              <div>
                <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                  <img
                    src={acc.images[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800'}
                    alt={acc.title}
                    className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge variant="psg" className="bg-white/95 text-slate-900 shadow">
                      {acc.property_type}
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge
                      variant={
                        acc.gender_preference === 'Girls Only'
                          ? 'purple'
                          : acc.gender_preference === 'Boys Only'
                          ? 'default'
                          : 'secondary'
                      }
                      className="shadow"
                    >
                      {acc.gender_preference}
                    </Badge>
                  </div>
                  <div className="absolute bottom-3 right-3 bg-slate-950/85 backdrop-blur-sm text-white px-2.5 py-1 rounded-lg text-xs font-extrabold shadow">
                    ₹{acc.rent.toLocaleString('en-IN')}/mo
                  </div>
                </div>

                <CardContent className="p-5">
                  <h3 className="font-bold text-slate-900 text-sm line-clamp-1">
                    {acc.title}
                  </h3>
                  <p className="text-xs text-emerald-700 font-semibold mt-1 flex items-center gap-1">
                    📍 {acc.distance_to_campus}
                  </p>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                    {acc.location}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Deposit: ₹{acc.deposit.toLocaleString('en-IN')}
                  </p>

                  <div className="mt-3 flex flex-wrap gap-1">
                    {acc.amenities.slice(0, 3).map((a) => (
                      <span key={a} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">
                        {a}
                      </span>
                    ))}
                    {acc.amenities.length > 3 && (
                      <span className="text-[10px] text-slate-400">+{acc.amenities.length - 3}</span>
                    )}
                  </div>
                </CardContent>
              </div>

              <div className="p-5 pt-0 flex gap-2">
                <Button
                  onClick={() => setSelectedAcc(acc)}
                  size="sm"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                >
                  View & Contact
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredListings.length === 0 && (
          <Card className="p-12 text-center text-slate-500">
            <Home className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No accommodation found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your max rent budget or clearing selected filters.
            </p>
          </Card>
        )}
      </div>

      {/* PROPERTY DETAIL & CONTACT MODAL */}
      {selectedAcc && (
        <Modal
          isOpen={Boolean(selectedAcc)}
          onClose={() => setSelectedAcc(null)}
          title={selectedAcc.title}
          description={`📍 ${selectedAcc.location}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs">
            {/* Image banner */}
            <div className="h-56 w-full rounded-xl overflow-hidden bg-slate-100 relative">
              <img
                src={selectedAcc.images[0]}
                alt={selectedAcc.title}
                className="h-full w-full object-cover"
              />
              <div className="absolute bottom-3 right-3 bg-slate-900/90 text-white px-3 py-1.5 rounded-xl font-extrabold text-sm">
                Rent: ₹{selectedAcc.rent.toLocaleString('en-IN')} / month
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Property Type</span>
                <span className="font-bold text-slate-900">{selectedAcc.property_type}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Security Deposit</span>
                <span className="font-bold text-slate-900">₹{selectedAcc.deposit.toLocaleString('en-IN')}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Distance to PSG</span>
                <span className="font-bold text-emerald-700">{selectedAcc.distance_to_campus}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Gender Preference</span>
                <span className="font-bold text-slate-900">{selectedAcc.gender_preference}</span>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Description</h4>
              <p className="text-slate-600 leading-relaxed">{selectedAcc.description}</p>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Amenities Included</h4>
              <div className="flex flex-wrap gap-1.5">
                {selectedAcc.amenities.map((am) => (
                  <Badge key={am} variant="secondary">
                    ✓ {am}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Contact Card */}
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
              <p className="font-bold text-emerald-950 text-sm">Verified Property Contact</p>
              <p className="text-slate-700 flex items-center gap-2">
                <span className="font-semibold">Owner / Caretaker:</span> {selectedAcc.owner_name}
              </p>
              <p className="text-slate-700 flex items-center gap-2">
                <span className="font-semibold">Phone:</span> {selectedAcc.owner_phone}
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              {selectedAcc.owner_whatsapp && (
                <a
                  href={`https://wa.me/${selectedAcc.owner_whatsapp}?text=Hello%2C%20I%20am%20a%20PSG%20student%20interested%20in%20your%20listing%3A%20${encodeURIComponent(selectedAcc.title)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2 font-bold">
                    <MessageCircle className="h-4 w-4" /> WhatsApp Owner
                  </Button>
                </a>
              )}
              <a href={`tel:${selectedAcc.owner_phone}`} className="flex-1">
                <Button variant="outline" className="w-full flex items-center justify-center gap-2 font-bold">
                  <Phone className="h-4 w-4" /> Call Phone
                </Button>
              </a>
            </div>
          </div>
        </Modal>
      )}

      {/* POST ACCOMMODATION MODAL */}
      {isPostModalOpen && (
        <Modal
          isOpen={isPostModalOpen}
          onClose={() => setIsPostModalOpen(false)}
          title="Post Student Accommodation Listing"
          description="List a flat, PG, or hostel room for PSG students"
          maxWidth="2xl"
        >
          <form onSubmit={handlePostSubmit} className="space-y-3 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Listing Title *</label>
              <Input
                type="text"
                placeholder="e.g. Deluxe Single PG Room with AC & Food"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Property Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="Single Room">Single Room</option>
                  <option value="1 BHK">1 BHK Flat</option>
                  <option value="2 BHK">2 BHK Flat</option>
                  <option value="3 BHK">3 BHK Flat</option>
                  <option value="Shared Room">Shared Room</option>
                  <option value="PG / Hostel">PG / Hostel</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Monthly Rent (₹) *</label>
                <Input
                  type="number"
                  value={newRent}
                  onChange={(e) => setNewRent(Number(e.target.value))}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Deposit (₹) *</label>
                <Input
                  type="number"
                  value={newDeposit}
                  onChange={(e) => setNewDeposit(Number(e.target.value))}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Location Area</label>
                <Input
                  type="text"
                  placeholder="e.g. Peelamedu"
                  value={newLoc}
                  onChange={(e) => setNewLoc(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Distance to PSG Tech</label>
                <Input
                  type="text"
                  placeholder="e.g. 0.5 km (5 mins walk)"
                  value={newDist}
                  onChange={(e) => setNewDist(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Gender Rule</label>
                <select
                  value={newGender}
                  onChange={(e) => setNewGender(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="Boys Only">Boys Only</option>
                  <option value="Girls Only">Girls Only</option>
                  <option value="Any / Co-ed">Any / Co-ed</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Amenities Checklist</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                {allAmenitiesList.map((am) => (
                  <label key={am} className="flex items-center gap-1.5 text-[11px] text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newAmenities.includes(am)}
                      onChange={() => toggleAmenity(am)}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>{am}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Owner / Manager Name *</label>
                <Input
                  type="text"
                  placeholder="e.g. Mr. K. Selvam"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Owner Phone *</label>
                <Input
                  type="tel"
                  placeholder="+91 98401 23456"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">WhatsApp Number</label>
                <Input
                  type="tel"
                  placeholder="919840123456"
                  value={ownerWhatsapp}
                  onChange={(e) => setOwnerWhatsapp(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Description *</label>
              <Textarea
                rows={3}
                placeholder="Mention meal timings, gate curfew rules, furnishings, water supply..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsPostModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold">
                Publish Listing
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function AccommodationPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading Student Accommodation...</div>}>
      <AccommodationContent />
    </React.Suspense>
  );
}
