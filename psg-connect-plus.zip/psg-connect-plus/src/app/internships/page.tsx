'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import confetti from 'canvas-confetti';
import {
  Search,
  GraduationCap,
  MapPin,
  Clock,
  Bookmark,
  Sparkles,
  PlusCircle,
  TrendingUp,
} from 'lucide-react';
import { Internship, InternshipDomain, RemoteType } from '@/types';

function InternshipsContent() {
  const searchParams = useSearchParams();
  const initialId = searchParams.get('id') || '';

  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [internships, setInternships] = useState<Internship[]>([]);
  const [search, setSearch] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedRemote, setSelectedRemote] = useState<string>('all');
  const [selectedDuration, setSelectedDuration] = useState<string>('all');

  // Modals
  const [selectedIntern, setSelectedIntern] = useState<Internship | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);

  // Apply Form
  const [rollNo, setRollNo] = useState('');
  const [portfolioUrl, setPortfolioUrl] = useState('');
  const [pitchNote, setPitchNote] = useState('');

  // Post Form
  const [newRole, setNewRole] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newDomain, setNewDomain] = useState<InternshipDomain>('Software Development');
  const [newStipend, setNewStipend] = useState('₹45,000 / month');
  const [newDuration, setNewDuration] = useState('6 Months');
  const [newRemote, setNewRemote] = useState<RemoteType>('Hybrid');
  const [newLocation, setNewLocation] = useState('Bengaluru / Remote');
  const [newDesc, setNewDesc] = useState('');
  const [newDeadline, setNewDeadline] = useState('2026-10-25');

  const loadInternships = () => {
    const list = DataStore.getInternships();
    setInternships(list);
    if (initialId) {
      const target = list.find((i) => i.id === initialId);
      if (target) setSelectedIntern(target);
    }
  };

  useEffect(() => {
    loadInternships();
    window.addEventListener('psg_store_updated', loadInternships);
    return () => window.removeEventListener('psg_store_updated', loadInternships);
  }, [initialId]);

  const handleSave = (id: string) => {
    if (!user) {
      info('Please Sign In', 'Log in to bookmark internships.');
      return;
    }
    const isSaved = DataStore.toggleSaveItem(id, 'internship', user.id);
    if (isSaved) {
      success('Saved', 'Internship added to your dashboard.');
    } else {
      info('Removed', 'Removed from saved items.');
    }
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      info('Sign In Required', 'Please log in to apply.');
      return;
    }
    if (!selectedIntern) return;

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });

    DataStore.addNotification({
      user_id: user.id,
      title: `Internship Application: ${selectedIntern.role}`,
      message: `Your application to ${selectedIntern.company} has been sent successfully.`,
      type: 'opportunity',
      link: '/dashboard',
    });

    success('Application Sent!', `Applied to ${selectedIntern.company} for ${selectedIntern.role}.`);
    setIsApplyModalOpen(false);
    setPitchNote('');
  };

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRole || !newCompany || !newDesc) {
      error('Missing Information', 'Please fill in role, company and description.');
      return;
    }

    const created = DataStore.addInternship({
      role: newRole,
      company: newCompany,
      company_logo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100',
      location: newLocation,
      domain: newDomain,
      is_paid: true,
      stipend: newStipend,
      duration: newDuration,
      remote_type: newRemote,
      eligible_departments: ['CSE', 'IT', 'AI & DS', 'ECE'],
      description: newDesc,
      requirements: ['Enrolled in PSG Institutions', 'Strong fundamental concepts in domain'],
      deadline: `${newDeadline}T23:59:59Z`,
      apply_url: 'https://careers.psgconnect.edu',
      posted_by: user?.id,
      is_active: true,
    });

    success('Internship Published!', `${created.role} at ${created.company} is now live.`);
    setIsPostModalOpen(false);
    setNewRole('');
    setNewCompany('');
    setNewDesc('');
  };

  const domains: InternshipDomain[] = [
    'Software Development',
    'AI / ML',
    'Data Science',
    'VLSI & Embedded',
    'Core Mechanical',
    'Robotics & Automation',
    'Finance & Analytics',
    'UI/UX Design',
  ];

  const filteredInternships = internships.filter((i) => {
    const matchSearch =
      !search ||
      i.role.toLowerCase().includes(search.toLowerCase()) ||
      i.company.toLowerCase().includes(search.toLowerCase()) ||
      i.domain.toLowerCase().includes(search.toLowerCase());

    const matchDomain = selectedDomain === 'all' || i.domain === selectedDomain;
    const matchRemote = selectedRemote === 'all' || i.remote_type === selectedRemote;

    return matchSearch && matchDomain && matchRemote;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-600">
              <GraduationCap className="h-4 w-4" /> Student Internships & Research
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              PSG Internship Portal
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              High-stipend summer internships, 6-month pre-placement offers, and industrial research projects
            </p>
          </div>

          <Button
            onClick={() => setIsPostModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
          >
            <PlusCircle className="h-4 w-4" /> Post Internship
          </Button>
        </div>

        {/* Filter Toolbar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search Input */}
            <div className="relative lg:col-span-2">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search by role, company, or domain (e.g. AI, NVIDIA, Robotics)..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 text-xs"
              />
            </div>

            {/* Domain Filter */}
            <select
              value={selectedDomain}
              onChange={(e) => setSelectedDomain(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Domains</option>
              {domains.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            {/* Remote Type */}
            <select
              value={selectedRemote}
              onChange={(e) => setSelectedRemote(e.target.value)}
              className="h-10 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Work Formats</option>
              <option value="On-site">On-site</option>
              <option value="Hybrid">Hybrid</option>
              <option value="Remote">Remote</option>
            </select>
          </div>

          {/* Quick Domain Pills */}
          <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 overflow-x-auto text-xs">
            <button
              onClick={() => setSelectedDomain('all')}
              className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                selectedDomain === 'all'
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Domains
            </button>
            {domains.map((d) => (
              <button
                key={d}
                onClick={() => setSelectedDomain(d)}
                className={`px-3 py-1 rounded-full whitespace-nowrap transition-colors ${
                  selectedDomain === d
                    ? 'bg-indigo-600 text-white font-semibold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Internship Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredInternships.map((intern) => {
            const isItemSaved = user ? DataStore.isSaved(intern.id, 'internship', user.id) : false;
            return (
              <Card
                key={intern.id}
                className="flex flex-col justify-between hover:border-indigo-300 hover:shadow-lg transition-all"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={intern.company_logo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100'}
                        alt={intern.company}
                        className="h-12 w-12 rounded-xl object-cover border border-slate-200 shadow-sm"
                      />
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm line-clamp-1">{intern.role}</h3>
                        <p className="text-xs text-slate-500 font-medium">{intern.company}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSave(intern.id)}
                      className={`p-2 rounded-lg transition-colors ${
                        isItemSaved
                          ? 'bg-indigo-50 text-indigo-600'
                          : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                      }`}
                      title="Bookmark Internship"
                    >
                      <Bookmark className={`h-4 w-4 ${isItemSaved ? 'fill-indigo-600' : ''}`} />
                    </button>
                  </div>

                  <div className="space-y-2 mb-4 text-xs text-slate-600">
                    <p className="flex items-center gap-2">
                      <MapPin className="h-3.5 w-3.5 text-slate-400" />
                      <span>{intern.location} ({intern.remote_type})</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                      <span className="font-bold text-indigo-700">{intern.stipend}</span>
                      <span className="text-slate-400">• {intern.duration}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Clock className="h-3.5 w-3.5 text-slate-400" />
                      <span>Deadline: {new Date(intern.deadline).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</span>
                    </p>
                  </div>

                  <div className="mb-4">
                    <Badge variant="purple" className="text-[11px]">
                      {intern.domain}
                    </Badge>
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                    {intern.description}
                  </p>

                  <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                    <Button
                      onClick={() => setSelectedIntern(intern)}
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                    >
                      View Details
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedIntern(intern);
                        setIsApplyModalOpen(true);
                      }}
                      size="sm"
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
                    >
                      Apply Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* DETAIL MODAL */}
      {selectedIntern && (
        <Modal
          isOpen={Boolean(selectedIntern)}
          onClose={() => setSelectedIntern(null)}
          title={selectedIntern.role}
          description={`${selectedIntern.company} • ${selectedIntern.domain}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs">
            <div className="flex flex-wrap gap-2 p-3 bg-indigo-50/60 rounded-xl border border-indigo-200">
              <div>
                <span className="text-indigo-900/60 block text-[10px] uppercase font-bold">Monthly Stipend</span>
                <span className="font-bold text-indigo-700 text-sm">{selectedIntern.stipend}</span>
              </div>
              <div className="border-l border-indigo-200 pl-3">
                <span className="text-indigo-900/60 block text-[10px] uppercase font-bold">Duration</span>
                <span className="font-semibold text-slate-800">{selectedIntern.duration}</span>
              </div>
              <div className="border-l border-indigo-200 pl-3">
                <span className="text-indigo-900/60 block text-[10px] uppercase font-bold">Work Mode</span>
                <span className="font-semibold text-slate-800">{selectedIntern.remote_type}</span>
              </div>
              <div className="border-l border-indigo-200 pl-3">
                <span className="text-indigo-900/60 block text-[10px] uppercase font-bold">Deadline</span>
                <span className="font-semibold text-slate-800">{new Date(selectedIntern.deadline).toLocaleDateString()}</span>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Project & Internship Overview</h4>
              <p className="text-slate-600 leading-relaxed">{selectedIntern.description}</p>
            </div>

            {selectedIntern.requirements && (
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Requirements & Eligibility</h4>
                <ul className="list-disc pl-4 space-y-1 text-slate-600">
                  {selectedIntern.requirements.map((req, idx) => (
                    <li key={idx}>{req}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setSelectedIntern(null)}>
                Close
              </Button>
              <Button
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
                onClick={() => setIsApplyModalOpen(true)}
              >
                Apply for Internship
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* APPLY MODAL */}
      {isApplyModalOpen && selectedIntern && (
        <Modal
          isOpen={isApplyModalOpen}
          onClose={() => setIsApplyModalOpen(false)}
          title={`Apply: ${selectedIntern.role}`}
          description={`${selectedIntern.company} • Stipend: ${selectedIntern.stipend}`}
        >
          <form onSubmit={handleApply} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">PSG Student Roll Number *</label>
              <Input
                type="text"
                placeholder="e.g. 23CS205"
                value={rollNo}
                onChange={(e) => setRollNo(e.target.value)}
                required
                className="text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Portfolio / GitHub / Resume Link *</label>
              <Input
                type="url"
                placeholder="https://github.com/... or Google Drive"
                value={portfolioUrl}
                onChange={(e) => setPortfolioUrl(e.target.value)}
                required
                className="text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Brief Note on your relevant experience</label>
              <Textarea
                rows={3}
                placeholder="Mention relevant coursework, hackathons, or past projects in this domain..."
                value={pitchNote}
                onChange={(e) => setPitchNote(e.target.value)}
                className="text-xs"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsApplyModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold">
                Submit Internship Application
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* POST MODAL */}
      {isPostModalOpen && (
        <Modal
          isOpen={isPostModalOpen}
          onClose={() => setIsPostModalOpen(false)}
          title="Post an Internship Opportunity"
          description="Publish a summer or 6-month internship opening for PSG students"
          maxWidth="2xl"
        >
          <form onSubmit={handlePost} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Internship Role *</label>
                <Input
                  type="text"
                  placeholder="e.g. AI Research Intern"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Company / Lab Name *</label>
                <Input
                  type="text"
                  placeholder="e.g. NVIDIA Research"
                  value={newCompany}
                  onChange={(e) => setNewCompany(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Domain</label>
                <select
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  {domains.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Stipend</label>
                <Input
                  type="text"
                  value={newStipend}
                  onChange={(e) => setNewStipend(e.target.value)}
                  className="text-xs"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Duration</label>
                <Input
                  type="text"
                  value={newDuration}
                  onChange={(e) => setNewDuration(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Work Mode</label>
                <select
                  value={newRemote}
                  onChange={(e) => setNewRemote(e.target.value as any)}
                  className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="Hybrid">Hybrid</option>
                  <option value="On-site">On-site</option>
                  <option value="Remote">Remote</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Deadline</label>
                <Input
                  type="date"
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Description *</label>
              <Textarea
                rows={3}
                placeholder="Key learning goals and requirements..."
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsPostModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-indigo-600 text-white font-bold">
                Publish Internship
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function InternshipsPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading PSG Internships...</div>}>
      <InternshipsContent />
    </React.Suspense>
  );
}
