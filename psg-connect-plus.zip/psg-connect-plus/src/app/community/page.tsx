'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { DataStore } from '@/lib/store';
import { useToast } from '@/components/ui/toast';
import { Button } from '@/components/ui/button';
import { Input, Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Modal } from '@/components/ui/modal';
import {
  MessageSquare,
  ThumbsUp,
  Share2,
  PlusCircle,
  Pin,
  Search,
  Filter,
  Users,
  Send,
  Sparkles,
  HelpCircle,
  Car,
  Home,
  Briefcase,
  Code,
} from 'lucide-react';
import { CommunityPost, CommunityChannel } from '@/types';

function CommunityContent() {
  const { user } = useAuth();
  const { success, info, error } = useToast();

  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [activeChannel, setActiveChannel] = useState<string>('all');
  const [search, setSearch] = useState('');

  // Comment input per post
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  // New Post Modal
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newChannel, setNewChannel] = useState<CommunityChannel>('general');
  const [newContent, setNewContent] = useState('');

  const loadPosts = () => {
    setPosts(DataStore.getCommunityPosts());
  };

  useEffect(() => {
    loadPosts();
    window.addEventListener('psg_store_updated', loadPosts);
    return () => window.removeEventListener('psg_store_updated', loadPosts);
  }, []);

  const handleUpvote = (postId: string) => {
    const userId = user?.id || 'guest-usr';
    DataStore.toggleUpvotePost(postId, userId);
  };

  const handleAddComment = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    DataStore.addCommunityComment(postId, {
      author_name: user?.full_name || 'PSGian',
      author_role: user ? `${user.department.split(' ')[0]} '${String(user.batch_year).slice(-2)}` : 'Student',
      content: text,
    });

    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
    success('Reply Posted', 'Your comment has been added.');
  };

  const handleCreatePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newContent) {
      error('Missing Information', 'Please fill in title and description.');
      return;
    }

    const created = DataStore.addCommunityPost({
      title: newTitle,
      channel: newChannel,
      content: newContent,
      author_name: user?.full_name || 'PSG Student',
      author_role: user?.role === 'alumni' ? 'Alumni' : 'Student',
      author_dept: user?.department?.split(' ')[0] || 'PSG',
      author_avatar: user?.avatar_url,
    });

    if (user) {
      DataStore.addNotification({
        user_id: user.id,
        title: 'Discussion Thread Started',
        message: `Your post "${created.title}" is now active in #${newChannel}.`,
        type: 'system',
        link: '/community',
      });
    }

    success('Thread Created!', `Your discussion is now live in #${newChannel}.`);
    setIsPostModalOpen(false);
    setNewTitle('');
    setNewContent('');
  };

  const channels: { id: CommunityChannel | 'all'; label: string; icon: any }[] = [
    { id: 'all', label: 'All Discussions', icon: MessageSquare },
    { id: 'placement', label: 'Placement & Drives', icon: Briefcase },
    { id: 'housing', label: 'Flatmates & Rooms', icon: Home },
    { id: 'projects', label: 'Hackathons & Teams', icon: Code },
    { id: 'lost-found', label: 'Lost & Found', icon: HelpCircle },
    { id: 'rides', label: 'Cab & Ride Sharing', icon: Car },
  ];

  const filteredPosts = posts.filter((p) => {
    const matchSearch =
      !search ||
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.content.toLowerCase().includes(search.toLowerCase()) ||
      p.author_name.toLowerCase().includes(search.toLowerCase());

    const matchChannel = activeChannel === 'all' || p.channel === activeChannel;

    return matchSearch && matchChannel;
  });

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
      <div className="container max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-600">
              <Sparkles className="h-4 w-4" /> The Pulse of PSG Tech
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              PSG Campus Buzz & Student Lounge
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Live student discussions, hackathon team matching, flatmate finder, rideshare & senior guidance
            </p>
          </div>

          <Button
            onClick={() => setIsPostModalOpen(true)}
            className="bg-psg-900 hover:bg-psg-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm shrink-0"
          >
            <PlusCircle className="h-4 w-4" /> Post on Buzz
          </Button>
        </div>

        {/* Channel Navigation Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {channels.map((ch) => {
            const Icon = ch.icon;
            return (
              <button
                key={ch.id}
                onClick={() => setActiveChannel(ch.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeChannel === ch.id
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{ch.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative bg-white rounded-2xl border border-slate-200 shadow-sm p-2">
          <Search className="absolute left-5 top-4 h-4 w-4 text-slate-400" />
          <Input
            type="text"
            placeholder="Search discussion threads, questions, roll numbers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 text-xs border-0 shadow-none focus-visible:ring-0"
          />
        </div>

        {/* Feed */}
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const isUpvoted = post.upvoted_by.includes(user?.id || '');
            return (
              <Card key={post.id} className="p-6 transition-all hover:shadow-md">
                {/* Channel & Pin */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="psg" className="capitalize text-[10px]">
                      #{post.channel}
                    </Badge>
                    {post.is_pinned && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                        <Pin className="h-3 w-3" /> Pinned
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {new Date(post.created_at).toLocaleDateString('en-IN', {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </span>
                </div>

                <h2 className="text-base font-bold text-slate-900 leading-snug mb-2">
                  {post.title}
                </h2>
                <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line mb-4">
                  {post.content}
                </p>

                {/* Author Details & Upvote */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="h-7 w-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs">
                      {post.author_name[0]}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-slate-900">{post.author_name}</p>
                      <p className="text-[10px] text-slate-400">{post.author_role}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      onClick={() => handleUpvote(post.id)}
                      variant={isUpvoted ? 'default' : 'outline'}
                      size="sm"
                      className={`text-xs flex items-center gap-1.5 h-8 ${
                        isUpvoted ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-blue-50'
                      }`}
                    >
                      <ThumbsUp className="h-3.5 w-3.5" />
                      <span>{post.upvotes}</span>
                    </Button>
                  </div>
                </div>

                {/* Threaded Comments Section */}
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-3 bg-slate-50/70 p-4 rounded-xl">
                  <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Replies ({post.comments.length})
                  </p>

                  {post.comments.map((comm) => (
                    <div key={comm.id} className="p-3 bg-white rounded-lg border border-slate-200 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{comm.author_name}</span>
                        <span className="text-[10px] text-slate-400">{comm.author_role}</span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{comm.content}</p>
                    </div>
                  ))}

                  {/* Comment Input */}
                  <div className="flex items-center gap-2 pt-2">
                    <Input
                      type="text"
                      placeholder="Write a helpful response..."
                      value={commentInputs[post.id] || ''}
                      onChange={(e) =>
                        setCommentInputs({ ...commentInputs, [post.id]: e.target.value })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleAddComment(post.id);
                        }
                      }}
                      className="text-xs bg-white h-9"
                    />
                    <Button
                      onClick={() => handleAddComment(post.id)}
                      size="sm"
                      className="bg-psg-900 text-white h-9 px-3 shrink-0"
                    >
                      <Send className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {filteredPosts.length === 0 && (
          <Card className="p-12 text-center text-slate-500">
            <MessageSquare className="h-12 w-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No discussions found in this channel</h3>
            <p className="text-xs text-slate-500 mt-1">
              Be the first to start a conversation in #{activeChannel}.
            </p>
          </Card>
        )}
      </div>

      {/* CREATE DISCUSSION MODAL */}
      {isPostModalOpen && (
        <Modal
          isOpen={isPostModalOpen}
          onClose={() => setIsPostModalOpen(false)}
          title="Start a Community Discussion"
          description="Post a question or request assistance from PSG peers"
          maxWidth="lg"
        >
          <form onSubmit={handleCreatePostSubmit} className="space-y-3 text-xs">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Channel / Category *</label>
              <select
                value={newChannel}
                onChange={(e) => setNewChannel(e.target.value as any)}
                className="w-full h-10 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
              >
                <option value="placement">Placement & Drives (#placement)</option>
                <option value="housing">Flatmates & Rooms (#housing)</option>
                <option value="projects">Hackathons & Projects (#projects)</option>
                <option value="lost-found">Lost & Found (#lost-found)</option>
                <option value="rides">Cab & Ride Sharing (#rides)</option>
                <option value="general">General Campus Discussion (#general)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Thread Title *</label>
              <Input
                type="text"
                placeholder="e.g. Tips for Amazon SDE OA round or Flatmate needed in Hope College"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700">Detailed Message / Question *</label>
              <Textarea
                rows={4}
                placeholder="Provide all relevant details so peers can assist you..."
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setIsPostModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-psg-900 text-white font-bold">
                Post Discussion
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

export default function CommunityPage() {
  return (
    <React.Suspense fallback={<div className="min-h-screen bg-slate-50 py-12 text-center text-slate-500">Loading PSG Community...</div>}>
      <CommunityContent />
    </React.Suspense>
  );
}
