# 🎓 PSG Connect+

> **A Modern Student & Alumni Community Platform for PSG Institutions**
> Designed and engineered with Next.js (App Router), React, TypeScript, Tailwind CSS, and Supabase.

---

## 🌟 Overview & Purpose

**PSG Connect+** is a community and career platform built specifically for students, faculty, and alumni of PSG College of Technology and PSG Institutions. It provides a modern hub for:

- 💼 **Job Portal**: Placement opportunities, on-campus recruitments, off-campus referrals, and CTC tracking.
- 🎓 **Internship Hub**: High-stipend summer internships, research openings, and domain-specific roles (AI/ML, VLSI, Embedded, Robotics, Web).
- 🏠 **Student Accommodation Marketplace**: Verified PG, hostel, and apartment listings near Peelamedu, Hope College, and SITRA with zero brokerage and direct WhatsApp contact with owners.
- 📅 **College Events & Symposiums**: Live registrations for KRIYA, 24-hr Hackathons, Robotics Workshops, and Alumni Keynotes with digital QR ticket passes.
- 📝 **Exams & Academic Timetables**: Continuous Assessments (CA-1, CA-2) and End Semester exam schedules with venue allocations and iCal/Google Calendar exports.
- 🤝 **Global Alumni Directory**: Searchable network of PSG alumni at Google, Tesla, NVIDIA, Microsoft, McKinsey, and startups with 1-click mentorship connections.
- 📊 **User Dashboard**: Personalized opportunity recommendations tailored to the student's department, saved bookmarks, registered event passes, and notification feed.
- 🛡️ **Admin Control Suite**: Full administrative KPIs, listing approvals, job creation, exam timetable publication, user verification, and database reset tooling.

---

## 🚀 Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS, CSS variables, collegiate design system (PSG Navy & Emerald accents)
- **Components**: Custom accessible components, modal dialogs, and toast notifications
- **Database & Auth**: Supabase PostgreSQL + Auth with Row Level Security (RLS) policies
- **Resilient Fallback**: Hydrated Local Storage reactive data store pre-seeded with 50+ realistic PSG sample records
- **Icons**: Lucide React
- **Celebration Effects**: Canvas Confetti

---

## ⚡ Quick Start & Local Development

### 1. Prerequisites
- Node.js 18.17+ or 20+
- npm or pnpm

### 2. Installation

```bash
# Clone or navigate to the project directory
cd psg-connect-plus

# Install dependencies
npm install
```

### 3. Environment Variables (Optional for Demo Mode)

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

Fill in your Supabase credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

> **Note**: If Supabase variables are omitted, **PSG Connect+ automatically runs in Dual Demo Mode** with fully functional local persistence and instant role switching between **Student**, **Alumni**, and **Admin**!

### 4. Run the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🗄️ Supabase PostgreSQL Setup & Database Schema

To link a real Supabase database:

1. Create a new project in [Supabase](https://supabase.com).
2. Go to the **SQL Editor** in your Supabase dashboard.
3. Open [`supabase/schema.sql`](./supabase/schema.sql) from this repository and run the script.
4. It will automatically create all tables, indexes, triggers, and Row Level Security (RLS) policies:
   - `profiles`
   - `jobs`
   - `internships`
   - `accommodations`
   - `events`
   - `event_registrations`
   - `exams`
   - `alumni`
   - `saved_items`
   - `notifications`
   - `reports`

---

## 👥 Demo Accounts & Role Switching

PSG Connect+ includes a 1-click role switcher banner at the top of every page:

| Role | Demo Name | Email | Description |
| :--- | :--- | :--- | :--- |
| **Student** | Aditya Ramanathan | `aditya.22cse@psgtech.ac.in` | Pre-final year CSE student. Can save jobs, apply, register for events, and post housing. |
| **Alumni** | Dr. Priya Sundaram | `priya.sundaram@google.com` | Staff AI Engineer @ Google. Can offer mentorship, post jobs, and connect. |
| **Admin** | Placement & Admin Cell | `admin@psgconnect.edu` | Full platform manager. Can approve accommodation, publish exams, and manage drives. |

---

## 📦 Deploying to Vercel

PSG Connect+ is 100% ready for Vercel deployment:

1. Push this repository to GitHub / GitLab.
2. Import the project in [Vercel](https://vercel.com).
3. (Optional) Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in **Environment Variables**.
4. Click **Deploy**.

---

## 📄 License & Credits

Built for the PSG Tech and PSG Institutions community with excellence.
© 2026 PSG Connect+. All rights reserved.
