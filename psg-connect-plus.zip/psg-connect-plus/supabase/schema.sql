-- ==============================================================================
-- PSG Connect+ Complete Supabase PostgreSQL Schema (Idempotent & Safe)
-- Platform: Student & Alumni Hub for PSG Institutions
-- ==============================================================================

-- 1. Enable UUID extension
create extension if not exists "uuid-ossp";

-- 2. PROFILES TABLE
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text not null,
  email text unique not null,
  role text not null check (role in ('student', 'alumni', 'admin')),
  department text not null,
  batch_year integer not null,
  phone text,
  avatar_url text,
  bio text,
  skills text[],
  current_company text,
  "current_role" text,
  linkedin_url text,
  github_url text,
  is_verified boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. INTERNSHIPS TABLE
create table if not exists public.internships (
  id uuid default uuid_generate_v4() primary key,
  role text not null,
  company text not null,
  company_logo text,
  location text not null,
  domain text not null,
  is_paid boolean default true,
  stipend text not null,
  duration text not null,
  remote_type text not null check (remote_type in ('On-site', 'Remote', 'Hybrid')),
  eligible_departments text[] default '{}',
  description text not null,
  requirements text[] default '{}',
  deadline timestamp with time zone not null,
  apply_url text,
  posted_by uuid references public.profiles(id) on delete set null,
  is_active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. ACCOMMODATION LISTINGS TABLE
create table if not exists public.accommodations (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text not null,
  property_type text not null check (property_type in ('Single Room', '1 BHK', '2 BHK', '3 BHK', 'Shared Room', 'PG / Hostel')),
  rent integer not null,
  deposit integer not null,
  location text not null,
  distance_to_campus text not null,
  gender_preference text not null check (gender_preference in ('Boys Only', 'Girls Only', 'Any / Co-ed')),
  amenities text[] default '{}',
  images text[] default '{}',
  available_from date default current_date not null,
  owner_name text not null,
  owner_phone text not null,
  owner_whatsapp text,
  is_verified boolean default false,
  status text not null default 'approved' check (status in ('pending', 'approved', 'rejected')),
  posted_by uuid references public.profiles(id) on delete set null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 5. ACADEMIC SPOTLIGHT & RESOURCES TABLE
create table if not exists public.resources (
  id uuid default uuid_generate_v4() primary key,
  student_name text not null,
  title text not null,
  category text not null,
  program_type text,
  institution text not null default 'PSG Institute of Advanced Studies, Coimbatore',
  partner_university text,
  "current_role" text,
  award_name text,
  cohort_year text,
  photo_url text not null,
  description text not null,
  tags text[] default '{}',
  external_link text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 6. CAMPUS BUZZ / COMMUNITY POSTS TABLE
create table if not exists public.community_posts (
  id uuid default uuid_generate_v4() primary key,
  channel text not null check (channel in ('general', 'placement', 'housing', 'projects', 'lost-found', 'rides')),
  title text not null,
  content text not null,
  author_name text not null,
  author_avatar text,
  author_role text not null,
  author_dept text,
  upvotes integer default 0,
  is_pinned boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 7. COMMUNITY COMMENTS TABLE
create table if not exists public.community_comments (
  id uuid default uuid_generate_v4() primary key,
  post_id uuid references public.community_posts(id) on delete cascade not null,
  author_name text not null,
  author_avatar text,
  author_role text not null,
  content text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 8. EVENTS TABLE
create table if not exists public.events (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  category text not null check (category in ('Technical', 'Cultural', 'Sports', 'Workshops', 'Hackathons', 'Seminars', 'Alumni Talks', 'Placement')),
  event_date date not null,
  event_time text not null,
  venue text not null,
  description text not null,
  cover_image text,
  organizer text not null,
  capacity integer not null default 100,
  registered_count integer not null default 0,
  registration_link text,
  is_featured boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 9. EVENT REGISTRATIONS TABLE
create table if not exists public.event_registrations (
  id uuid default uuid_generate_v4() primary key,
  event_id uuid references public.events(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  student_roll_no text,
  ticket_code text not null default substr(md5(random()::text), 1, 8),
  status text default 'confirmed' check (status in ('confirmed', 'cancelled', 'attended')),
  registered_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (event_id, user_id)
);

-- 10. ALUMNI DIRECTORY TABLE
create table if not exists public.alumni (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  avatar_url text,
  department text not null,
  graduation_year integer not null,
  current_company text not null,
  position text not null,
  location text,
  skills text[] default '{}',
  linkedin_url text,
  bio text not null,
  available_for_mentorship boolean default true,
  contact_email text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 11. SAVED ITEMS TABLE
create table if not exists public.saved_items (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  item_id uuid not null,
  item_type text not null check (item_type in ('job', 'internship', 'event', 'accommodation')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (user_id, item_id, item_type)
);

-- 12. NOTIFICATIONS TABLE
create table if not exists public.notifications (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  title text not null,
  message text not null,
  type text not null check (type in ('opportunity', 'event', 'exam', 'housing', 'mentorship', 'system')),
  link text,
  is_read boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 13. CHAT MESSAGES TABLE
create table if not exists public.chat_messages (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  sender text not null check (sender in ('user', 'assistant', 'system')),
  content text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

alter table public.profiles enable row level security;
alter table public.internships enable row level security;
alter table public.accommodations enable row level security;
alter table public.resources enable row level security;
alter table public.community_posts enable row level security;
alter table public.community_comments enable row level security;
alter table public.events enable row level security;
alter table public.event_registrations enable row level security;
alter table public.alumni enable row level security;
alter table public.saved_items enable row level security;
alter table public.notifications enable row level security;
alter table public.chat_messages enable row level security;

-- Drop existing policies if any before re-creating
drop policy if exists "Public can view profiles" on public.profiles;
create policy "Public can view profiles" on public.profiles for select using (true);

drop policy if exists "Public can view internships" on public.internships;
create policy "Public can view internships" on public.internships for select using (is_active = true);

drop policy if exists "Public can view approved accommodations" on public.accommodations;
create policy "Public can view approved accommodations" on public.accommodations for select using (status = 'approved');

drop policy if exists "Public can view resources" on public.resources;
create policy "Public can view resources" on public.resources for select using (true);

drop policy if exists "Public can view community posts" on public.community_posts;
create policy "Public can view community posts" on public.community_posts for select using (true);

drop policy if exists "Public can view community comments" on public.community_comments;
create policy "Public can view community comments" on public.community_comments for select using (true);

drop policy if exists "Public can view events" on public.events;
create policy "Public can view events" on public.events for select using (true);

drop policy if exists "Public can view alumni directory" on public.alumni;
create policy "Public can view alumni directory" on public.alumni for select using (true);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);

drop policy if exists "Users can post accommodation" on public.accommodations;
create policy "Users can post accommodation" on public.accommodations for insert with check (auth.uid() = posted_by or posted_by is null);

drop policy if exists "Users can create community posts" on public.community_posts;
create policy "Users can create community posts" on public.community_posts for insert with check (true);

drop policy if exists "Users can add comments" on public.community_comments;
create policy "Users can add comments" on public.community_comments for insert with check (true);

drop policy if exists "Users can register for events" on public.event_registrations;
create policy "Users can register for events" on public.event_registrations for insert with check (auth.uid() = user_id);

drop policy if exists "Users can view own registrations" on public.event_registrations;
create policy "Users can view own registrations" on public.event_registrations for select using (auth.uid() = user_id);

drop policy if exists "Users can manage saved items" on public.saved_items;
create policy "Users can manage saved items" on public.saved_items for all using (auth.uid() = user_id);

drop policy if exists "Users can view notifications" on public.notifications;
create policy "Users can view notifications" on public.notifications for select using (auth.uid() = user_id);

drop policy if exists "Users can view and add chat messages" on public.chat_messages;
create policy "Users can view and add chat messages" on public.chat_messages for all using (auth.uid() = user_id or user_id is null);

-- Automatic updated_at trigger function
create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = timezone('utc'::text, now());
  return new;
end;
$$ language plpgsql;

drop trigger if exists on_profiles_updated on public.profiles;
create trigger on_profiles_updated
  before update on public.profiles
  for each row execute procedure public.handle_updated_at();
